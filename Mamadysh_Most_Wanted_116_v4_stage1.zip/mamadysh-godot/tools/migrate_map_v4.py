#!/usr/bin/env python3
"""Deterministic, idempotent v3 -> v4 terrain/road migration. Python 3.9+.

Keeps the original OSM-derived roads and navigation graph. No downloads.
"""
import argparse
import json
import math
from pathlib import Path


def smoothstep(t):
    t = max(0.0, min(1.0, t))
    return t*t*(3.0-2.0*t)


def migrate(data):
    if data.get('v4_migration', {}).get('version') == 1:
        return data
    b = data['bounds']; n = int(b['grid_n'])
    original = [float(x) for x in data['terrain_h']]
    assert len(original) == n*n, 'terrain grid size mismatch'
    xmin, xmax = float(b['x_min']), float(b['x_max'])
    zmin, zmax = float(b['z_min']), float(b['z_max'])
    dx, dz = (xmax-xmin)/(n-1), (zmax-zmin)/(n-1)
    roads = data['roads']
    assert all(len(r['pts']) >= 2 for r in roads)

    # Bridge endpoint adjustment: neighboring at-grade roads are eased to bridge
    # endpoint elevations over 45m. Do not carve under bridge decks.
    bridge_ends = []
    for r in roads:
        if int(r.get('br', 0)):
            for p in (r['pts'][0], r['pts'][-1]):
                bridge_ends.append((float(p[0]), float(p[2]), float(p[1])))
    for r in roads:
        if int(r.get('br', 0)):
            continue
        pts = r['pts']
        for k, p in enumerate(pts):
            # Only adjust road segments near bridge connections, preserving
            # far-field elevations and the original road topology.
            best = None
            for bx, bz, by in bridge_ends:
                dist = math.hypot(p[0]-bx, p[2]-bz)
                if dist <= 45.0 and (best is None or dist < best[0]):
                    best = (dist, by)
            if best:
                dist, by = best
                influence = 1.0 - smoothstep(dist/45.0)
                p[1] = round(float(p[1])*(1.0-influence) + by*influence, 4)

    # Road-aware terrain carving. A smooth weighted average at each terrain
    # grid vertex avoids harsh 19m grid stair-steps. The road mesh remains the
    # precise driving surface, while the terrain meets its shoulders.
    total = [0.0]*(n*n)
    weight = [0.0]*(n*n)
    for r in roads:
        if int(r.get('br', 0)):
            continue
        pts = r['pts']
        half = max(2.0, float(r.get('w', 8.0))*0.5)
        core = half + 1.0
        fade = max(12.0, 0.9*max(dx,dz))
        radius = core+fade
        for a, c in zip(pts, pts[1:]):
            ax, ay, az = map(float, a)
            cx, cy, cz = map(float, c)
            seglen = math.hypot(cx-ax, cz-az)
            if seglen < 1e-5:
                continue
            steps = max(1, math.ceil(seglen/5.0))
            for s in range(steps+1):
                t = s/steps
                x, z = ax+(cx-ax)*t, az+(cz-az)*t
                y = ay+(cy-ay)*t
                i0 = max(0, int(math.floor((x-radius-xmin)/dx)))
                i1 = min(n-1, int(math.ceil((x+radius-xmin)/dx)))
                j0 = max(0, int(math.floor((z-radius-zmin)/dz)))
                j1 = min(n-1, int(math.ceil((z+radius-zmin)/dz)))
                for j in range(j0, j1+1):
                    zz = zmin+j*dz
                    for i in range(i0, i1+1):
                        xx = xmin+i*dx
                        d = math.hypot(xx-x, zz-z)
                        if d >= radius:
                            continue
                        blend = 1.0 if d <= core else 1.0-smoothstep((d-core)/fade)
                        # Avoid oversampling long roads changing relative weights.
                        w = blend * min(1.0, seglen/steps/5.0)
                        idx = j*n+i
                        total[idx] += (y-0.06)*w
                        weight[idx] += w
    result = []
    for i, h in enumerate(original):
        if weight[i]:
            # Blended road target; terrain is below the road to prevent z-fighting.
            influence = min(1.0, weight[i])
            result.append(round(h*(1.0-influence)+total[i]/weight[i]*influence, 4))
        else:
            result.append(h)
    data['terrain_h'] = result
    data['v4_migration'] = {'version': 1, 'method': 'road_weighted_grid_carving',
                            'source': 'v3_osm_srtm', 'bridge_ramp_m': 45.0}
    return data


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('source', type=Path)
    ap.add_argument('--output', type=Path)
    args = ap.parse_args()
    source = args.source
    target = args.output or source.with_name(source.stem+'_v4.json')
    data = json.loads(source.read_text(encoding='utf-8'))
    migrate(data)
    target.write_text(json.dumps(data, ensure_ascii=False, separators=(',', ':'))+'\n', encoding='utf-8')
    print(f'Wrote {target} ({len(data["roads"])} roads, {len(data["terrain_h"])} terrain heights)')


if __name__ == '__main__':
    main()
