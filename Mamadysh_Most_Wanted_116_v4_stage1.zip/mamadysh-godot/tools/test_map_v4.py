#!/usr/bin/env python3
"""Offline deterministic structural checks for v4 migration."""
import copy
import json
import math
from pathlib import Path
from migrate_map_v4 import migrate
root = Path(__file__).resolve().parents[1]
a = json.loads((root/'assets/map/mamadysh_map.json').read_text(encoding='utf8'))
b = json.loads((root/'assets/map/mamadysh_map_v4.json').read_text(encoding='utf8'))
assert migrate(copy.deepcopy(a)) == b, 'Migration not reproducible'
assert migrate(copy.deepcopy(b)) == b, 'Migration not idempotent'
for key in ('graph_nodes', 'graph_adj', 'buildings', 'landmarks', 'race_circuit', 'olimp_circuit', 'vyatka_bank', 'oshma'):
    assert a[key] == b[key], f'Unexpected change to {key}'
assert len(a['roads']) == len(b['roads']) == 193
assert len(b['terrain_h']) == 180*180
assert all(math.isfinite(v) for v in b['terrain_h'])
assert all(r['pts'][0][:1] == old['pts'][0][:1] for r,old in zip(b['roads'],a['roads']))
print('PASS: deterministic, idempotent migration; topology preserved; heights finite')
