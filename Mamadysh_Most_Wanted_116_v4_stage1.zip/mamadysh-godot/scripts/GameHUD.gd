extends CanvasLayer
class_name GameHUD

signal car_selected(car_id: String)
signal circuit_selected(circuit_id: String)
signal start_requested(mode: PursuitAndRaceManager.GameMode)
signal atmosphere_cycled
signal camera_cycled
signal reset_car_requested
signal back_to_garage_requested

var main_root: Control
var garage_panel: Control
var hud_panel: Control
var result_panel: Control
var minimap: MinimapControl

var _car_title: Label
var _car_sub: Label
var _stat_bars: Array[ProgressBar] = []
var _atmo_garage_btn: Button
var _selected_mode: PursuitAndRaceManager.GameMode = PursuitAndRaceManager.GameMode.RACE
var _selected_circuit := "race"
var _mode_btns: Array[Button] = []
var _circuit_btns: Array[Button] = []

var _lbl_speed: Label
var _lbl_gear: Label
var _bar_rpm: ProgressBar
var _bar_nos: ProgressBar
var _bar_sb: ProgressBar
var _lbl_bounty: Label
var _lbl_heat: Label
var _lbl_lap: Label
var _bar_pursuit: ProgressBar
var _lbl_pursuit_state: Label
var _lbl_banner: Label
var _banner_timer := 0.0
var _btn_atmo_hud: Button
var _btn_cam_hud: Button
var _brake_btn: Button

var _lbl_res_title: Label
var _lbl_res_sub: Label
var _lbl_res_bounty: Label

var _touch_pads: Array[Dictionary] = []
var _active_fingers: Dictionary = {}
var _steer_zone: Control
var _steer_finger := -1
var _steer_mouse_down := false
var _steer_norm := 0.0  # -1 left .. +1 right (visual X)

var _player_ctrl: PlayerCarController
var _player_car: MamadyshVehicle
var _manager: PursuitAndRaceManager

func build_ui() -> void:
	main_root = Control.new()
	main_root.set_anchors_preset(Control.PRESET_FULL_RECT)
	main_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(main_root)

	_build_garage_ui()
	_build_hud_ui()
	_build_result_ui()
	show_garage()

func _style_btn(b: Button, bg: Color, border: Color, font_sz := 18) -> void:
	b.add_theme_font_size_override("font_size", font_sz)
	var sb := StyleBoxFlat.new()
	sb.bg_color = bg; sb.border_color = border
	sb.set_border_width_all(2); sb.set_corner_radius_all(8)
	sb.content_margin_left = 12; sb.content_margin_right = 12
	sb.content_margin_top = 8; sb.content_margin_bottom = 8
	b.add_theme_stylebox_override("normal", sb)
	var hb := sb.duplicate() as StyleBoxFlat; hb.bg_color = bg.lightened(0.14)
	b.add_theme_stylebox_override("hover", hb)
	var pb := sb.duplicate() as StyleBoxFlat; pb.bg_color = border.darkened(0.2)
	b.add_theme_stylebox_override("pressed", pb)

func _build_garage_ui() -> void:
	garage_panel = Control.new()
	garage_panel.set_anchors_preset(Control.PRESET_FULL_RECT)
	garage_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	main_root.add_child(garage_panel)

	var top_bar := PanelContainer.new()
	top_bar.set_anchors_preset(Control.PRESET_TOP_WIDE)
	top_bar.custom_minimum_size = Vector2(0, 64)
	var tb_style := StyleBoxFlat.new()
	tb_style.bg_color = Color(0.05, 0.06, 0.09, 0.85)
	tb_style.border_color = Color(0.95, 0.68, 0.14); tb_style.border_width_bottom = 2
	top_bar.add_theme_stylebox_override("panel", tb_style)
	garage_panel.add_child(top_bar)

	var top_hbox := HBoxContainer.new()
	top_hbox.add_theme_constant_override("separation", 16)
	top_bar.add_child(top_hbox)

	var title := Label.new()
	title.text = "  МАМАДЫШ: MOST WANTED 116  •  v3.0"
	title.add_theme_font_size_override("font_size", 24)
	title.add_theme_color_override("font_color", Color(1.0, 0.82, 0.22))
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	top_hbox.add_child(title)

	_atmo_garage_btn = Button.new()
	_atmo_garage_btn.text = "ПОГОДА: ЗАКАТ"
	_style_btn(_atmo_garage_btn, Color(0.14, 0.18, 0.26, 0.92), Color(0.45, 0.72, 1.0), 16)
	_atmo_garage_btn.pressed.connect(func(): atmosphere_cycled.emit())
	top_hbox.add_child(_atmo_garage_btn)

	var left_panel := PanelContainer.new()
	left_panel.position = Vector2(20, 78)
	left_panel.size = Vector2(360, 520)
	var lp_style := StyleBoxFlat.new()
	lp_style.bg_color = Color(0.05, 0.07, 0.11, 0.86)
	lp_style.border_color = Color(0.92, 0.68, 0.18, 0.75)
	lp_style.set_border_width_all(2); lp_style.set_corner_radius_all(10)
	left_panel.add_theme_stylebox_override("panel", lp_style)
	garage_panel.add_child(left_panel)

	var lvbox := VBoxContainer.new()
	lvbox.add_theme_constant_override("separation", 7)
	left_panel.add_child(lvbox)

	var hdr := Label.new()
	hdr.text = "ГАРАЖ МАМАДЫША"
	hdr.add_theme_font_size_override("font_size", 18)
	hdr.add_theme_color_override("font_color", Color(1.0, 0.84, 0.28))
	lvbox.add_child(hdr)

	for c in CarCatalog.CARS:
		var cid: String = c["id"]
		var cb := Button.new()
		cb.text = c["name"]
		cb.alignment = HORIZONTAL_ALIGNMENT_LEFT
		_style_btn(cb, Color(0.11, 0.13, 0.18, 0.95), Color(0.38, 0.44, 0.56), 15)
		cb.pressed.connect(func():
			_update_car_info(cid)
			car_selected.emit(cid)
		)
		lvbox.add_child(cb)

	lvbox.add_child(HSeparator.new())
	_car_title = Label.new(); _car_title.add_theme_font_size_override("font_size", 17); _car_title.add_theme_color_override("font_color", Color.WHITE); lvbox.add_child(_car_title)
	_car_sub = Label.new(); _car_sub.add_theme_font_size_override("font_size", 13); _car_sub.add_theme_color_override("font_color", Color(0.74, 0.80, 0.90)); lvbox.add_child(_car_sub)

	for sn in ["Скорость", "Разгон", "Управление", "Прочность"]:
		var sh := HBoxContainer.new()
		var sl := Label.new(); sl.text = sn; sl.custom_minimum_size = Vector2(108, 0); sl.add_theme_font_size_override("font_size", 13); sh.add_child(sl)
		var pb := ProgressBar.new(); pb.max_value = 100; pb.show_percentage = false; pb.size_flags_horizontal = Control.SIZE_EXPAND_FILL; pb.custom_minimum_size = Vector2(0, 13); sh.add_child(pb)
		lvbox.add_child(sh); _stat_bars.append(pb)

	var right_box := PanelContainer.new()
	right_box.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	right_box.offset_left = -410; right_box.offset_top = -315; right_box.offset_right = -20; right_box.offset_bottom = -20
	right_box.add_theme_stylebox_override("panel", lp_style)
	garage_panel.add_child(right_box)

	var rvbox := VBoxContainer.new()
	rvbox.add_theme_constant_override("separation", 7)
	right_box.add_child(rvbox)

	var c_lbl := Label.new(); c_lbl.text = "МАРШРУТ ПО ГОРОДУ"; c_lbl.add_theme_font_size_override("font_size", 15); c_lbl.add_theme_color_override("font_color", Color(0.6, 0.85, 1.0)); rvbox.add_child(c_lbl)
	var chb := HBoxContainer.new(); chb.add_theme_constant_override("separation", 8); rvbox.add_child(chb)
	for circ in [["Кольцо 6.1 км", "race"], ["Олимп — Пузанка", "olimp"]]:
		var cb := Button.new(); cb.text = circ[0]; cb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var cid: String = circ[1]
		_style_btn(cb, Color(0.11, 0.14, 0.2), Color(0.4, 0.5, 0.6), 14)
		cb.pressed.connect(func():
			_selected_circuit = cid
			_highlight_circuits()
			circuit_selected.emit(cid)
		)
		chb.add_child(cb); _circuit_btns.append(cb)

	var m_lbl := Label.new(); m_lbl.text = "РЕЖИМ ИГРЫ"; m_lbl.add_theme_font_size_override("font_size", 15); m_lbl.add_theme_color_override("font_color", Color(1.0, 0.84, 0.28)); rvbox.add_child(m_lbl)
	for md in [["ГОНКА ПО ГОРОДУ", PursuitAndRaceManager.GameMode.RACE], ["ПОГОНЯ ДПС (HEAT 1–5 ★)", PursuitAndRaceManager.GameMode.PURSUIT], ["СВОБОДНАЯ ЕЗДА", PursuitAndRaceManager.GameMode.FREE_ROAM]]:
		var mb := Button.new(); mb.text = md[0]; var m_val: PursuitAndRaceManager.GameMode = md[1]
		_style_btn(mb, Color(0.11, 0.14, 0.2, 0.95), Color(0.4, 0.45, 0.55), 14)
		mb.pressed.connect(func(): _selected_mode = m_val; _highlight_modes())
		rvbox.add_child(mb); _mode_btns.append(mb)

	var go_btn := Button.new(); go_btn.text = "НА СТАРТ!"
	_style_btn(go_btn, Color(0.85, 0.56, 0.08), Color(1.0, 0.9, 0.35), 22)
	go_btn.add_theme_color_override("font_color", Color(0.05, 0.05, 0.06))
	go_btn.pressed.connect(func(): start_requested.emit(_selected_mode))
	rvbox.add_child(go_btn)

	_update_car_info("lada_vesta_sport")
	_highlight_modes()
	_highlight_circuits()

func _highlight_modes() -> void:
	var vals: Array[PursuitAndRaceManager.GameMode] = [PursuitAndRaceManager.GameMode.RACE, PursuitAndRaceManager.GameMode.PURSUIT, PursuitAndRaceManager.GameMode.FREE_ROAM]
	for i in range(_mode_btns.size()):
		var active: bool = vals[i] == _selected_mode
		_style_btn(_mode_btns[i], Color(0.24, 0.19, 0.08) if active else Color(0.11, 0.14, 0.2), Color(1.0, 0.78, 0.2) if active else Color(0.35, 0.4, 0.5), 14)

func _highlight_circuits() -> void:
	var vals := ["race", "olimp"]
	for i in range(_circuit_btns.size()):
		var active: bool = vals[i] == _selected_circuit
		_style_btn(_circuit_btns[i], Color(0.10, 0.24, 0.32) if active else Color(0.11, 0.14, 0.2), Color(0.42, 0.85, 1.0) if active else Color(0.35, 0.4, 0.5), 14)

func _update_car_info(car_id: String) -> void:
	var cfg := CarCatalog.get_car(car_id)
	_car_title.text = cfg["name"]
	_car_sub.text = cfg["subtitle"]
	var keys := ["stat_speed", "stat_accel", "stat_handling", "stat_tough"]
	for i in range(keys.size()):
		_stat_bars[i].value = float(cfg.get(keys[i], 70))

func _build_hud_ui() -> void:
	hud_panel = Control.new()
	hud_panel.set_anchors_preset(Control.PRESET_FULL_RECT)
	hud_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	main_root.add_child(hud_panel)

	minimap = MinimapControl.new()
	minimap.position = Vector2(18, 18)
	minimap.size = Vector2(185, 165)
	hud_panel.add_child(minimap)

	var info_box := VBoxContainer.new()
	info_box.position = Vector2(215, 18)
	info_box.add_theme_constant_override("separation", 4)
	hud_panel.add_child(info_box)

	_lbl_bounty = Label.new(); _lbl_bounty.add_theme_font_size_override("font_size", 22); _lbl_bounty.add_theme_color_override("font_color", Color(1.0, 0.84, 0.22)); info_box.add_child(_lbl_bounty)
	_lbl_heat = Label.new(); _lbl_heat.add_theme_font_size_override("font_size", 18); _lbl_heat.add_theme_color_override("font_color", Color(1.0, 0.35, 0.3)); info_box.add_child(_lbl_heat)
	_lbl_lap = Label.new(); _lbl_lap.add_theme_font_size_override("font_size", 18); _lbl_lap.add_theme_color_override("font_color", Color(0.88, 0.94, 1.0)); info_box.add_child(_lbl_lap)
	_lbl_pursuit_state = Label.new(); _lbl_pursuit_state.add_theme_font_size_override("font_size", 14); info_box.add_child(_lbl_pursuit_state)
	_bar_pursuit = ProgressBar.new(); _bar_pursuit.custom_minimum_size = Vector2(200, 14); _bar_pursuit.max_value = 100; _bar_pursuit.show_percentage = false; _bar_pursuit.visible = false; info_box.add_child(_bar_pursuit)

	_lbl_banner = Label.new()
	_lbl_banner.set_anchors_preset(Control.PRESET_CENTER_TOP)
	_lbl_banner.offset_left = -340; _lbl_banner.offset_right = 340; _lbl_banner.offset_top = 84
	_lbl_banner.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_lbl_banner.add_theme_font_size_override("font_size", 32)
	_lbl_banner.add_theme_color_override("font_outline_color", Color.BLACK)
	_lbl_banner.add_theme_constant_override("outline_size", 6)
	hud_panel.add_child(_lbl_banner)

	var tools_hb := HBoxContainer.new()
	tools_hb.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	tools_hb.offset_left = -480; tools_hb.offset_top = 16; tools_hb.offset_right = -18
	tools_hb.alignment = BoxContainer.ALIGNMENT_END; tools_hb.add_theme_constant_override("separation", 8)
	hud_panel.add_child(tools_hb)

	_btn_cam_hud = Button.new(); _btn_cam_hud.text = "КАМЕРА"
	_style_btn(_btn_cam_hud, Color(0.08, 0.1, 0.16, 0.84), Color(0.5, 0.65, 0.85), 14)
	_btn_cam_hud.pressed.connect(func(): camera_cycled.emit()); tools_hb.add_child(_btn_cam_hud)

	_btn_atmo_hud = Button.new(); _btn_atmo_hud.text = "ЗАКАТ"
	_style_btn(_btn_atmo_hud, Color(0.08, 0.1, 0.16, 0.84), Color(0.5, 0.65, 0.85), 14)
	_btn_atmo_hud.pressed.connect(func(): atmosphere_cycled.emit()); tools_hb.add_child(_btn_atmo_hud)

	var btn_rst := Button.new(); btn_rst.text = "НА ДОРОГУ"
	_style_btn(btn_rst, Color(0.08, 0.1, 0.16, 0.84), Color(0.85, 0.65, 0.25), 14)
	btn_rst.pressed.connect(func(): reset_car_requested.emit()); tools_hb.add_child(btn_rst)

	var btn_gar := Button.new(); btn_gar.text = "ГАРАЖ"
	_style_btn(btn_gar, Color(0.16, 0.08, 0.08, 0.88), Color(0.95, 0.35, 0.3), 14)
	btn_gar.pressed.connect(func(): back_to_garage_requested.emit()); tools_hb.add_child(btn_gar)

	# Speedometer & Gear Panel
	var dash := PanelContainer.new()
	dash.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	dash.offset_left = -255; dash.offset_top = -315; dash.offset_right = -18; dash.offset_bottom = -185
	var ds := StyleBoxFlat.new()
	ds.bg_color = Color(0.04, 0.06, 0.10, 0.82); ds.border_color = Color(0.95, 0.72, 0.16, 0.75)
	ds.set_border_width_all(2); ds.set_corner_radius_all(10)
	dash.add_theme_stylebox_override("panel", ds); hud_panel.add_child(dash)

	var dv := VBoxContainer.new(); dash.add_child(dv)
	var sp_row := HBoxContainer.new(); dv.add_child(sp_row)
	_lbl_speed = Label.new(); _lbl_speed.text = "0"; _lbl_speed.add_theme_font_size_override("font_size", 42)
	_lbl_speed.add_theme_color_override("font_color", Color.WHITE); _lbl_speed.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sp_row.add_child(_lbl_speed)
	_lbl_gear = Label.new(); _lbl_gear.text = "N"; _lbl_gear.add_theme_font_size_override("font_size", 32)
	_lbl_gear.add_theme_color_override("font_color", Color(1.0, 0.82, 0.2)); sp_row.add_child(_lbl_gear)
	_bar_rpm = ProgressBar.new(); _bar_rpm.max_value = 8000; _bar_rpm.show_percentage = false; _bar_rpm.custom_minimum_size = Vector2(0, 8); dv.add_child(_bar_rpm)
	var nos_lbl := Label.new(); nos_lbl.text = "NOS [Shift]"; nos_lbl.add_theme_font_size_override("font_size", 11); dv.add_child(nos_lbl)
	_bar_nos = ProgressBar.new(); _bar_nos.max_value = 100; _bar_nos.show_percentage = false; _bar_nos.custom_minimum_size = Vector2(0, 10); dv.add_child(_bar_nos)
	var sb_lbl := Label.new(); sb_lbl.text = "ЗАМЕДЛЕНИЕ [E]"; sb_lbl.add_theme_font_size_override("font_size", 11); dv.add_child(sb_lbl)
	_bar_sb = ProgressBar.new(); _bar_sb.max_value = 100; _bar_sb.show_percentage = false; _bar_sb.custom_minimum_size = Vector2(0, 10); dv.add_child(_bar_sb)

	# Bottom-Left Analog Steering Joystick + Handbrake
	_steer_zone = Control.new()
	_steer_zone.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	_steer_zone.offset_left = 18; _steer_zone.offset_top = -172
	_steer_zone.offset_right = 232; _steer_zone.offset_bottom = -18
	_steer_zone.draw.connect(_draw_steer_joystick)
	hud_panel.add_child(_steer_zone)

	_add_touch_pad("РУЧН.", "hb", Control.PRESET_BOTTOM_LEFT, Rect2(246, -124, 96, 98), Color(0.38, 0.16, 0.12, 0.72))

	# Bottom-Right Pedals: Brake/Reverse ("ТОРМ / R"), Gas ("ГАЗ"), NOS, Slow-mo
	_brake_btn = _add_touch_pad("ТОРМ / R", "brake", Control.PRESET_BOTTOM_RIGHT, Rect2(-264, -145, 114, 122), Color(0.45, 0.12, 0.12, 0.78))
	_add_touch_pad("ГАЗ", "gas", Control.PRESET_BOTTOM_RIGHT, Rect2(-138, -165, 118, 142), Color(0.14, 0.42, 0.20, 0.80))
	_add_touch_pad("NOS", "nos", Control.PRESET_BOTTOM_RIGHT, Rect2(-376, -160, 98, 72), Color(0.10, 0.34, 0.56, 0.78))
	_add_touch_pad("SLOW", "sb", Control.PRESET_BOTTOM_RIGHT, Rect2(-376, -80, 98, 58), Color(0.42, 0.30, 0.08, 0.78))

func _draw_steer_joystick() -> void:
	if not is_instance_valid(_steer_zone):
		return
	var sz := _steer_zone.size
	var c := sz * 0.5
	var r_outer := minf(sz.x, sz.y) * 0.46
	_steer_zone.draw_arc(c, r_outer, 0.0, TAU, 36, Color(0.85, 0.88, 0.94, 0.42), 3.0)
	_steer_zone.draw_circle(c, r_outer, Color(0.08, 0.12, 0.20, 0.62))
	_steer_zone.draw_line(c - Vector2(r_outer * 0.72, 0), c + Vector2(r_outer * 0.72, 0), Color(1, 1, 1, 0.20), 2.0)
	var knob_pos := c + Vector2(_steer_norm * (r_outer * 0.68), 0.0)
	var active := absf(_steer_norm) > 0.02 or _steer_finger != -1 or _steer_mouse_down
	_steer_zone.draw_circle(knob_pos, r_outer * 0.36, Color(0.95, 0.76, 0.20, 0.90) if active else Color(0.45, 0.58, 0.74, 0.82))
	_steer_zone.draw_arc(knob_pos, r_outer * 0.36, 0.0, TAU, 24, Color(1, 1, 1, 0.75), 2.2)

func _update_analog_steer_from_pos(pos: Vector2) -> void:
	var rect := _steer_zone.get_global_rect()
	var cx := rect.get_center().x
	var max_r := rect.size.x * 0.38
	var raw := clampf((pos.x - cx) / max_r, -1.0, 1.0)
	if absf(raw) < 0.07:
		raw = 0.0
	else:
		raw = signf(raw) * pow((absf(raw) - 0.07) / 0.93, 1.15)
	_steer_norm = raw
	if is_instance_valid(_player_ctrl):
		# +X visual right = -1.0 steer right; -X visual left = +1.0 steer left
		_player_ctrl.touch_steer = -raw
	_steer_zone.queue_redraw()

func _add_touch_pad(text: String, action_id: String, preset: Control.LayoutPreset, off: Rect2, col: Color) -> Button:
	var b := Button.new()
	b.text = text; b.focus_mode = Control.FOCUS_NONE
	b.set_anchors_preset(preset)
	b.offset_left = off.position.x; b.offset_top = off.position.y
	b.offset_right = off.position.x + off.size.x; b.offset_bottom = off.position.y + off.size.y
	_style_btn(b, col, Color(1, 1, 1, 0.45), 17)
	b.button_down.connect(func(): _set_pad_state(action_id, true))
	b.button_up.connect(func(): _set_pad_state(action_id, false))
	hud_panel.add_child(b)
	_touch_pads.append({"btn": b, "id": action_id})
	return b

func _input(event: InputEvent) -> void:
	if not hud_panel.visible or not is_instance_valid(_player_ctrl):
		return
	if event is InputEventScreenTouch:
		var ev := event as InputEventScreenTouch
		if ev.pressed:
			if _steer_zone.get_global_rect().has_point(ev.position):
				_steer_finger = ev.index
				_update_analog_steer_from_pos(ev.position)
				return
			for pad in _touch_pads:
				if (pad["btn"] as Button).get_global_rect().has_point(ev.position):
					_active_fingers[ev.index] = pad["id"]
					_recompute_touch_pads()
					break
		else:
			if ev.index == _steer_finger:
				_steer_finger = -1
				_steer_norm = 0.0
				_player_ctrl.touch_steer = 0.0
				_steer_zone.queue_redraw()
			if _active_fingers.has(ev.index):
				_active_fingers.erase(ev.index)
				_recompute_touch_pads()
	elif event is InputEventScreenDrag:
		var dv := event as InputEventScreenDrag
		if dv.index == _steer_finger:
			_update_analog_steer_from_pos(dv.position)
			return
		var found := ""
		for pad in _touch_pads:
			if (pad["btn"] as Button).get_global_rect().has_point(dv.position):
				found = pad["id"]; break
		if found != "": _active_fingers[dv.index] = found
		elif _active_fingers.has(dv.index): _active_fingers.erase(dv.index)
		_recompute_touch_pads()
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		var mb := event as InputEventMouseButton
		if mb.pressed and _steer_zone.get_global_rect().has_point(mb.position):
			_steer_mouse_down = true; _update_analog_steer_from_pos(mb.position)
		elif not mb.pressed and _steer_mouse_down:
			_steer_mouse_down = false; _steer_norm = 0.0; _player_ctrl.touch_steer = 0.0; _steer_zone.queue_redraw()
	elif event is InputEventMouseMotion and _steer_mouse_down:
		_update_analog_steer_from_pos((event as InputEventMouseMotion).position)
	elif event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_R: reset_car_requested.emit()
		elif event.keycode == KEY_C: camera_cycled.emit()
		elif event.keycode == KEY_T: atmosphere_cycled.emit()

func _recompute_touch_pads() -> void:
	if not is_instance_valid(_player_ctrl): return
	var held := {}
	for k in _active_fingers.values(): held[k] = true
	_player_ctrl.touch_throttle = 1.0 if held.has("gas") else 0.0
	_player_ctrl.touch_brake = 1.0 if held.has("brake") else 0.0
	_player_ctrl.touch_handbrake = 1.0 if held.has("hb") else 0.0
	_player_ctrl.touch_nos = held.has("nos")
	_player_ctrl.touch_sb = held.has("sb")

func _set_pad_state(action_id: String, down: bool) -> void:
	if not is_instance_valid(_player_ctrl): return
	match action_id:
		"gas": _player_ctrl.touch_throttle = 1.0 if down else 0.0
		"brake": _player_ctrl.touch_brake = 1.0 if down else 0.0
		"hb": _player_ctrl.touch_handbrake = 1.0 if down else 0.0
		"nos": _player_ctrl.touch_nos = down
		"sb": _player_ctrl.touch_sb = down

func _build_result_ui() -> void:
	result_panel = Control.new(); result_panel.set_anchors_preset(Control.PRESET_FULL_RECT); main_root.add_child(result_panel)
	var bg := ColorRect.new(); bg.set_anchors_preset(Control.PRESET_FULL_RECT); bg.color = Color(0.02, 0.03, 0.06, 0.72); result_panel.add_child(bg)
	var card := PanelContainer.new(); card.set_anchors_preset(Control.PRESET_CENTER)
	card.offset_left = -260; card.offset_top = -150; card.offset_right = 260; card.offset_bottom = 150
	var cs := StyleBoxFlat.new(); cs.bg_color = Color(0.06, 0.08, 0.12, 0.96); cs.border_color = Color(1.0, 0.78, 0.2)
	cs.set_border_width_all(3); cs.set_corner_radius_all(12); card.add_theme_stylebox_override("panel", cs); result_panel.add_child(card)
	var v := VBoxContainer.new(); v.add_theme_constant_override("separation", 12); v.alignment = BoxContainer.ALIGNMENT_CENTER; card.add_child(v)
	_lbl_res_title = Label.new(); _lbl_res_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; _lbl_res_title.add_theme_font_size_override("font_size", 28); _lbl_res_title.add_theme_color_override("font_color", Color(1.0, 0.84, 0.24)); v.add_child(_lbl_res_title)
	_lbl_res_sub = Label.new(); _lbl_res_sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; _lbl_res_sub.add_theme_font_size_override("font_size", 16); v.add_child(_lbl_res_sub)
	_lbl_res_bounty = Label.new(); _lbl_res_bounty.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; _lbl_res_bounty.add_theme_font_size_override("font_size", 22); _lbl_res_bounty.add_theme_color_override("font_color", Color(0.4, 1.0, 0.5)); v.add_child(_lbl_res_bounty)
	var hb := HBoxContainer.new(); hb.alignment = BoxContainer.ALIGNMENT_CENTER; hb.add_theme_constant_override("separation", 14); v.add_child(hb)
	var b_retry := Button.new(); b_retry.text = "ЗАНОВО"; _style_btn(b_retry, Color(0.84, 0.56, 0.08), Color(1.0, 0.9, 0.35), 18); b_retry.pressed.connect(func(): start_requested.emit(_selected_mode)); hb.add_child(b_retry)
	var b_gar := Button.new(); b_gar.text = "В ГАРАЖ"; _style_btn(b_gar, Color(0.14, 0.18, 0.25), Color(0.55, 0.65, 0.8), 18); b_gar.pressed.connect(func(): back_to_garage_requested.emit()); hb.add_child(b_gar)

func bind_session(car: MamadyshVehicle, ctrl: PlayerCarController, mgr: PursuitAndRaceManager) -> void:
	_player_car = car; _player_ctrl = ctrl; _manager = mgr

func show_garage() -> void:
	garage_panel.visible = true; hud_panel.visible = false; result_panel.visible = false; _active_fingers.clear()
	_steer_finger = -1; _steer_mouse_down = false; _steer_norm = 0.0

func show_hud() -> void:
	garage_panel.visible = false; hud_panel.visible = true; result_panel.visible = false

func show_result(summary: Dictionary) -> void:
	result_panel.visible = true
	_lbl_res_title.text = summary.get("title", "ЗАЕЗД ЗАВЕРШЁН")
	_lbl_res_sub.text = summary.get("subtitle", "")
	_lbl_res_bounty.text = "РЕЙТИНГ: %d ₽" % int(summary.get("bounty", 0))

func show_banner(msg: String, col := Color(1.0, 0.88, 0.25)) -> void:
	_lbl_banner.text = msg; _lbl_banner.add_theme_color_override("font_color", col); _banner_timer = 2.2

func set_atmosphere_label(lbl: String) -> void:
	if _atmo_garage_btn: _atmo_garage_btn.text = "ПОГОДА: " + lbl
	if _btn_atmo_hud: _btn_atmo_hud.text = lbl

func set_camera_label(lbl: String) -> void:
	if _btn_cam_hud: _btn_cam_hud.text = lbl

func _process(delta: float) -> void:
	if _banner_timer > 0.0:
		_banner_timer -= delta / maxf(Engine.time_scale, 0.1)
		_lbl_banner.visible = _banner_timer > 0.0

	if not hud_panel.visible or not is_instance_valid(_player_car) or not is_instance_valid(_manager):
		return

	_lbl_speed.text = "%d км/ч" % _player_car.get_speed_kmh()
	var g := _player_car.current_gear
	_lbl_gear.text = "R" if g == -1 else ("N" if g == 0 else str(g))
	if _brake_btn:
		_brake_btn.text = "ЗАДНИЙ [R]" if g == -1 else "ТОРМ / R"
	_bar_rpm.value = _player_car.motor_rpm
	_bar_nos.value = _player_car.nos_fuel
	_bar_sb.value = _player_car.sb_energy

	_lbl_bounty.text = "РЕЙТИНГ: %d ₽" % _manager.bounty
	_lbl_heat.text = ("ЖАР ДПС: %s" % "★".repeat(_manager.heat_level)) if _manager.heat_level > 0 else "СПОКОЙНО"

	if _manager.mode == PursuitAndRaceManager.GameMode.RACE:
		_lbl_lap.text = "КРУГ %d / %d  •  %.1fс" % [_manager.current_lap, _manager.total_laps, _manager.race_time]
	elif _manager.mode == PursuitAndRaceManager.GameMode.PURSUIT:
		_lbl_lap.text = "ТАРАН ДПС: %d  •  %.0fс" % [_manager.takedowns, _manager.race_time]
	else:
		_lbl_lap.text = "СВОБОДНАЯ ЕЗДА • МАМАДЫШ"

	if _manager.bust_meter > 0.04:
		_bar_pursuit.visible = true; _bar_pursuit.value = _manager.bust_meter * 100.0
		_lbl_pursuit_state.text = "УГРОЗА АРЕСТА!"; _lbl_pursuit_state.add_theme_color_override("font_color", Color(1.0, 0.25, 0.25))
	elif _manager.evade_meter > 0.04 and _manager.mode == PursuitAndRaceManager.GameMode.PURSUIT:
		_bar_pursuit.visible = true; _bar_pursuit.value = _manager.evade_meter * 100.0
		_lbl_pursuit_state.text = "ОТРЫВ ОТ ДПС..."; _lbl_pursuit_state.add_theme_color_override("font_color", Color(0.35, 0.95, 0.5))
	else:
		_bar_pursuit.visible = false; _lbl_pursuit_state.text = ""
