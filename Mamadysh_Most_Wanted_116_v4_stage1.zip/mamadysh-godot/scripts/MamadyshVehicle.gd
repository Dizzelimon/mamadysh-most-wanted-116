extends "res://addons/gevp/scripts/vehicle.gd"
class_name MamadyshVehicle

signal crashed(impulse: float, other: Node)

var car_cfg: Dictionary = {}
var is_player := false
var is_police := false
var is_traffic := false
var is_racer := false
var ram_power := 1.0

var caliper_links: Array[Dictionary] = []
var headlight_mats: Array[StandardMaterial3D] = []
var taillight_mats: Array[StandardMaterial3D] = []
var reverse_mat: StandardMaterial3D
var headlights_spots: Array[SpotLight3D] = []
var nos_flames: Array[MeshInstance3D] = []
var smoke_particles: Array[CPUParticles3D] = []

var police_red_mat: StandardMaterial3D
var police_blue_mat: StandardMaterial3D
var police_light: OmniLight3D
var siren_player: AudioStreamPlayer3D
var siren_active := false

var screech_player: AudioStreamPlayer3D
var crash_player: AudioStreamPlayer3D
var nos_player: AudioStreamPlayer3D

var detachable_parts: Array[Node3D] = []
var detached_count := 0

var nos_fuel := 100.0
var nos_active := false
var sb_energy := 100.0
var sb_active := false

var _night_mode := false
var _police_timer := 0.0
var _crash_cooldown := 0.0
var _last_crash_impulse := 0.0
var _screech_smooth := 0.0

func _ready() -> void:
	contact_monitor = true
	max_contacts_reported = 4
	super._ready()

func _integrate_forces(state: PhysicsDirectBodyState3D) -> void:
	super._integrate_forces(state)
	var max_imp := 0.0
	var hit_node: Node = null
	for i in range(state.get_contact_count()):
		var imp := state.get_contact_impulse(i).length()
		if imp > max_imp:
			max_imp = imp
			var col := state.get_contact_collider_object(i)
			if col is Node:
				hit_node = col
	if max_imp > 1400.0 and _crash_cooldown <= 0.0:
		_last_crash_impulse = max_imp
		_crash_cooldown = 0.35
		call_deferred("_handle_crash", max_imp, hit_node)

func _physics_process(delta: float) -> void:
	super._physics_process(delta)
	if linear_velocity.y > 11.0:
		linear_velocity.y = 11.0
	if _crash_cooldown > 0.0:
		_crash_cooldown -= delta

	# Keep non-spinning brake calipers aligned with wheel vertical travel
	for link in caliper_links:
		var wn: Node3D = link["wheel_node"]
		var kn: Node3D = link["knuckle"]
		if is_instance_valid(wn) and is_instance_valid(kn):
			kn.position.y = wn.position.y

	# Taillight braking glow + crisp Reverse lights
	var brake_glow := 3.8 if (brake_input > 0.15 or handbrake_input > 0.15) else (0.75 if _night_mode else 0.0)
	for tm in taillight_mats:
		tm.emission_energy_multiplier = brake_glow
	if reverse_mat:
		reverse_mat.emission_energy_multiplier = 3.5 if current_gear == -1 else 0.0

	# NOS physics boost + flames + audio
	if nos_active and nos_fuel > 1.0 and throttle_input > 0.1:
		var boost_n := vehicle_mass * (10.5 if is_player else 6.0)
		apply_central_force(-global_transform.basis.z * boost_n)
		nos_fuel = maxf(0.0, nos_fuel - delta * 26.0)
		for nf in nos_flames:
			nf.visible = true
			nf.scale = Vector3(1.0 + randf() * 0.35, 1.0 + randf() * 0.35, 0.9 + randf() * 0.7)
		if nos_player and not nos_player.playing:
			nos_player.play()
	else:
		nos_active = false
		var regen := 6.5 if absf(local_velocity.x) < 3.0 else 16.0  # Drift fills NOS faster!
		nos_fuel = minf(100.0, nos_fuel + delta * regen)
		for nf in nos_flames:
			nf.visible = false
		if nos_player and nos_player.playing:
			nos_player.stop()

	# Tire slip screech & drift smoke
	var slip_lat := absf(local_velocity.x)
	var drifting := speed > 7.5 and (slip_lat > 3.6 or (handbrake_input > 0.2 and speed > 6.0))
	var target_screech := clampf((slip_lat - 3.0) / 8.0, 0.0, 1.0) if drifting else 0.0
	_screech_smooth = lerpf(_screech_smooth, target_screech, delta * 10.0)
	if screech_player:
		if _screech_smooth > 0.08:
			if not screech_player.playing:
				screech_player.play()
			screech_player.volume_db = linear_to_db(_screech_smooth * 0.42)
		elif screech_player.playing:
			screech_player.stop()
	for sp in smoke_particles:
		sp.emitting = drifting

	# Police Lightbar strobe
	if is_police:
		_police_timer += delta * (9.5 if siren_active else 0.0)
		var phase := int(_police_timer) % 4
		if police_red_mat and police_blue_mat:
			police_red_mat.emission_energy_multiplier = 4.5 if (siren_active and phase < 2) else 0.0
			police_blue_mat.emission_energy_multiplier = 4.5 if (siren_active and phase >= 2) else 0.0
		if police_light:
			police_light.light_energy = 2.6 if siren_active else 0.0
			police_light.light_color = Color(1.0, 0.12, 0.1) if phase < 2 else Color(0.15, 0.45, 1.0)
		if siren_player:
			if siren_active and not siren_player.playing:
				siren_player.play()
			elif not siren_active and siren_player.playing:
				siren_player.stop()

func _handle_crash(imp: float, other: Node) -> void:
	crashed.emit(imp, other)
	if crash_player and imp > 1800.0:
		crash_player.volume_db = linear_to_db(clampf(imp / 14000.0, 0.18, 0.9))
		crash_player.pitch_scale = randf_range(0.88, 1.14)
		crash_player.play()

	# Detach bumpers / spoiler / mirrors on heavy hits!
	if imp > 4800.0 and detachable_parts.size() > 0:
		var part: Node3D = detachable_parts.pop_front()
		if is_instance_valid(part) and part.get_parent():
			_detach_part(part)

func _detach_part(part: Node3D) -> void:
	detached_count += 1
	var world_tr := part.global_transform
	part.get_parent().remove_child(part)
	var parent_world := get_parent()
	if parent_world == null:
		part.queue_free()
		return
	var debris := RigidBody3D.new()
	debris.collision_layer = 2
	debris.collision_mask = 1 | 2
	debris.mass = 18.0
	debris.global_transform = world_tr
	part.transform = Transform3D.IDENTITY
	debris.add_child(part)
	var cs := CollisionShape3D.new()
	var sh := BoxShape3D.new()
	sh.size = Vector3(0.8, 0.28, 0.35)
	cs.shape = sh
	debris.add_child(cs)
	parent_world.add_child(debris)
	debris.apply_central_impulse(linear_velocity * 8.0 + Vector3(randf_range(-40, 40), 95, randf_range(-40, 40)))
	debris.apply_torque_impulse(Vector3(randf_range(-18, 18), randf_range(-18, 18), randf_range(-18, 18)))
	get_tree().create_timer(7.0).timeout.connect(func():
		if is_instance_valid(debris):
			debris.queue_free()
	)

func set_headlights_night(night: bool) -> void:
	_night_mode = night
	for hm in headlight_mats:
		hm.emission_energy_multiplier = 3.2 if night else 0.25
	for sp in headlights_spots:
		sp.light_energy = 3.6 if (night and (is_player or is_police)) else 0.0

func get_speed_kmh() -> int:
	return int(roundf(speed * 3.6))
