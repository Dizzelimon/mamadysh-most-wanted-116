extends RefCounted
class_name VehicleFactory

static var _audio_cache: Dictionary = {}

static func _load_wav(path: String, loop := false) -> AudioStreamWAV:
	var key := path + ("_loop" if loop else "")
	if _audio_cache.has(key):
		return _audio_cache[key]
	var wav := load(path) as AudioStreamWAV
	if wav and loop:
		wav = wav.duplicate() as AudioStreamWAV
		wav.loop_mode = AudioStreamWAV.LOOP_FORWARD
		var sample_count := int(wav.get_length() * float(wav.mix_rate))
		if sample_count > 0:
			wav.loop_end = sample_count
	_audio_cache[key] = wav
	return wav

static func create_vehicle(car_id: String, role := "player", add_sound := true) -> MamadyshVehicle:
	var cfg := CarCatalog.get_car(car_id)
	var v := MamadyshVehicle.new()
	v.car_cfg = cfg
	v.is_player = (role == "player")
	v.is_police = (role == "police")
	v.is_traffic = (role == "traffic")
	v.is_racer = (role == "racer")
	v.ram_power = float(cfg.get("ram_power", 1.0))

	# Physics layers: vehicles on Layer 4, collide with Terrain(1), Props/Buildings(2), Vehicles(4)
	v.collision_layer = 4
	v.collision_mask = 1 | 2 | 4

	# GEVP Vehicle tuning tailored to Mamadysh Russian fleet
	v.vehicle_mass = float(cfg["mass"])
	v.max_torque = float(cfg["max_torque"]) * 1.28
	v.max_rpm = float(cfg["max_rpm"])
	v.idle_rpm = 950.0
	v.clutch_out_rpm = 1250.0
	v.front_torque_split = float(cfg["front_torque_split"])
	v.variable_torque_split = true
	v.front_variable_split = float(cfg["front_torque_split"])
	v.automatic_transmission = true
	var gr: Array[float] = [3.65, 2.25, 1.54, 1.12, 0.86, 0.68]
	v.gear_ratios = gr
	v.final_drive = 4.20
	v.reverse_ratio = 4.10
	v.shift_time = 0.09
	v.max_steering_angle = deg_to_rad(36.0)
	v.steering_speed = 4.6
	v.countersteer_assist = 0.88
	v.stability_yaw_ground_multiplier = 5.6
	v.center_of_gravity_height_offset = float(cfg.get("cog_y", -0.22))
	v.braking_grip_multiplier = 2.0
	v.front_damping_ratio = 0.72
	v.rear_damping_ratio = 0.72
	v.front_arb_ratio = 0.35
	v.rear_arb_ratio = 0.32
	v.front_tire_radius = float(cfg["wheel_r"])
	v.rear_tire_radius = float(cfg["wheel_r"])
	v.front_spring_length = float(cfg["spring_len"]) + 0.05
	v.rear_spring_length = float(cfg["spring_len"]) + 0.06
	v.front_resting_ratio = 0.5
	v.rear_resting_ratio = 0.5
	v.coefficient_of_drag = 0.30
	v.frontal_area = 2.2

	var tc := Curve.new()
	tc.add_point(Vector2(0.0, 0.78))
	tc.add_point(Vector2(0.55, 1.0))
	tc.add_point(Vector2(1.0, 0.78))
	v.torque_curve = tc

	var grip_r := float(cfg["grip_road"])
	var grip_g := float(cfg["grip_grass"])
	v.tire_stiffnesses = {"Road": 11.5, "Grass": 3.4 if grip_g > 2.4 else 1.2}
	v.coefficient_of_friction = {"Road": grip_r, "Grass": grip_g}
	v.rolling_resistance = {"Road": 0.6, "Grass": 2.2 if grip_g > 2.4 else 3.8}
	v.lateral_grip_assist = {"Road": 0.16, "Grass": 0.05}
	v.longitudinal_grip_ratio = {"Road": 0.92, "Grass": 0.65}

	# Main CollisionShape3D raised above ride clearance so flat asphalt never scrapes
	var cs := CollisionShape3D.new()
	var box := BoxShape3D.new()
	var L := float(cfg["length"])
	var W := float(cfg["width"])
	var H := float(cfg["height"])
	box.size = Vector3(W * 0.92, H * 0.66, L * 0.94)
	cs.shape = box
	cs.position = Vector3(0.0, 0.32 + H * 0.33, 0.0)
	v.add_child(cs)

	# Load .glb car scene and bind Body_Shell + 4 GEVP RayCast3D Wheels
	var glb_ps := load(cfg["glb"]) as PackedScene
	var model_root := glb_ps.instantiate()

	var wheel_map := {
		"Wheel_FL": "front_left_wheel",
		"Wheel_FR": "front_right_wheel",
		"Wheel_RL": "rear_left_wheel",
		"Wheel_RR": "rear_right_wheel",
	}
	var spring_f := v.front_spring_length
	var spring_r := v.rear_spring_length

	for wname: String in wheel_map.keys():
		var w_src := model_root.get_node_or_null(wname) as Node3D
		var is_front: bool = wname.ends_with("FL") or wname.ends_with("FR")
		var sp_len := spring_f if is_front else spring_r

		var w_ray := preload("res://addons/gevp/scripts/wheel.gd").new()
		w_ray.name = wname
		w_ray.collision_mask = 1  # ONLY collide RayCast3D with Road/Grass terrain!
		w_ray.position = (w_src.position if w_src else Vector3.ZERO) + Vector3(0.0, sp_len * 0.5, 0.0)
		v.add_child(w_ray)

		var w_node := Node3D.new()
		w_node.name = "WheelSpin"
		w_ray.add_child(w_node)
		w_ray.wheel_node = w_node

		var knuckle := Node3D.new()
		knuckle.name = "WheelKnuckle"
		w_ray.add_child(knuckle)
		v.caliper_links.append({"wheel_node": w_node, "knuckle": knuckle})

		if w_src:
			# Move children (e.g. Wheel_*_Caliper) first
			for child in w_src.get_children():
				w_src.remove_child(child)
				_clear_owners(child)
				if "Caliper" in child.name:
					knuckle.add_child(child)
				else:
					w_node.add_child(child)
			# v3.0 .glb exports Wheel_FL itself as a MeshInstance3D containing tire + spokes + rotor!
			if w_src is MeshInstance3D:
				w_src.get_parent().remove_child(w_src)
				_clear_owners(w_src)
				w_src.position = Vector3.ZERO
				w_src.rotation = Vector3.ZERO
				w_node.add_child(w_src)
			else:
				w_src.queue_free()

		v.set(wheel_map[wname], w_ray)

	# Rear tire smoke emitters
	if role == "player" or role == "racer":
		for rl_name in ["Wheel_RL", "Wheel_RR"]:
			var wr := v.get_node_or_null(rl_name) as Node3D
			if wr:
				var sp := CPUParticles3D.new()
				sp.emitting = false
				sp.amount = 14
				sp.lifetime = 0.65
				sp.local_coords = false
				sp.gravity = Vector3(0, 1.4, 0)
				sp.initial_velocity_min = 0.6
				sp.initial_velocity_max = 1.8
				var sm := SphereMesh.new(); sm.radius = 0.22; sm.height = 0.44
				var pmat := StandardMaterial3D.new()
				pmat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
				pmat.albedo_color = Color(0.86, 0.86, 0.88, 0.35)
				pmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
				sm.material = pmat
				sp.mesh = sm
				sp.position = Vector3(0, -0.25, 0)
				wr.add_child(sp)
				v.smoke_particles.append(sp)

	# Reparent remaining Body_Shell & parts onto Vehicle
	for child in model_root.get_children():
		model_root.remove_child(child)
		_clear_owners(child)
		v.add_child(child)
	model_root.queue_free()

	# Inspect Body_Shell children for lights, police strobes, and detachable crash parts
	_wire_car_materials_and_lights(v, cfg)

	# NOS exhaust flame cones at rear
	if role == "player":
		var fmat := StandardMaterial3D.new()
		fmat.albedo_color = Color(0.25, 0.72, 1.0)
		fmat.emission_enabled = true
		fmat.emission = Color(0.15, 0.75, 1.0)
		fmat.emission_energy_multiplier = 4.8
		fmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		for sx in [-0.42, 0.42]:
			var flame := MeshInstance3D.new()
			var cm := CylinderMesh.new(); cm.top_radius = 0.01; cm.bottom_radius = 0.09; cm.height = 0.72
			flame.mesh = cm
			flame.rotation_degrees = Vector3(-90, 0, 0)
			flame.position = Vector3(sx, 0.23, L * 0.52 + 0.34)
			flame.material_override = fmat
			flame.visible = false
			v.add_child(flame)
			v.nos_flames.append(flame)

	# Audio players
	if add_sound:
		var eng := preload("res://addons/gevp/scripts/engine_sound.gd").new()
		eng.vehicle = v
		eng.sample_rpm = 4000.0
		eng.stream = _load_wav("res://addons/gevp/sounds/4000.wav", true)
		eng.max_distance = 75.0
		eng.unit_size = 6.0 if role == "player" else 3.5
		eng.volume_db = -4.0 if role == "player" else -12.0
		eng.autoplay = true
		v.add_child(eng)

		if role == "player":
			v.screech_player = AudioStreamPlayer3D.new()
			v.screech_player.stream = _load_wav("res://assets/audio/tire_screech.wav", true)
			v.screech_player.max_distance = 55.0
			v.add_child(v.screech_player)

			v.nos_player = AudioStreamPlayer3D.new()
			v.nos_player.stream = _load_wav("res://assets/audio/nos_boost.wav", true)
			v.nos_player.volume_db = -3.0
			v.add_child(v.nos_player)

		v.crash_player = AudioStreamPlayer3D.new()
		v.crash_player.stream = _load_wav("res://assets/audio/crash_impact.wav", false)
		v.crash_player.max_distance = 80.0
		v.add_child(v.crash_player)

		if role == "police":
			v.siren_player = AudioStreamPlayer3D.new()
			v.siren_player.stream = _load_wav("res://assets/audio/siren_dps.wav", true)
			v.siren_player.max_distance = 135.0
			v.siren_player.unit_size = 9.0
			v.siren_player.volume_db = -3.0
			v.add_child(v.siren_player)

			v.police_light = OmniLight3D.new()
			v.police_light.omni_range = 16.0
			v.police_light.light_energy = 0.0
			v.police_light.position = Vector3(0.0, 1.85, 0.25)
			v.add_child(v.police_light)

	return v

static func _clear_owners(n: Node) -> void:
	n.owner = null
	for c in n.get_children():
		_clear_owners(c)

static func _wire_car_materials_and_lights(v: MamadyshVehicle, cfg: Dictionary) -> void:
	var stack := [v]
	while stack.size() > 0:
		var n: Node = stack.pop_back()
		for c in n.get_children():
			stack.append(c)
		if n is MeshInstance3D:
			var nm := n.name
			if nm == "FrontBumper" or nm == "RearBumper" or nm == "Spoiler" or nm.begins_with("MirrorCap"):
				v.detachable_parts.append(n)
			if nm.begins_with("Headlight") or nm.begins_with("DRL"):
				var mat := _unique_std_mat(n, Color(0.95, 0.96, 1.0))
				mat.emission_enabled = true
				mat.emission = Color(0.92, 0.95, 1.0)
				mat.emission_energy_multiplier = 0.25
				v.headlight_mats.append(mat)
			elif nm.begins_with("Taillight_Red"):
				var mat := _unique_std_mat(n, Color(0.85, 0.06, 0.06))
				mat.emission_enabled = true
				mat.emission = Color(1.0, 0.08, 0.06)
				mat.emission_energy_multiplier = 0.0
				v.taillight_mats.append(mat)
			elif nm == "Lightbar_Red":
				v.police_red_mat = _unique_std_mat(n, Color(0.92, 0.08, 0.08))
				v.police_red_mat.emission_enabled = true
				v.police_red_mat.emission = Color(1.0, 0.1, 0.08)
				v.police_red_mat.emission_energy_multiplier = 0.0
			elif nm == "Lightbar_Blue":
				v.police_blue_mat = _unique_std_mat(n, Color(0.08, 0.35, 0.98))
				v.police_blue_mat.emission_enabled = true
				v.police_blue_mat.emission = Color(0.12, 0.45, 1.0)
				v.police_blue_mat.emission_energy_multiplier = 0.0

	if v.is_player or v.is_police:
		var L := float(cfg["length"])
		var H := float(cfg["height"])
		for sx in [-0.55, 0.55]:
			var sl := SpotLight3D.new()
			sl.spot_range = 46.0
			sl.spot_angle = 38.0
			sl.spot_attenuation = 1.4
			sl.light_color = Color(1.0, 0.96, 0.86)
			sl.light_energy = 0.0
			sl.position = Vector3(sx, H * 0.48, -L * 0.48)
			v.add_child(sl)
			v.headlights_spots.append(sl)

		# Subtle rear reverse light cones/glow
		var rmat := StandardMaterial3D.new()
		rmat.albedo_color = Color(0.95, 0.97, 1.0)
		rmat.emission_enabled = true
		rmat.emission = Color(1.0, 0.98, 0.92)
		rmat.emission_energy_multiplier = 0.0
		v.reverse_mat = rmat
		for sx in [-0.46, 0.46]:
			var rl := MeshInstance3D.new()
			var bm := BoxMesh.new(); bm.size = Vector3(0.14, 0.055, 0.025)
			rl.mesh = bm
			rl.position = Vector3(sx, H * 0.45, L * 0.506)
			rl.material_override = rmat
			v.add_child(rl)

static func _unique_std_mat(mi: MeshInstance3D, fallback_col: Color) -> StandardMaterial3D:
	var m: Material = mi.get_active_material(0)
	if m is StandardMaterial3D:
		var dup := (m as StandardMaterial3D).duplicate() as StandardMaterial3D
		mi.set_surface_override_material(0, dup)
		return dup
	var sm := StandardMaterial3D.new()
	sm.albedo_color = fallback_col
	mi.material_override = sm
	return sm
