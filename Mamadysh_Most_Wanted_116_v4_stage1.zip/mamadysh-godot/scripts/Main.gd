extends Node3D

var world: MamadyshWorld
var atmosphere: AtmosphereManager
var camera_rig: CameraRig
var manager: PursuitAndRaceManager
var hud: GameHUD
var vehicles_root: Node3D

var selected_car_id := "lada_vesta_sport"
var showroom_root: Node3D
var showroom_car: Node3D
var player_car: MamadyshVehicle
var player_ctrl: PlayerCarController

func _ready() -> void:
	world = MamadyshWorld.new()
	world.name = "MamadyshWorld"
	add_child(world)
	world.build_world(false, "race")

	vehicles_root = Node3D.new()
	vehicles_root.name = "Vehicles"
	add_child(vehicles_root)

	camera_rig = CameraRig.new()
	camera_rig.name = "CameraRig"
	add_child(camera_rig)
	camera_rig.make_current()

	atmosphere = AtmosphereManager.new()
	atmosphere.name = "AtmosphereManager"
	add_child(atmosphere)
	atmosphere.setup(self, world, camera_rig)

	manager = PursuitAndRaceManager.new()
	manager.name = "PursuitAndRaceManager"
	add_child(manager)
	manager.setup(vehicles_root, world)

	hud = GameHUD.new()
	hud.name = "GameHUD"
	add_child(hud)
	hud.build_ui()
	hud.minimap.setup(world, manager)
	hud.set_atmosphere_label(atmosphere.get_mode_label())

	hud.car_selected.connect(_on_car_selected)
	hud.circuit_selected.connect(_on_circuit_selected)
	hud.start_requested.connect(_on_start_requested)
	hud.atmosphere_cycled.connect(_on_atmosphere_cycled)
	hud.camera_cycled.connect(_on_camera_cycled)
	hud.reset_car_requested.connect(_on_reset_car)
	hud.back_to_garage_requested.connect(_enter_garage)

	manager.hud_event.connect(func(msg: String, col: Color): hud.show_banner(msg, col))
	manager.state_changed.connect(func(_st, summary: Dictionary): hud.show_result(summary))

	_build_showroom()
	_enter_garage()

func _build_showroom() -> void:
	showroom_root = Node3D.new()
	showroom_root.name = "ShowroomPodium"
	# Scenic Victory Park plaza right beside Mamadysh Eiffel Tower & 1941-1945 Memorial!
	var sx := 744.0; var sz := 22.0
	var sy := world.sample_terrain_h(sx, sz) + 0.35
	showroom_root.position = Vector3(sx, sy, sz)
	add_child(showroom_root)

	var podium := MeshInstance3D.new()
	var cm := CylinderMesh.new(); cm.top_radius = 3.8; cm.bottom_radius = 4.1; cm.height = 0.25
	podium.mesh = cm; podium.position = Vector3(0, -0.125, 0)
	var pmat := StandardMaterial3D.new(); pmat.albedo_color = Color(0.10, 0.12, 0.16); pmat.metallic = 0.72; pmat.roughness = 0.26
	podium.material_override = pmat; showroom_root.add_child(podium)

	var spot := OmniLight3D.new(); spot.light_color = Color(1.0, 0.94, 0.85); spot.light_energy = 2.6; spot.omni_range = 14.0
	spot.position = Vector3(0, 4.0, 0); showroom_root.add_child(spot)

func _spawn_showroom_car(car_id: String) -> void:
	if is_instance_valid(showroom_car): showroom_car.queue_free()
	var cfg := CarCatalog.get_car(car_id)
	var ps := load(cfg["glb"]) as PackedScene
	showroom_car = ps.instantiate()
	VehicleFactory.finish_showroom_model(showroom_car)
	showroom_car.rotation_degrees = Vector3(0, 145, 0)
	showroom_root.add_child(showroom_car)

func _enter_garage() -> void:
	Engine.time_scale = 1.0
	manager.clear_entities()
	manager.state = PursuitAndRaceManager.State.IDLE
	if is_instance_valid(player_car): player_car.queue_free(); player_car = null
	if is_instance_valid(player_ctrl): player_ctrl.queue_free(); player_ctrl = null

	showroom_root.visible = true
	_spawn_showroom_car(selected_car_id)
	camera_rig.set_garage_target(showroom_root.global_position)
	hud.show_garage()

func _on_car_selected(car_id: String) -> void:
	selected_car_id = car_id
	if showroom_root.visible:
		_spawn_showroom_car(car_id)

func _on_circuit_selected(circuit_id: String) -> void:
	world.set_active_circuit(circuit_id)
	hud.minimap.refresh_map_cache()

func _on_start_requested(game_mode: PursuitAndRaceManager.GameMode) -> void:
	Engine.time_scale = 1.0
	showroom_root.visible = false
	if is_instance_valid(showroom_car): showroom_car.queue_free(); showroom_car = null
	if is_instance_valid(player_car): player_car.queue_free()
	if is_instance_valid(player_ctrl): player_ctrl.queue_free()

	player_car = VehicleFactory.create_vehicle(selected_car_id, "player", true)
	player_car.transform = world.spawn_transform
	player_car.crashed.connect(func(imp: float, _other):
		if imp > 2400.0:
			camera_rig.add_shake(clampf(imp / 14000.0, 0.15, 0.9))
	)
	vehicles_root.add_child(player_car)

	player_ctrl = PlayerCarController.new()
	player_ctrl.vehicle = player_car
	add_child(player_ctrl)

	camera_rig.bind_vehicle(player_car)
	var is_night := atmosphere.current_mode == AtmosphereManager.TimeMode.NIGHT_RAIN
	manager.start_session(game_mode, player_car, player_ctrl, is_night)
	hud.bind_session(player_car, player_ctrl, manager)
	hud.show_hud()

func _on_atmosphere_cycled() -> void:
	atmosphere.cycle_mode()
	var lbl := atmosphere.get_mode_label()
	hud.set_atmosphere_label(lbl)
	if not showroom_root.visible:
		hud.show_banner("ПОГОДА: " + lbl, Color(0.55, 0.85, 1.0))

func _on_camera_cycled() -> void:
	var lbl := camera_rig.cycle_view()
	hud.set_camera_label(lbl)
	hud.show_banner(lbl, Color(0.85, 0.92, 1.0))

func _on_reset_car() -> void:
	if not is_instance_valid(player_car) or not is_instance_valid(world):
		return
	var tr := world.get_nearest_road_transform(player_car.global_position)
	player_car.global_transform = tr
	manager.clear_player_gate_sample()
	player_car.linear_velocity = Vector3.ZERO
	player_car.angular_velocity = Vector3.ZERO
	hud.show_banner("АВТО ВОЗВРАЩЕНО НА ДОРОГУ", Color(1.0, 0.84, 0.28))
