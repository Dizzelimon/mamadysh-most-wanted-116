extends Node
class_name AtmosphereManager

enum TimeMode { DAY, SUNSET, NIGHT_RAIN }

var current_mode: TimeMode = TimeMode.SUNSET
var world_env: WorldEnvironment
var sun_light: DirectionalLight3D
var rain_particles: GPUParticles3D
var mamadysh_world: MamadyshWorld
var tracked_camera: Camera3D

var _sky_mat: ProceduralSkyMaterial
var _env: Environment

func setup(parent: Node3D, world: MamadyshWorld, cam: Camera3D) -> void:
	mamadysh_world = world
	tracked_camera = cam

	world_env = WorldEnvironment.new()
	_env = Environment.new()
	_sky_mat = ProceduralSkyMaterial.new()
	var sky := Sky.new()
	sky.sky_material = _sky_mat
	_env.background_mode = Environment.BG_SKY
	_env.sky = sky
	_env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	_env.tonemap_mode = Environment.TONE_MAPPER_ACES
	_env.glow_enabled = false # Mobile: bloom is expensive; keep lighting and fog
	_env.glow_intensity = 0.55
	_env.glow_bloom = 0.18
	_env.fog_enabled = true
	world_env.environment = _env
	parent.add_child(world_env)

	sun_light = DirectionalLight3D.new()
	sun_light.shadow_enabled = true
	sun_light.shadow_bias = 0.04
	sun_light.directional_shadow_max_distance = 120.0
	parent.add_child(sun_light)

	_build_rain(parent)
	apply_mode(current_mode)

func _build_rain(parent: Node3D) -> void:
	rain_particles = GPUParticles3D.new()
	rain_particles.amount = 260
	rain_particles.lifetime = 0.85
	rain_particles.visibility_aabb = AABB(Vector3(-25, -10, -25), Vector3(50, 35, 50))
	var pm := ParticleProcessMaterial.new()
	pm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
	pm.emission_box_extents = Vector3(22.0, 2.0, 22.0)
	pm.direction = Vector3(0.08, -1.0, 0.05)
	pm.spread = 4.0
	pm.initial_velocity_min = 24.0
	pm.initial_velocity_max = 30.0
	pm.gravity = Vector3(0.0, -9.8, 0.0)
	rain_particles.process_material = pm

	var streak := BoxMesh.new()
	streak.size = Vector3(0.025, 0.72, 0.025)
	var smat := StandardMaterial3D.new()
	smat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	smat.albedo_color = Color(0.75, 0.85, 1.0, 0.48)
	smat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	streak.material = smat
	rain_particles.draw_pass_1 = streak
	rain_particles.emitting = false
	parent.add_child(rain_particles)

func _process(_delta: float) -> void:
	if is_instance_valid(rain_particles) and is_instance_valid(tracked_camera) and rain_particles.emitting:
		rain_particles.global_position = tracked_camera.global_position + Vector3(0.0, 14.0, 0.0)

func cycle_mode() -> TimeMode:
	var nxt := (int(current_mode) + 1) % 3
	apply_mode(nxt as TimeMode)
	return current_mode

func apply_mode(mode: TimeMode) -> void:
	current_mode = mode
	match mode:
		TimeMode.DAY:
			_sky_mat.sky_top_color = Color(0.18, 0.46, 0.84)
			_sky_mat.sky_horizon_color = Color(0.68, 0.82, 0.94)
			_sky_mat.ground_bottom_color = Color(0.16, 0.20, 0.14)
			_sky_mat.ground_horizon_color = Color(0.60, 0.74, 0.82)
			_env.ambient_light_energy = 0.82
			_env.fog_light_color = Color(0.72, 0.84, 0.94)
			_env.fog_density = 0.00048
			sun_light.rotation_degrees = Vector3(-52, -32, 0)
			sun_light.light_color = Color(1.0, 0.97, 0.91)
			sun_light.light_energy = 1.45
			rain_particles.emitting = false
			if is_instance_valid(mamadysh_world):
				mamadysh_world.set_night_state(false, false)
		TimeMode.SUNSET:
			_sky_mat.sky_top_color = Color(0.24, 0.18, 0.36)
			_sky_mat.sky_horizon_color = Color(0.95, 0.50, 0.22)
			_sky_mat.ground_bottom_color = Color(0.18, 0.12, 0.09)
			_sky_mat.ground_horizon_color = Color(0.84, 0.44, 0.22)
			_env.ambient_light_energy = 0.72
			_env.fog_light_color = Color(0.88, 0.52, 0.28)
			_env.fog_density = 0.00072
			sun_light.rotation_degrees = Vector3(-16, 128, 0)
			sun_light.light_color = Color(1.0, 0.64, 0.30)
			sun_light.light_energy = 1.65
			rain_particles.emitting = false
			if is_instance_valid(mamadysh_world):
				mamadysh_world.set_night_state(false, false)
		TimeMode.NIGHT_RAIN:
			_sky_mat.sky_top_color = Color(0.02, 0.04, 0.09)
			_sky_mat.sky_horizon_color = Color(0.08, 0.14, 0.24)
			_sky_mat.ground_bottom_color = Color(0.02, 0.03, 0.05)
			_sky_mat.ground_horizon_color = Color(0.07, 0.12, 0.20)
			_env.ambient_light_energy = 0.46
			_env.fog_light_color = Color(0.09, 0.15, 0.26)
			_env.fog_density = 0.0016
			sun_light.rotation_degrees = Vector3(-42, 48, 0)
			sun_light.light_color = Color(0.42, 0.56, 0.84)
			sun_light.light_energy = 0.42
			rain_particles.emitting = true
			if is_instance_valid(mamadysh_world):
				mamadysh_world.set_night_state(true, true)

	for node in get_tree().get_nodes_in_group("vehicles_headlights"):
		if node is MamadyshVehicle:
			node.set_headlights_night(mode == TimeMode.NIGHT_RAIN)

func get_mode_label() -> String:
	match current_mode:
		TimeMode.DAY:
			return "ДЕНЬ"
		TimeMode.SUNSET:
			return "ЗАКАТ"
		TimeMode.NIGHT_RAIN:
			return "НОЧЬ / ДОЖДЬ"
	return "ЗАКАТ"
