extends Node
class_name PursuitAndRaceManager

enum GameMode { FREE_ROAM, RACE, PURSUIT }
enum State { IDLE, COUNTDOWN, ACTIVE, BUSTED, EVADED, RACE_DONE }

signal hud_event(msg: String, color: Color)
signal state_changed(new_state: State, summary: Dictionary)

var world: MamadyshWorld
var player: MamadyshVehicle
var player_ctrl: PlayerCarController
var mode: GameMode = GameMode.RACE
var state: State = State.IDLE

var racers: Array[MamadyshVehicle] = []
var cops: Array[MamadyshVehicle] = []
var traffic: Array[MamadyshVehicle] = []
var vehicles_root: Node3D

var bounty := 0
var heat_level := 0
var bust_meter := 0.0
var evade_meter := 0.0
var takedowns := 0

var current_lap := 1
var total_laps := 1
var next_cp_idx := 1
var race_time := 0.0
var countdown_timer := 0.0
var _last_countdown_int := 4

var _cp_gate: Node3D
var _beep_player: AudioStreamPlayer
var _go_player: AudioStreamPlayer
var _roadblock_timer := 10.0
var _cop_spawn_timer := 4.0
var _bounty_tick := 0.0
var _water_timer := 0.0
var _is_night := false

func setup(v_root: Node3D, w: MamadyshWorld) -> void:
	vehicles_root = v_root
	world = w

	_beep_player = AudioStreamPlayer.new()
	_beep_player.stream = load("res://assets/audio/countdown_beep.wav")
	_beep_player.volume_db = -4.0
	add_child(_beep_player)

	_go_player = AudioStreamPlayer.new()
	_go_player.stream = load("res://assets/audio/countdown_go.wav")
	_go_player.volume_db = -3.0
	add_child(_go_player)

	_build_checkpoint_gate()

func _build_checkpoint_gate() -> void:
	_cp_gate = Node3D.new()
	var gmat := StandardMaterial3D.new()
	gmat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	gmat.albedo_color = Color(1.0, 0.72, 0.12, 0.48)
	gmat.emission_enabled = true; gmat.emission = Color(1.0, 0.72, 0.15); gmat.emission_energy_multiplier = 2.6
	gmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	for sx in [-7.0, 7.0]:
		var p := MeshInstance3D.new(); var cm := CylinderMesh.new(); cm.top_radius = 0.3; cm.bottom_radius = 0.45; cm.height = 6.5
		p.mesh = cm; p.position = Vector3(sx, 3.25, 0); p.material_override = gmat; _cp_gate.add_child(p)
	var bar := MeshInstance3D.new(); var bm := BoxMesh.new(); bm.size = Vector3(14.6, 0.65, 0.65)
	bar.mesh = bm; bar.position = Vector3(0, 6.2, 0); bar.material_override = gmat; _cp_gate.add_child(bar)
	_cp_gate.visible = false
	add_child(_cp_gate)

func clear_entities() -> void:
	for arr in [racers, cops, traffic]:
		for v in arr:
			if is_instance_valid(v): v.queue_free()
		arr.clear()
	if is_instance_valid(world): world.clear_roadblocks()
	_cp_gate.visible = false

func start_session(selected_mode: GameMode, p_vehicle: MamadyshVehicle, p_ctrl: PlayerCarController, is_night: bool) -> void:
	clear_entities()
	mode = selected_mode
	player = p_vehicle
	player_ctrl = p_ctrl
	_is_night = is_night

	bounty = 0
	heat_level = 1 if mode == GameMode.PURSUIT else 0
	bust_meter = 0.0
	evade_meter = 0.0
	takedowns = 0
	current_lap = 1
	total_laps = 1
	next_cp_idx = 1
	race_time = 0.0
	_roadblock_timer = 14.0
	_cop_spawn_timer = 3.5
	_water_timer = 0.0

	player.crashed.connect(_on_player_crash)
	player.set_headlights_night(is_night)
	player.add_to_group("vehicles_headlights")

	_spawn_traffic(5)

	if mode == GameMode.RACE:
		_spawn_racers(p_vehicle.car_cfg["id"])
		_update_checkpoint_gate()
		player_ctrl.controls_locked = true
		state = State.COUNTDOWN
		countdown_timer = 3.4
		_last_countdown_int = 4
	elif mode == GameMode.PURSUIT:
		player_ctrl.controls_locked = false
		state = State.ACTIVE
		_spawn_police(1, 65.0)
		_spawn_police(1, -60.0)
		hud_event.emit("ПОГОНЯ ДПС • УРОВЕНЬ ЖАРА 1!", Color(1.0, 0.32, 0.28))
	else:
		player_ctrl.controls_locked = false
		state = State.ACTIVE
		_spawn_police(1, 220.0)
		hud_event.emit("СВОБОДНАЯ ЕЗДА ПО МАМАДЫШУ", Color(0.45, 0.88, 1.0))

func _spawn_traffic(count: int) -> void:
	var pool := ["vaz_2107", "gaz_3110_volga", "lada_niva", "lada_priora", "uaz_patriot"]
	var L := world.get_track_length()
	for i in range(count):
		var cid: String = pool[i % pool.size()]
		var v := VehicleFactory.create_vehicle(cid, "traffic", false)
		var d := fmod(140.0 + float(i) * (L / float(count)), L)
		var tr := world.sample_track(d)
		v.transform = tr
		v.position += tr.basis.x * 2.8 + Vector3(0, 0.35, 0)
		v.set_headlights_night(_is_night)
		v.add_to_group("vehicles_headlights")

		var ai := AICarDriver.new(); ai.vehicle = v; ai.world = world; ai.role = AICarDriver.Role.TRAFFIC
		ai.target_speed_ms = 14.5
		v.add_child(ai)
		vehicles_root.add_child(v); traffic.append(v)

func _spawn_racers(player_car_id: String) -> void:
	var candidates := ["lada_vesta_sport", "lada_priora", "gaz_3110_volga", "vaz_2107"]
	var picks: Array[String] = []
	for c in candidates:
		if c != player_car_id and picks.size() < 2: picks.append(c)
	var offsets := [Vector2(-2.8, -6.5), Vector2(2.8, -12.5)]
	for i in range(picks.size()):
		var v := VehicleFactory.create_vehicle(picks[i], "racer", true)
		var tr := world.sample_track(world.get_track_length() + offsets[i].y)
		v.transform = tr; v.position += tr.basis.x * offsets[i].x + Vector3(0, 0.35, 0)
		v.set_headlights_night(_is_night); v.add_to_group("vehicles_headlights")
		var ai := AICarDriver.new(); ai.vehicle = v; ai.world = world; ai.role = AICarDriver.Role.RACER
		ai.lane_offset = offsets[i].x * 0.45; ai.target_speed_ms = 39.0 + float(i) * 3.5; ai.active = false
		v.add_child(ai); vehicles_root.add_child(v); racers.append(v)

func _spawn_police(count: int, ahead_dist := 75.0) -> void:
	if not is_instance_valid(player): return
	var avoid: Array[Vector3] = [player.global_position]
	for arr in [cops, racers, traffic]:
		for v in arr:
			if is_instance_valid(v): avoid.append(v.global_position)
	var min_d := clampf(absf(ahead_dist) * 0.75, 50.0, 140.0)
	var max_d := min_d + 65.0
	for i in range(count):
		var v := VehicleFactory.create_vehicle("dps_patrol", "police", true)
		var tr := world.get_street_spawn_near(player.global_position, min_d, max_d, player.global_position, avoid)
		avoid.append(tr.origin)
		v.transform = tr
		v.siren_active = (heat_level > 0); v.set_headlights_night(_is_night); v.add_to_group("vehicles_headlights")
		var ai := AICarDriver.new(); ai.vehicle = v; ai.world = world; ai.target_vehicle = player
		ai.role = AICarDriver.Role.POLICE
		ai.cop_state = AICarDriver.CopState.PURSUIT if heat_level > 0 else AICarDriver.CopState.PATROL
		v.add_child(ai); vehicles_root.add_child(v); cops.append(v)

func _on_player_crash(imp: float, other: Node) -> void:
	if state != State.ACTIVE or not is_instance_valid(player): return
	if other is MamadyshVehicle:
		var ov := other as MamadyshVehicle
		if ov.is_police:
			if heat_level == 0:
				heat_level = 1; hud_event.emit("ПРОВОКАЦИЯ ДПС! НАЧАТА ПОГОНЯ!", Color(1.0, 0.3, 0.25))
			if imp * player.ram_power > 5000.0:
				takedowns += 1; bounty += 2500
				hud_event.emit("ТАРАН ДПС! +2 500 ₽ РЕЙТИНГА", Color(1.0, 0.82, 0.2))
				_disable_cop_temporarily(ov)
		else: bounty += 250
	elif other is RigidBody3D: bounty += 150

func _disable_cop_temporarily(cop: MamadyshVehicle) -> void:
	for c in cop.get_children():
		if c is AICarDriver:
			c.active = false; cop.siren_active = false
			get_tree().create_timer(7.0).timeout.connect(func():
				if is_instance_valid(c) and is_instance_valid(cop):
					c.active = true; cop.siren_active = heat_level > 0
			)

func _update_checkpoint_gate() -> void:
	if world.checkpoint_positions.is_empty(): return
	var cp := world.checkpoint_positions[next_cp_idx % world.checkpoint_positions.size()]
	_cp_gate.global_transform = cp["transform"]
	_cp_gate.visible = (mode == GameMode.RACE and state == State.ACTIVE)

func _process(delta: float) -> void:
	if state == State.COUNTDOWN:
		countdown_timer -= delta
		var c_int := ceili(countdown_timer)
		if c_int != _last_countdown_int and c_int >= 1 and c_int <= 3:
			_last_countdown_int = c_int; _beep_player.play()
			hud_event.emit(str(c_int), Color(1.0, 0.86, 0.22))
		if countdown_timer <= 0.0:
			_go_player.play(); state = State.ACTIVE; player_ctrl.controls_locked = false
			for r in racers:
				for ch in r.get_children():
					if ch is AICarDriver: ch.active = true
			_update_checkpoint_gate(); hud_event.emit("СТАРТ!", Color(0.28, 1.0, 0.45))
		return

	if state != State.ACTIVE or not is_instance_valid(player): return

	var unscaled_dt := delta / maxf(Engine.time_scale, 0.1)
	race_time += unscaled_dt

	# Water hazard recovery: if car splashes into Vyatka or Oshma, recover onto nearest road!
	if world.is_in_water(player.global_position):
		_water_timer += unscaled_dt
		if _water_timer > 0.45:
			_water_timer = 0.0
			var tr := world.get_nearest_road_transform(player.global_position)
			player.global_transform = tr
			player.linear_velocity = Vector3.ZERO; player.angular_velocity = Vector3.ZERO
			hud_event.emit("ВЫЕЗД В РЕКУ! ЭВАКУАЦИЯ НА БЕРЕГ", Color(0.35, 0.85, 1.0))
	else:
		_water_timer = 0.0

	# Race Checkpoints
	if mode == GameMode.RACE and not world.checkpoint_positions.is_empty():
		var target_cp := world.checkpoint_positions[next_cp_idx]
		if player.global_position.distance_to(target_cp["pos"]) < 19.0:
			if next_cp_idx == 0:
				if current_lap >= total_laps:
					_finish_race(); return
				current_lap += 1; bounty += 1500
				hud_event.emit("КРУГ %d / %d" % [current_lap, total_laps], Color(1.0, 0.88, 0.25))
				next_cp_idx = 1
			else:
				next_cp_idx = (next_cp_idx + 1) % world.checkpoint_positions.size()
			_update_checkpoint_gate()

	if heat_level > 0 or mode == GameMode.PURSUIT:
		_process_pursuit(unscaled_dt)

func _process_pursuit(dt: float) -> void:
	_bounty_tick += dt
	if _bounty_tick >= 1.0:
		_bounty_tick = 0.0
		if player.speed > 18.0:
			bounty += int(player.speed * 4.5) * max(1, heat_level)

	var desired_heat := clampi(1 + int(bounty / 4500), 1, 5)
	if desired_heat > heat_level:
		heat_level = desired_heat
		hud_event.emit("УРОВЕНЬ ЖАРА ДПС: %d ★" % heat_level, Color(1.0, 0.28, 0.24))

	var target_cops := clampi(heat_level, 1, 3)
	_cop_spawn_timer -= dt
	if cops.size() < target_cops and _cop_spawn_timer <= 0.0:
		_cop_spawn_timer = 7.0
		_spawn_police(1, 95.0)

	if heat_level >= 2:
		_roadblock_timer -= dt
		if _roadblock_timer <= 0.0:
			_roadblock_timer = maxf(12.0, 24.0 - float(heat_level) * 2.5)
			var ahead_pos := player.global_position - player.global_transform.basis.z * 135.0
			var tr := world.get_nearest_road_transform(ahead_pos)
			world.spawn_roadblock_at_pos(tr.origin, -tr.basis.z)
			hud_event.emit("ВНИМАНИЕ: ВПЕРЕДИ БЛОКПОСТ ДПС!", Color(1.0, 0.55, 0.15))

	var nearest := 9999.0
	for c in cops:
		if is_instance_valid(c):
			var d := c.global_position.distance_to(player.global_position)
			if d < nearest: nearest = d
			if d > 280.0 and mode == GameMode.PURSUIT:
				var behind_pos := player.global_position + player.global_transform.basis.z * 90.0
				var tr := world.get_nearest_road_transform(behind_pos)
				c.global_transform = tr; c.global_position += Vector3(0, 0.4, 0)
				c.linear_velocity = -tr.basis.z * 24.0

	if nearest < 13.5 and player.get_speed_kmh() < 14:
		bust_meter = minf(1.0, bust_meter + dt / 4.2)
		evade_meter = maxf(0.0, evade_meter - dt * 0.5)
		if bust_meter >= 1.0: _trigger_busted()
	elif nearest > 115.0:
		bust_meter = maxf(0.0, bust_meter - dt * 0.6)
		evade_meter = minf(1.0, evade_meter + dt / 7.5)
		if evade_meter >= 1.0 and mode == GameMode.PURSUIT: _trigger_evaded()
	else:
		bust_meter = maxf(0.0, bust_meter - dt * 0.35)
		evade_meter = maxf(0.0, evade_meter - dt * 0.35)

func _finish_race() -> void:
	state = State.RACE_DONE; player_ctrl.controls_locked = true; bounty += 5000
	state_changed.emit(State.RACE_DONE, {"title": "ФИНИШ В МАМАДЫШЕ!", "subtitle": "Время: %.1f сек • Трасса пройдена" % race_time, "bounty": bounty})

func _trigger_busted() -> void:
	state = State.BUSTED; player_ctrl.controls_locked = true
	state_changed.emit(State.BUSTED, {"title": "АРЕСТОВАН ДПС (116 RUS)", "subtitle": "Полиция Мамадыша заблокировала ваш автомобиль", "bounty": bounty})

func _trigger_evaded() -> void:
	state = State.EVADED; player_ctrl.controls_locked = true; bounty += heat_level * 3000
	state_changed.emit(State.EVADED, {"title": "УШЁЛ ОТ ПОГОНИ!", "subtitle": "Вы оторвались от патрулей ДПС (Уровень жара %d)" % heat_level, "bounty": bounty})
