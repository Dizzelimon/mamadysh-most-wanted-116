extends RefCounted
class_name TextureBank

static var _cache: Dictionary = {}
static var _mats: Dictionary = {}

static func _tex(path: String) -> Texture2D:
	if _cache.has(path):
		return _cache[path]
	if not ResourceLoader.exists(path):
		_cache[path] = null
		return null
	var t := load(path) as Texture2D
	_cache[path] = t
	return t

static func pbr_mat(key: String, repeat_scale := 1.0, triplanar := false, emission_strength := 0.0) -> StandardMaterial3D:
	var cache_key := "%s_%.2f_%s_%.2f" % [key, repeat_scale, str(triplanar), emission_strength]
	if _mats.has(cache_key):
		return _mats[cache_key]

	var m := StandardMaterial3D.new()
	var base := "res://assets/textures/" + key
	var c_tex := _tex(base + "_color.jpg")
	if c_tex:
		m.albedo_texture = c_tex
	var n_tex := _tex(base + "_normal.jpg")
	if n_tex:
		m.normal_enabled = true
		m.normal_texture = n_tex
		m.normal_scale = 0.85
	var r_tex := _tex(base + "_roughness.jpg")
	if r_tex:
		m.roughness_texture = r_tex
		m.roughness = 1.0
	else:
		m.roughness = 0.82

	var em_path := base + "_emission.png"
	if ResourceLoader.exists(em_path):
		var e_tex := _tex(em_path)
		if e_tex:
			m.emission_enabled = true
			m.emission_texture = e_tex
			m.emission_energy_multiplier = emission_strength
			m.emission = Color(1.0, 0.88, 0.65)

	if triplanar:
		m.uv1_triplanar = true
		m.uv1_world_triplanar = true
		m.uv1_scale = Vector3(repeat_scale, repeat_scale, repeat_scale)
	else:
		m.uv1_scale = Vector3(repeat_scale, repeat_scale, 1.0)

	_mats[cache_key] = m
	return m

static func road_material(is_wet := false) -> StandardMaterial3D:
	var key := "road_main_wet" if is_wet else "road_main_dry"
	if _mats.has(key):
		return _mats[key]
	var m := StandardMaterial3D.new()
	m.albedo_texture = _tex("res://assets/textures/road_main_color.jpg")
	m.normal_enabled = true
	m.normal_texture = _tex("res://assets/textures/road_main_normal.jpg")
	m.normal_scale = 0.6 if is_wet else 0.9
	m.roughness_texture = _tex("res://assets/textures/road_main_roughness.jpg")
	m.roughness = 0.24 if is_wet else 0.88
	m.metallic = 0.14 if is_wet else 0.0
	m.albedo_color = Color(0.72, 0.76, 0.82) if is_wet else Color.WHITE
	_mats[key] = m
	return m

static func curb_redwhite_material() -> StandardMaterial3D:
	if _mats.has("curb_rw"):
		return _mats["curb_rw"]
	var m := StandardMaterial3D.new()
	m.albedo_texture = _tex("res://assets/textures/curb_redwhite_color.jpg")
	m.roughness = 0.82
	_mats["curb_rw"] = m
	return m

static func water_material() -> ShaderMaterial:
	if _mats.has("water_vyatka"):
		return _mats["water_vyatka"]
	var sh := Shader.new()
	sh.code = """
shader_type spatial;
render_mode specular_schlick_ggx, cull_disabled;

uniform sampler2D normal_tex : source_color, repeat_enable;
uniform vec4 deep_color : source_color = vec4(0.03, 0.14, 0.24, 0.92);
uniform vec4 shallow_color : source_color = vec4(0.08, 0.30, 0.40, 0.86);
uniform float time_speed = 0.025;
uniform float wave_scale = 0.032;

void fragment() {
	vec3 world_pos = (INV_VIEW_MATRIX * vec4(VERTEX, 1.0)).xyz;
	vec2 uv1 = world_pos.xz * wave_scale + vec2(TIME * time_speed, TIME * time_speed * 0.6);
	vec2 uv2 = world_pos.xz * (wave_scale * 1.65) + vec2(-TIME * time_speed * 0.8, TIME * time_speed * 0.9);
	vec3 n1 = texture(normal_tex, uv1).xyz * 2.0 - 1.0;
	vec3 n2 = texture(normal_tex, uv2).xyz * 2.0 - 1.0;
	vec3 n_mix = normalize(n1 + n2);
	NORMAL_MAP = n_mix * 0.5 + 0.5;
	NORMAL_MAP_DEPTH = 0.55;
	float fresnel = pow(1.0 - clamp(dot(NORMAL, VIEW), 0.0, 1.0), 3.2);
	ALBEDO = mix(deep_color.rgb, shallow_color.rgb, fresnel * 0.7 + 0.15);
	METALLIC = 0.22;
	ROUGHNESS = mix(0.14, 0.04, fresnel);
	SPECULAR = 0.85;
	ALPHA = 0.90;
}
"""
	var sm := ShaderMaterial.new()
	sm.shader = sh
	sm.set_shader_parameter("normal_tex", _tex("res://assets/textures/water_normal.jpg"))
	_mats["water_vyatka"] = sm
	return sm
