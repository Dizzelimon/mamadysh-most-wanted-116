extends Node
class_name AICarDriver

enum Role { RACER, TRAFFIC, POLICE }
enum CopState { PATROL, PURSUIT, SEARCH }

var vehicle: MamadyshVehicle
var world: MamadyshWorld
var target_vehicle: MamadyshVehicle
var role: Role = Role.TRAFFIC
var cop_state: CopState = CopState.PATROL

var track_dist := 0.0
var lane_offset := 3.0
var target_speed_ms := 16.0
var active := true

var _path_pts: PackedVector3Array = PackedVector3Array()
var _path_idx := 0
var _repath_timer := 0.0
var _cruise_node := -1
var _prev_cruise_node := -1
var _last_known_pos := Vector3.ZERO
var _stuck_timer := 0.0
var _reverse_timer := 0.0
var _flank_sign := 1.0
var _street_limit_ms := 12.0
var _track_refresh := 0.0
var _sensor_refresh := 0.0
var _cached_avoid := 0.0
var _cached_speed_cap := 100.0

func _ready() -> void:
	_flank_sign = -1.0 if randf() < 0.5 else 1.0

func _physics_process(delta: float) -> void:
	if not is_instance_valid(vehicle) or not is_instance_valid(world) or not active:
		return

	var pos := vehicle.global_position
	var fwd := -vehicle.global_transform.basis.z
	fwd.y = 0.0
	if fwd.length_squared() < 0.001: fwd = Vector3.FORWARD
	else: fwd = fwd.normalized()

	var aim_pos := pos + fwd * 16.0
	var desired_speed := target_speed_ms

	if role == Role.POLICE and is_instance_valid(target_vehicle):
		var tpos := target_vehicle.global_position
		var dist := pos.distance_to(tpos)
		var has_los := _check_los(pos, tpos)
		if has_los or dist < 52.0:
			cop_state = CopState.PURSUIT
			_last_known_pos = tpos
		elif cop_state == CopState.PURSUIT and dist > 110.0:
			cop_state = CopState.SEARCH

		vehicle.siren_active = (cop_state != CopState.PATROL) or dist < 130.0

		if cop_state == CopState.PATROL:
			aim_pos = _step_street_cruise(pos)
			desired_speed = 16.0
		elif cop_state == CopState.PURSUIT:
			var dir_to_p := (tpos - pos); dir_to_p.y = 0.0
			var facing_p := dir_to_p.length_squared() > 0.01 and fwd.dot(dir_to_p.normalized()) > 0.25
			if dist < 30.0 and has_los and facing_p:
				# Close-quarters PIT & Flank intercept
				var p_right := target_vehicle.global_transform.basis.x
				var lead := target_vehicle.linear_velocity * clampf(dist / 36.0, 0.06, 0.55)
				var side_off := p_right * (_flank_sign * (1.8 if dist > 10.0 else 0.4))
				aim_pos = tpos + lead + side_off
				desired_speed = maxf(target_vehicle.speed * 1.24, 34.0)
			else:
				aim_pos = _follow_astar(pos, tpos, delta)
				desired_speed = maxf(target_vehicle.speed * 1.20, 32.0)
		else:  # SEARCH
			aim_pos = _follow_astar(pos, _last_known_pos, delta)
			desired_speed = 26.0
			if pos.distance_to(_last_known_pos) < 16.0:
				cop_state = CopState.PATROL

	elif role == Role.TRAFFIC:
		aim_pos = _step_street_cruise(pos)
		desired_speed = minf(target_speed_ms, _street_limit_ms)

	else:  # RACER
		var L := world.get_track_length()
		_track_refresh -= delta
		if _track_refresh <= 0.0:
			_track_refresh += 0.11
			track_dist = world.road_curve.get_closest_offset(pos)
		var lookahead := clampf(vehicle.speed * 0.55 + 6.0, 8.0, 24.0)
		var tr := world.sample_track(fposmod(track_dist + lookahead, L))
		var tr_near := world.sample_track(fposmod(track_dist + 2.0, L))
		aim_pos = tr.origin + tr.basis.x * lane_offset
		for look in [12.0, 24.0, 42.0]:
			var ahead := world.sample_track(track_dist + look)
			var angle := tr_near.basis.z.angle_to(ahead.basis.z)
			var bend_speed := lerpf(target_speed_ms, 9.5, clampf(angle / 1.25, 0.0, 1.0))
			desired_speed = minf(desired_speed, bend_speed + look * 0.08)

	_sensor_refresh -= delta
	if _sensor_refresh <= 0.0:
		_sensor_refresh += 0.085
		_scan_obstacles(pos, fwd)
	var steer_avoid := _cached_avoid
	var speed_cap := minf(desired_speed, _cached_speed_cap)

	# Stuck detection + instant reverse recovery
	if vehicle.speed < 2.0:
		_stuck_timer += delta
		if _stuck_timer > 1.35:
			_reverse_timer = 1.15
			_stuck_timer = 0.0
	else:
		_stuck_timer = maxf(0.0, _stuck_timer - delta)

	var to_aim := (aim_pos - pos)
	to_aim.y = 0.0
	if to_aim.length_squared() < 0.01: to_aim = fwd
	else: to_aim = to_aim.normalized()

	var cross_y := fwd.cross(to_aim).y
	var steer_cmd := clampf(cross_y * 2.3 + steer_avoid, -1.0, 1.0)

	if _reverse_timer > 0.0:
		_reverse_timer -= delta
		vehicle.steering_input = -steer_cmd
		vehicle.handbrake_input = 0.0
		if vehicle.current_gear != -1:
			vehicle.current_gear = -1
			vehicle.requested_gear = -1
			vehicle.is_shifting = false
			vehicle.clutch_amount = 0.0
			vehicle.brake_amount = 0.0
		vehicle.throttle_input = 0.85
		vehicle.brake_input = 0.0
		return

	if vehicle.current_gear == -1:
		vehicle.current_gear = 1
		vehicle.requested_gear = 1
		vehicle.is_shifting = false
		vehicle.clutch_amount = 0.0
		vehicle.brake_amount = 0.0

	vehicle.steering_input = steer_cmd
	vehicle.handbrake_input = 0.0
	if vehicle.speed < speed_cap:
		vehicle.throttle_input = clampf((speed_cap - vehicle.speed) * 0.20 + 0.35, 0.25, 1.0)
		vehicle.brake_input = 0.0
	else:
		vehicle.throttle_input = 0.0
		vehicle.brake_input = clampf((vehicle.speed - speed_cap) * 0.25, 0.0, 0.85)

func _scan_obstacles(pos: Vector3, fwd: Vector3) -> void:
	_cached_avoid = 0.0
	_cached_speed_cap = 100.0
	var space := vehicle.get_world_3d().direct_space_state
	if space == null:
		return
	var origin := pos + Vector3(0, 0.72, 0)
	var ray_len := clampf(vehicle.speed * 0.85 + 7.0, 8.0, 28.0)
	var exclude: Array[RID] = [vehicle.get_rid()]
	if role == Role.POLICE and is_instance_valid(target_vehicle) and pos.distance_to(target_vehicle.global_position) < 22.0:
		exclude.append(target_vehicle.get_rid())
	for angle in [-0.31, 0.0, 0.31]:
		var direction := fwd.rotated(Vector3.UP, angle)
		var query := PhysicsRayQueryParameters3D.create(origin, origin + direction * ray_len, 2 | 4, exclude)
		var hit := space.intersect_ray(query)
		if hit.is_empty():
			continue
		var d := origin.distance_to(hit["position"])
		var urgency := 1.0 - d / ray_len
		if angle == 0.0:
			_cached_speed_cap = sqrt(9.6 * maxf(0.0, d - 4.0))
		else:
			_cached_avoid -= signf(angle) * urgency * 0.60

func _check_los(from_p: Vector3, to_p: Vector3) -> bool:
	var space := vehicle.get_world_3d().direct_space_state
	if space == null:
		return true
	var q := PhysicsRayQueryParameters3D.create(from_p + Vector3(0, 1.1, 0), to_p + Vector3(0, 1.1, 0), 2)
	return space.intersect_ray(q).is_empty()

func _follow_astar(pos: Vector3, goal: Vector3, delta: float) -> Vector3:
	_repath_timer -= delta
	if _repath_timer <= 0.0 or _path_pts.is_empty():
		_repath_timer = 1.2
		_path_pts = world.find_path_astar(pos, goal)
		_path_idx = 0
	while _path_idx < _path_pts.size() - 1 and pos.distance_to(_path_pts[_path_idx]) < 18.0:
		_path_idx += 1
	return _path_pts[_path_idx] if _path_idx < _path_pts.size() else goal

func _step_street_cruise(pos: Vector3) -> Vector3:
	if world.graph_nodes.is_empty():
		return pos + Vector3.FORWARD * 20.0
	if _cruise_node < 0:
		_cruise_node = world.get_nearest_graph_node(pos)
	var target_p := world.graph_nodes[_cruise_node]
	if Vector2(pos.x - target_p.x, pos.z - target_p.z).length() < 14.0:
		var adj: Array = world.graph_adj[_cruise_node] if _cruise_node < world.graph_adj.size() else []
		if not adj.is_empty():
			var choices: Array[int] = []
			for e_item in adj:
				var e: Array = e_item
				var nb := int(e[0])
				if nb != _prev_cruise_node:
					choices.append(nb)
			if choices.is_empty():
				choices.append(int(adj[0][0]))
			_prev_cruise_node = _cruise_node
			_cruise_node = choices[randi() % choices.size()]
			for edge: Array in adj:
				if int(edge[0]) == _cruise_node:
					_street_limit_ms = float(edge[2]) / 3.6
					break
			target_p = world.graph_nodes[_cruise_node]
	return target_p
