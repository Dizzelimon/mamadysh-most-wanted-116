extends Control
class_name MinimapControl

var world: MamadyshWorld
var manager: PursuitAndRaceManager
var _track_pts: PackedVector2Array = PackedVector2Array()
var _road_segs: Array[PackedVector2Array] = []
var _vyatka_poly: PackedVector2Array = PackedVector2Array()
var _oshma_line: PackedVector2Array = PackedVector2Array()
var _pulse := 0.0
const RADAR_RADIUS := 340.0

func setup(w: MamadyshWorld, m: PursuitAndRaceManager) -> void:
	world = w
	manager = m
	refresh_map_cache()

func refresh_map_cache() -> void:
	_track_pts.clear()
	_road_segs.clear()
	_vyatka_poly.clear()
	_oshma_line.clear()
	if not is_instance_valid(world):
		return
	if world.road_curve:
		var L := world.get_track_length()
		var n := 160
		for i in range(n):
			var p := world.road_curve.sample_baked(float(i) / float(n) * L, true)
			_track_pts.append(Vector2(p.x, p.z))

	var roads: Array = world.map_data.get("roads", [])
	for r_item in roads:
		var r: Dictionary = r_item
		var pts: Array = r.get("pts", [])
		if pts.size() < 2:
			continue
		var line := PackedVector2Array()
		for pt_item in pts:
			var pt: Array = pt_item
			line.append(Vector2(float(pt[0]), float(pt[2])))
		_road_segs.append(line)

	for a_item in world.vyatka_bank:
		var a: Array = a_item
		_vyatka_poly.append(Vector2(float(a[0]), float(a[1])))
	if _vyatka_poly.size() >= 2:
		var z_end := _vyatka_poly[-1].y
		var z_beg := _vyatka_poly[0].y
		_vyatka_poly.append(Vector2(world.x_max + 700.0, z_end))
		_vyatka_poly.append(Vector2(world.x_max + 700.0, z_beg))

	for o_item in world.oshma_pts:
		var o: Array = o_item
		_oshma_line.append(Vector2(float(o[0]), float(o[1])))

func _process(delta: float) -> void:
	_pulse += delta * 8.0
	if visible:
		queue_redraw()

func _to_radar(wx: float, wz: float, center_w: Vector2, rot_cos: float, rot_sin: float) -> Vector2:
	var dx := wx - center_w.x
	var dz := wz - center_w.y
	# Rotate so player's heading points UP on radar
	var rx := dx * rot_cos - dz * rot_sin
	var ry := dx * rot_sin + dz * rot_cos
	var sc := (minf(size.x, size.y) * 0.48) / RADAR_RADIUS
	return size * 0.5 + Vector2(rx * sc, ry * sc)

func _draw() -> void:
	draw_rect(Rect2(Vector2.ZERO, size), Color(0.05, 0.08, 0.12, 0.84), true)
	if not is_instance_valid(world):
		return

	var center_w := Vector2(388.0, -197.0)
	var heading := 0.0
	if is_instance_valid(manager) and is_instance_valid(manager.player):
		var pp := manager.player.global_position
		center_w = Vector2(pp.x, pp.z)
		var fwd := -manager.player.global_transform.basis.z
		heading = atan2(fwd.x, -fwd.z)

	var rc := cos(-heading)
	var rs := sin(-heading)

	# Clip everything cleanly inside the minimap frame by checking bounds or using DrawSetTransform
	RenderingServer.canvas_item_set_clip(get_canvas_item(), true)

	# Rivers
	if _vyatka_poly.size() >= 3:
		var vp := PackedVector2Array()
		for p in _vyatka_poly:
			vp.append(_to_radar(p.x, p.y, center_w, rc, rs))
		draw_colored_polygon(vp, Color(0.08, 0.30, 0.46, 0.85))
	if _oshma_line.size() >= 2:
		var ol := PackedVector2Array()
		for p in _oshma_line:
			ol.append(_to_radar(p.x, p.y, center_w, rc, rs))
		draw_polyline(ol, Color(0.10, 0.36, 0.52, 0.85), 8.0, true)

	# All 193 city streets
	for seg in _road_segs:
		var poly := PackedVector2Array()
		for p in seg:
			poly.append(_to_radar(p.x, p.y, center_w, rc, rs))
		draw_polyline(poly, Color(0.32, 0.37, 0.45, 0.9), 2.8, false)

	# Active Race Circuit highlight
	if _track_pts.size() > 2:
		var tpoly := PackedVector2Array()
		for p in _track_pts:
			tpoly.append(_to_radar(p.x, p.y, center_w, rc, rs))
		tpoly.append(tpoly[0])
		draw_polyline(tpoly, Color(0.95, 0.78, 0.25, 0.92), 3.6, true)

	# Landmarks
	var lm_tags := {"eiffel": "Э", "olimp": "ОЛ", "embankment": "В", "puzanka": "П", "rdk": "ДК"}
	for lk: String in lm_tags.keys():
		if world.landmarks.has(lk):
			var lp: Array = world.landmarks[lk]["pos"]
			var mp := _to_radar(float(lp[0]), float(lp[2]), center_w, rc, rs)
			if Rect2(Vector2(6, 6), size - Vector2(12, 12)).has_point(mp):
				draw_circle(mp, 4.2, Color(0.95, 0.75, 0.18))

	if is_instance_valid(manager):
		# Next checkpoint
		if manager.mode == PursuitAndRaceManager.GameMode.RACE and not world.checkpoint_positions.is_empty():
			var cp: Vector3 = world.checkpoint_positions[manager.next_cp_idx % world.checkpoint_positions.size()]["pos"]
			var cm := _to_radar(cp.x, cp.z, center_w, rc, rs)
			draw_circle(cm, 5.5, Color(1.0, 0.88, 0.18))

		# Rivals
		for r in manager.racers:
			if is_instance_valid(r):
				var rm := _to_radar(r.global_position.x, r.global_position.z, center_w, rc, rs)
				draw_circle(rm, 4.0, Color(1.0, 0.55, 0.12))

		# ДПС Patrols
		var cop_col := Color(1.0, 0.2, 0.2) if int(_pulse) % 2 == 0 else Color(0.22, 0.55, 1.0)
		for c in manager.cops:
			if is_instance_valid(c):
				var cm := _to_radar(c.global_position.x, c.global_position.z, center_w, rc, rs)
				draw_circle(cm, 4.8, cop_col)

	# Player centered upward arrow
	var mid := size * 0.5
	var tri := PackedVector2Array([mid + Vector2(0, -7.5), mid + Vector2(5.2, 5.5), mid + Vector2(-5.2, 5.5)])
	draw_colored_polygon(tri, Color(0.25, 0.96, 0.45))
	draw_rect(Rect2(Vector2.ZERO, size), Color(0.95, 0.72, 0.2, 0.72), false, 2.0)
