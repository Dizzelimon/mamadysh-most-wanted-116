extends Node3D
class_name MamadyshWorld

var map_data: Dictionary = {}
var bounds: Dictionary = {}
var terrain_h: PackedFloat32Array = PackedFloat32Array()
var grid_n := 180
var x_min := -1880.0
var x_max := 1520.0
var z_min := -1750.0
var z_max := 1550.0
var water_y := 0.4

var graph_nodes: PackedVector3Array = PackedVector3Array()
var graph_adj: Array = []
var _street_router := AStar3D.new()
var landmarks: Dictionary = {}

var road_curve: Curve3D
var race_curve: Curve3D
var olimp_curve: Curve3D
var active_circuit_name := "race"

var road_mesh_inst: MeshInstance3D
var facade_mats: Array[StandardMaterial3D] = []
var night_glow_mats: Array[StandardMaterial3D] = []
var night_lights: Array[Light3D] = []
var checkpoint_positions: Array[Dictionary] = []
var spawn_transform: Transform3D
var destructibles_root: Node3D
var roadblocks_root: Node3D
var checkpoints_root: Node3D
var _rng := RandomNumberGenerator.new()

const ROAD_HALF_W := 6.2

func load_map_json() -> void:
	if not map_data.is_empty():
		return
	var f := FileAccess.open("res://assets/map/mamadysh_map.json", FileAccess.READ)
	if f == null:
		push_error("Cannot open res://assets/map/mamadysh_map.json")
		return
	var txt := f.get_as_text()
	f.close()
	var parsed: Variant = JSON.parse_string(txt)
	if typeof(parsed) != TYPE_DICTIONARY:
		push_error("Invalid mamadysh_map.json format")
		return
	map_data = parsed
	bounds = map_data.get("bounds", {})
	grid_n = int(bounds.get("grid_n", 180))
	x_min = float(bounds.get("x_min", -1880.0))
	x_max = float(bounds.get("x_max", 1520.0))
	z_min = float(bounds.get("z_min", -1750.0))
	z_max = float(bounds.get("z_max", 1550.0))
	water_y = float(bounds.get("water_y", 0.4))

	var th_raw: Array = map_data.get("terrain_h", [])
	terrain_h.resize(th_raw.size())
	for i in range(th_raw.size()):
		terrain_h[i] = float(th_raw[i])

	landmarks = map_data.get("landmarks", {})

	var gn_raw: Array = map_data.get("graph_nodes", [])
	graph_nodes.resize(gn_raw.size())
	for i in range(gn_raw.size()):
		var p: Array = gn_raw[i]
		graph_nodes[i] = Vector3(float(p[0]), float(p[1]), float(p[2]))
	graph_adj = map_data.get("graph_adj", [])
	for i in range(graph_nodes.size()):
		_street_router.add_point(i, graph_nodes[i])
	for i in range(graph_adj.size()):
		for edge: Array in graph_adj[i]:
			var to := int(edge[0])
			if i != to:
				_street_router.connect_points(i, to, false)

func build_world(is_night := false, circuit_id := "race") -> void:
	_rng.seed = 11616
	load_map_json()
	active_circuit_name = circuit_id
	for c in get_children():
		c.queue_free()
	facade_mats.clear()
	night_glow_mats.clear()
	night_lights.clear()
	checkpoint_positions.clear()

	_init_circuits()
	_build_terrain_and_water()
	_build_all_roads_and_bridges()
	_build_mamadysh_landmarks()
	_build_pedestrian_spaces()
	_build_city_buildings()
	_build_trees_and_lights()
	_build_destructibles()
	_build_checkpoints()
	set_night_state(is_night)

func sample_terrain_h(x: float, z: float) -> float:
	if terrain_h.is_empty():
		return 10.0
	var cell_x := (x_max - x_min) / float(grid_n - 1)
	var cell_z := (z_max - z_min) / float(grid_n - 1)
	var u := clampf((x - x_min) / cell_x, 0.0, float(grid_n - 1) - 0.001)
	var v := clampf((z - z_min) / cell_z, 0.0, float(grid_n - 1) - 0.001)
	var i0 := int(u)
	var j0 := int(v)
	var fu := u - float(i0)
	var fv := v - float(j0)
	var h00 := terrain_h[j0 * grid_n + i0]
	var h10 := terrain_h[j0 * grid_n + i0 + 1]
	var h01 := terrain_h[(j0 + 1) * grid_n + i0]
	var h11 := terrain_h[(j0 + 1) * grid_n + i0 + 1]
	return (h00 * (1.0 - fu) + h10 * fu) * (1.0 - fv) + (h01 * (1.0 - fu) + h11 * fu) * fv

func set_active_circuit(circuit_id: String) -> void:
	active_circuit_name = circuit_id
	road_curve = olimp_curve if (circuit_id == "olimp" and olimp_curve != null) else race_curve
	if road_curve and road_curve.point_count > 1:
		var p0 := road_curve.sample_baked(0.0, true)
		var p1 := road_curve.sample_baked(6.0, true)
		var fwd := (p1 - p0).normalized()
		var up := Vector3.UP
		var right := fwd.cross(up).normalized()
		up = right.cross(fwd).normalized()
		spawn_transform = Transform3D(Basis(right, up, -fwd), p0 + Vector3(0.0, 0.25, 0.0))
	if is_inside_tree():
		_build_checkpoints()

func _build_curve_from_pts(raw_pts: Array) -> Curve3D:
	var c := Curve3D.new()
	c.bake_interval = 3.0
	var pts: Array[Vector3] = []
	for item in raw_pts:
		var a: Array = item
		var p := Vector3(float(a[0]), float(a[1]), float(a[2]))
		if pts.is_empty() or pts[-1].distance_to(p) > 0.8:
			pts.append(p)
	if pts.size() >= 2 and pts[0].distance_to(pts[-1]) < 4.0:
		pts.pop_back()
	var n := pts.size()
	if n < 3:
		return c
	for i in range(n + 1):
		var idx := i % n
		var p_prev := pts[(idx - 1 + n) % n]
		var p_curr := pts[idx]
		var p_next := pts[(idx + 1) % n]
		var d_in := (p_curr - p_prev).length()
		var d_out := (p_next - p_curr).length()
		var tang := (p_next - p_prev)
		if tang.length_squared() < 0.01:
			tang = Vector3.FORWARD
		else:
			tang = tang.normalized()
		var hl := minf(2.0, minf(d_in, d_out) * 0.18)
		c.add_point(p_curr, -tang * hl, tang * hl)
	return c

func _init_circuits() -> void:
	race_curve = _build_curve_from_pts(map_data.get("race_circuit", []))
	olimp_curve = _build_curve_from_pts(map_data.get("olimp_circuit", []))
	set_active_circuit(active_circuit_name)

func get_track_length() -> float:
	return road_curve.get_baked_length() if road_curve else 100.0

func sample_track(dist: float) -> Transform3D:
	var L := get_track_length()
	var d := fposmod(dist, L)
	var p := road_curve.sample_baked(d, true)
	var p_ahead := road_curve.sample_baked(fposmod(d + 5.0, L), true)
	p.y = maxf(p.y, sample_terrain_h(p.x, p.z)) + 0.055
	p_ahead.y = maxf(p_ahead.y, sample_terrain_h(p_ahead.x, p_ahead.z)) + 0.055
	var fwd := (p_ahead - p).normalized()
	if fwd.length_squared() < 0.001:
		fwd = Vector3.FORWARD
	var up := Vector3.UP
	var right := fwd.cross(up).normalized()
	up = right.cross(fwd).normalized()
	return Transform3D(Basis(right, up, -fwd), p)

func _build_terrain_and_water() -> void:
	var terrain_body := StaticBody3D.new()
	terrain_body.name = "MamadyshTerrain"
	terrain_body.collision_layer = 1
	terrain_body.collision_mask = 0
	terrain_body.add_to_group("Grass")
	add_child(terrain_body)

	var cell_x := (x_max - x_min) / float(grid_n - 1)
	var cell_z := (z_max - z_min) / float(grid_n - 1)
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)

	for j in range(grid_n - 1):
		var z0 := z_min + float(j) * cell_z
		var z1 := z_min + float(j + 1) * cell_z
		for i in range(grid_n - 1):
			var x0 := x_min + float(i) * cell_x
			var x1 := x_min + float(i + 1) * cell_x
			var h00 := terrain_h[j * grid_n + i]
			var h10 := terrain_h[j * grid_n + i + 1]
			var h01 := terrain_h[(j + 1) * grid_n + i]
			var h11 := terrain_h[(j + 1) * grid_n + i + 1]
			var p00 := Vector3(x0, h00, z0)
			var p10 := Vector3(x1, h10, z0)
			var p01 := Vector3(x0, h01, z1)
			var p11 := Vector3(x1, h11, z1)
			_add_terrain_tri(st, p00, p10, p11)
			_add_terrain_tri(st, p00, p11, p01)

	st.index()
	st.generate_normals()
	var t_mesh := st.commit()
	var t_inst := MeshInstance3D.new()
	t_inst.mesh = t_mesh
	var t_mat := TextureBank.pbr_mat("grass", 0.06, true).duplicate() as StandardMaterial3D
	t_mat.vertex_color_use_as_albedo = true
	t_inst.material_override = t_mat
	terrain_body.add_child(t_inst)

	var t_col := CollisionShape3D.new()
	t_col.shape = t_mesh.create_trimesh_shape()
	terrain_body.add_child(t_col)

	# World outer containment barrier walls so cars stay inside Mamadysh
	var wall_body := StaticBody3D.new()
	wall_body.name = "WorldBounds"
	wall_body.collision_layer = 2
	wall_body.collision_mask = 0
	add_child(wall_body)
	var span_x := x_max - x_min
	var span_z := z_max - z_min
	var mid_x := (x_min + x_max) * 0.5
	var mid_z := (z_min + z_max) * 0.5
	var walls := [
		[Vector3(mid_x, 40.0, z_min + 12.0), Vector3(span_x, 160.0, 6.0)],
		[Vector3(mid_x, 40.0, z_max - 12.0), Vector3(span_x, 160.0, 6.0)],
		[Vector3(x_min + 12.0, 40.0, mid_z), Vector3(6.0, 160.0, span_z)],
		[Vector3(x_max - 12.0, 40.0, mid_z), Vector3(6.0, 160.0, span_z)],
	]
	for w in walls:
		var wc := CollisionShape3D.new()
		var bs := BoxShape3D.new(); bs.size = w[1]
		wc.shape = bs; wc.position = w[0]
		wall_body.add_child(wc)

	var st_water := SurfaceTool.new()
	st_water.begin(Mesh.PRIMITIVE_TRIANGLES)
	for tri: Array in map_data.get("water_triangles", []):
		for point: Array in tri:
			var p := Vector3(float(point[0]), water_y, float(point[1]))
			st_water.set_uv(Vector2(p.x, p.z) / 24.0)
			st_water.add_vertex(p)
	st_water.index()
	st_water.generate_normals()
	var w_mesh := MeshInstance3D.new()
	w_mesh.name = "MappedWater"
	w_mesh.mesh = st_water.commit()
	w_mesh.material_override = TextureBank.water_material()
	w_mesh.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(w_mesh)

func _add_terrain_tri(st: SurfaceTool, p0: Vector3, p1: Vector3, p2: Vector3) -> void:
	for p: Vector3 in [p0, p1, p2]:
		var col := Color(0.92, 0.96, 0.88)
		if p.y < water_y + 0.7:
			col = Color(0.84, 0.78, 0.62)  # Sandy shoreline
		elif p.y > 68.0:
			col = Color(0.76, 0.86, 0.68)  # Puzanka sunlit slope
		st.set_color(col)
		st.set_uv(Vector2(p.x, p.z) / 8.0)
		st.add_vertex(p)

func _build_all_roads_and_bridges() -> void:
	var roads: Array = map_data.get("roads", [])
	var st_road := SurfaceTool.new()
	var st_side := SurfaceTool.new()
	var st_bridge_conc := SurfaceTool.new()
	var st_guard := SurfaceTool.new()
	var st_marking := SurfaceTool.new()
	st_road.begin(Mesh.PRIMITIVE_TRIANGLES)
	st_side.begin(Mesh.PRIMITIVE_TRIANGLES)
	st_bridge_conc.begin(Mesh.PRIMITIVE_TRIANGLES)
	st_guard.begin(Mesh.PRIMITIVE_TRIANGLES)
	st_marking.begin(Mesh.PRIMITIVE_TRIANGLES)

	for r_item in roads:
		var r: Dictionary = r_item
		var pts_raw: Array = r.get("pts", [])
		if pts_raw.size() < 2:
			continue
		var hw := float(r.get("w", 8.0)) * 0.5
		var is_bridge := int(r.get("br", 0)) == 1
		var is_main := String(r.get("hw", "")) == "secondary"
		var has_marking := is_main and not bool(r.get("dirt", false))

		# Subdivide long segments <= 12m so asphalt follows rolling Mamadysh slopes cleanly
		var sub_pts: Array[Vector3] = []
		for i in range(pts_raw.size()):
			var a: Array = pts_raw[i]
			var p := Vector3(float(a[0]), float(a[1]), float(a[2]))
			if i > 0:
				var prev := sub_pts[-1]
				var seg_len := prev.distance_to(p)
				var steps := maxi(1, int(ceilf(seg_len / 12.0)))
				for s in range(1, steps + 1):
					var t := float(s) / float(steps)
					var sp := prev.lerp(p, t)
					if not is_bridge:
						sp.y = sample_terrain_h(sp.x, sp.z) + (0.10 if is_main else 0.05)
					else:
						sp.y += 0.14
					sub_pts.append(sp)
			else:
				if not is_bridge:
					p.y = sample_terrain_h(p.x, p.z) + (0.10 if is_main else 0.05)
				else:
					p.y += 0.14
				sub_pts.append(p)

		if not is_bridge and sub_pts.size() >= 3:
			for _pass in range(2):
				var sy: Array[float] = [sub_pts[0].y]
				for k in range(1, sub_pts.size() - 1):
					sy.append(0.25 * sub_pts[k - 1].y + 0.50 * sub_pts[k].y + 0.25 * sub_pts[k + 1].y)
				sy.append(sub_pts[-1].y)
				for k in range(1, sub_pts.size() - 1):
					sub_pts[k].y = maxf(sy[k], sample_terrain_h(sub_pts[k].x, sub_pts[k].z) + (0.09 if is_main else 0.04))

		var target_st := st_road if is_main else st_side
		var v_acc := 0.0
		var n_pts := sub_pts.size()
		var prev_l := Vector3.ZERO
		var prev_r := Vector3.ZERO
		for i in range(n_pts):
			var p := sub_pts[i]
			var fwd := (sub_pts[mini(i + 1, n_pts - 1)] - sub_pts[maxi(i - 1, 0)])
			fwd.y = 0.0
			if fwd.length_squared() < 0.001:
				fwd = Vector3.FORWARD
			fwd = fwd.normalized()
			var right := fwd.cross(Vector3.UP).normalized()
			var cur_l := p - right * hw
			var cur_r := p + right * hw
			if not is_bridge:
				cur_l.y = maxf(cur_l.y, sample_terrain_h(cur_l.x, cur_l.z) + 0.085)
				cur_r.y = maxf(cur_r.y, sample_terrain_h(cur_r.x, cur_r.z) + 0.085)
			if i > 0:
				v_acc += sub_pts[i - 1].distance_to(p)
				var va := (v_acc - sub_pts[i - 1].distance_to(p)) / 14.0
				var vb := v_acc / 14.0
				_add_quad(target_st, prev_l, cur_l, cur_r, prev_r, Vector2(0, va), Vector2(0, vb), Vector2(1, vb), Vector2(1, va))

				# Painted dashed centerline, 3.5m dash / 5m gap, no collision.
				if has_marking and v_acc > 8.0:
					var segment := p - sub_pts[i - 1]
					var segment_length := segment.length()
					if segment_length > 0.01:
						var direction := segment / segment_length
						var side := Vector3(-direction.z, 0.0, direction.x).normalized() * 0.075
						var cursor := 0.0
						while cursor < segment_length:
							var phase := fposmod(v_acc - segment_length + cursor, 8.5)
							var advance := minf(segment_length - cursor, (3.5 if phase < 3.5 else 8.5) - phase)
							if phase < 3.5 and advance > 0.02:
								var a_mark := sub_pts[i - 1] + direction * cursor + Vector3.UP * 0.065
								var b_mark := sub_pts[i - 1] + direction * (cursor + advance) + Vector3.UP * 0.065
								_add_quad(st_marking, a_mark - side, b_mark - side, b_mark + side, a_mark + side, Vector2.ZERO, Vector2.ZERO, Vector2.ZERO, Vector2.ZERO)
							cursor += maxf(advance, 0.01)

				if is_bridge:
					# Bridge concrete deck underside + safety guardrails
					var u_al := prev_l - Vector3(0, 0.9, 0)
					var u_bl := cur_l - Vector3(0, 0.9, 0)
					var u_ar := prev_r - Vector3(0, 0.9, 0)
					var u_br := cur_r - Vector3(0, 0.9, 0)
					_add_quad(st_bridge_conc, prev_r, cur_r, u_br, u_ar, Vector2(0, 0), Vector2(0, 1), Vector2(1, 1), Vector2(1, 0))
					_add_quad(st_bridge_conc, u_al, u_bl, cur_l, prev_l, Vector2(0, 0), Vector2(0, 1), Vector2(1, 1), Vector2(1, 0))
					for s_edge in [prev_l, prev_r]:
						var b_edge := cur_l if s_edge == prev_l else cur_r
						_add_quad(st_guard, s_edge, s_edge + Vector3(0, 1.05, 0), b_edge + Vector3(0, 1.05, 0), b_edge,
								  Vector2(0, 0), Vector2(0, 1), Vector2(1, 1), Vector2(1, 0))
			prev_l = cur_l
			prev_r = cur_r

		if is_bridge and sub_pts.size() >= 2:
			var mid := sub_pts[sub_pts.size() / 2]
			var pier := MeshInstance3D.new()
			var pm := BoxMesh.new(); pm.size = Vector3(hw * 1.8, mid.y + 4.0, 2.8)
			pier.mesh = pm; pier.position = Vector3(mid.x, (mid.y - 4.0) * 0.5, mid.z)
			pier.material_override = TextureBank.pbr_mat("concrete", 0.3, true)
			add_child(pier)

	st_road.generate_normals(); st_road.generate_tangents()
	st_side.generate_normals(); st_side.generate_tangents()
	st_bridge_conc.generate_normals()
	st_guard.generate_normals()
	st_marking.generate_normals()
	var marking_mesh := st_marking.commit()
	if marking_mesh.get_surface_count() > 0:
		var marking_instance := MeshInstance3D.new()
		marking_instance.name = "RoadMarkings"
		marking_instance.mesh = marking_mesh
		var marking_material := StandardMaterial3D.new()
		marking_material.albedo_color = Color(0.94, 0.88, 0.67)
		marking_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		marking_material.cull_mode = BaseMaterial3D.CULL_DISABLED
		marking_instance.material_override = marking_material
		add_child(marking_instance)

	var road_body := StaticBody3D.new()
	road_body.name = "MamadyshRoadNetwork"
	road_body.collision_layer = 1
	road_body.collision_mask = 0
	road_body.add_to_group("Road")
	add_child(road_body)

	var main_mesh := st_road.commit()
	road_mesh_inst = MeshInstance3D.new()
	road_mesh_inst.mesh = main_mesh
	road_mesh_inst.material_override = TextureBank.road_material(false)
	road_body.add_child(road_mesh_inst)

	var side_mesh := st_side.commit()
	if side_mesh.get_surface_count() > 0:
		var side_inst := MeshInstance3D.new()
		side_inst.mesh = side_mesh
		side_inst.material_override = TextureBank.pbr_mat("asphalt_shoulder", 1.0, false)
		road_body.add_child(side_inst)
		var sc := CollisionShape3D.new(); sc.shape = side_mesh.create_trimesh_shape()
		road_body.add_child(sc)

	var mc := CollisionShape3D.new(); mc.shape = main_mesh.create_trimesh_shape()
	road_body.add_child(mc)

	var conc_mesh := st_bridge_conc.commit()
	if conc_mesh.get_surface_count() > 0:
		var ci := MeshInstance3D.new(); ci.mesh = conc_mesh
		ci.material_override = TextureBank.pbr_mat("concrete", 0.25, true)
		road_body.add_child(ci)

	var g_mesh := st_guard.commit()
	if g_mesh.get_surface_count() > 0:
		var gb := StaticBody3D.new(); gb.name = "BridgeGuardrails"; gb.collision_layer = 2; gb.collision_mask = 0
		add_child(gb)
		var gi := MeshInstance3D.new(); gi.mesh = g_mesh
		var gmat := TextureBank.pbr_mat("metal_brushed", 0.6, true).duplicate() as StandardMaterial3D
		gmat.cull_mode = BaseMaterial3D.CULL_DISABLED
		gi.material_override = gmat
		gb.add_child(gi)
		var gc := CollisionShape3D.new(); gc.shape = g_mesh.create_trimesh_shape()
		gb.add_child(gc)

func _add_quad(st: SurfaceTool, p0: Vector3, p1: Vector3, p2: Vector3, p3: Vector3, uv0: Vector2, uv1: Vector2, uv2: Vector2, uv3: Vector2) -> void:
	st.set_uv(uv0); st.add_vertex(p0)
	st.set_uv(uv1); st.add_vertex(p1)
	st.set_uv(uv2); st.add_vertex(p2)
	st.set_uv(uv0); st.add_vertex(p0)
	st.set_uv(uv2); st.add_vertex(p2)
	st.set_uv(uv3); st.add_vertex(p3)

func _lm_pos(key: String) -> Vector3:
	if not landmarks.has(key):
		return Vector3.ZERO
	var p: Array = landmarks[key]["pos"]
	var x := float(p[0]); var z := float(p[2])
	return Vector3(x, sample_terrain_h(x, z), z)

func _build_mamadysh_landmarks() -> void:
	# Start/Finish arch right on race_circuit[0] (Sovetskaya St / Lenin Square)
	if race_curve and race_curve.point_count > 1:
		var tr0 := sample_track(14.0)
		_build_start_arch(tr0)

	if landmarks.has("eiffel"): _build_eiffel_tower(_lm_pos("eiffel"))
	if landmarks.has("memorial"): _build_memorial(_lm_pos("memorial"))
	if landmarks.has("embankment"): _build_vyatka_embankment(_lm_pos("embankment"))
	if landmarks.has("olimp"): _build_olimp_ice_palace(_lm_pos("olimp"))
	if landmarks.has("lenin"): _build_lenin_monument(_lm_pos("lenin"))
	if landmarks.has("rdk"): _build_rdk_palace(_lm_pos("rdk"))
	if landmarks.has("admin"): _build_admin_building(_lm_pos("admin"))
	if landmarks.has("church"): _build_church(_lm_pos("church"))
	if landmarks.has("puzanka"): _build_puzanka_pavilion(_lm_pos("puzanka"))

func _add_landmark_collider(parent: Node3D, sz: Vector3, offset: Vector3) -> void:
	var sb := StaticBody3D.new(); sb.collision_layer = 2; sb.collision_mask = 0
	var cs := CollisionShape3D.new(); var bs := BoxShape3D.new(); bs.size = sz
	cs.shape = bs; cs.position = offset
	sb.add_child(cs); parent.add_child(sb)

func _build_start_arch(tr: Transform3D) -> void:
	var arch := Node3D.new(); arch.transform = tr; add_child(arch)
	var steel := TextureBank.pbr_mat("metal_brushed", 0.5, true)
	var banner := StandardMaterial3D.new()
	banner.albedo_color = Color(0.08, 0.09, 0.12)
	banner.emission_enabled = true; banner.emission = Color(1.0, 0.65, 0.12); banner.emission_energy_multiplier = 0.85
	for sx in [-7.6, 7.6]:
		var col := MeshInstance3D.new(); var bm := BoxMesh.new(); bm.size = Vector3(0.75, 7.2, 0.75)
		col.mesh = bm; col.position = Vector3(sx, 3.6, 0); col.material_override = steel; arch.add_child(col)
		_add_landmark_collider(arch, Vector3(0.85, 6.0, 0.85), Vector3(sx, 3.0, 0))
	var top := MeshInstance3D.new(); var tm := BoxMesh.new(); tm.size = Vector3(16.4, 1.9, 1.0)
	top.mesh = tm; top.position = Vector3(0, 6.8, 0); top.material_override = banner; arch.add_child(top)
	for s in [-1.0, 1.0]:
		var lbl := Label3D.new(); lbl.text = "МАМАДЫШ • MOST WANTED 116"; lbl.font_size = 68
		lbl.modulate = Color(1.0, 0.88, 0.25); lbl.position = Vector3(0, 6.8, s * 0.58)
		if s < 0.0: lbl.rotation_degrees.y = 180.0
		arch.add_child(lbl)

func _build_eiffel_tower(pos: Vector3) -> void:
	var tower := Node3D.new(); tower.position = pos; add_child(tower)
	var iron := StandardMaterial3D.new(); iron.albedo_color = Color(0.24, 0.21, 0.19); iron.metallic = 0.82; iron.roughness = 0.42
	var gold := StandardMaterial3D.new(); gold.albedo_color = Color(1.0, 0.82, 0.35); gold.emission_enabled = true
	gold.emission = Color(1.0, 0.72, 0.22); gold.emission_energy_multiplier = 0.2; night_glow_mats.append(gold)

	var ped := MeshInstance3D.new(); var pm := BoxMesh.new(); pm.size = Vector3(7.6, 1.2, 7.6)
	ped.mesh = pm; ped.position = Vector3(0, 0.4, 0); ped.material_override = TextureBank.pbr_mat("paving", 0.35, true)
	tower.add_child(ped)
	_add_landmark_collider(tower, Vector3(6.8, 14.0, 6.8), Vector3(0, 7.0, 0))

	var levels := [[2.7, 0.8], [1.45, 5.8], [0.70, 10.4], [0.18, 14.2]]
	for idx in range(levels.size() - 1):
		var r0: float = levels[idx][0]; var y0: float = levels[idx][1]
		var r1: float = levels[idx + 1][0]; var y1: float = levels[idx + 1][1]
		for sx in [-1.0, 1.0]:
			for sz in [-1.0, 1.0]:
				tower.add_child(_make_beam(Vector3(sx * r0, y0, sz * r0), Vector3(sx * r1, y1, sz * r1), 0.24 if idx == 0 else 0.15, iron))
		var deck := MeshInstance3D.new(); var dm := BoxMesh.new(); dm.size = Vector3(r1 * 2.4, 0.34, r1 * 2.4)
		deck.mesh = dm; deck.position = Vector3(0, y1, 0); deck.material_override = gold if idx < 2 else iron; tower.add_child(deck)
	var spire := MeshInstance3D.new(); var sm := CylinderMesh.new(); sm.top_radius = 0.04; sm.bottom_radius = 0.16; sm.height = 3.0
	spire.mesh = sm; spire.position = Vector3(0, 15.6, 0); spire.material_override = gold; tower.add_child(spire)
	var tl := OmniLight3D.new(); tl.light_color = Color(1.0, 0.78, 0.35); tl.light_energy = 0.0; tl.omni_range = 28.0
	tl.position = Vector3(0, 10.0, 0); tower.add_child(tl); night_lights.append(tl)

func _build_memorial(pos: Vector3) -> void:
	var mem := Node3D.new(); mem.position = pos; add_child(mem)
	var gran := TextureBank.pbr_mat("stone_blocks", 0.35, true)
	var dark_gran := StandardMaterial3D.new(); dark_gran.albedo_color = Color(0.14, 0.14, 0.16); dark_gran.roughness = 0.35
	var base := MeshInstance3D.new(); var bm := BoxMesh.new(); bm.size = Vector3(14.0, 1.0, 10.0)
	base.mesh = bm; base.position = Vector3(0, 0.3, 0); base.material_override = gran; mem.add_child(base)
	var wall := MeshInstance3D.new(); var wm := BoxMesh.new(); wm.size = Vector3(11.0, 4.2, 1.2)
	wall.mesh = wm; wall.position = Vector3(0, 2.8, -3.2); wall.material_override = dark_gran; mem.add_child(wall)
	var ob := MeshInstance3D.new(); var om := BoxMesh.new(); om.size = Vector3(1.6, 11.5, 1.6)
	ob.mesh = om; ob.position = Vector3(0, 6.2, -3.0); ob.material_override = dark_gran; mem.add_child(ob)
	var flame := MeshInstance3D.new(); var fm := CylinderMesh.new(); fm.top_radius = 0.05; fm.bottom_radius = 0.45; fm.height = 1.2
	var flm := StandardMaterial3D.new(); flm.albedo_color = Color(1.0, 0.55, 0.1); flm.emission_enabled = true
	flm.emission = Color(1.0, 0.48, 0.08); flm.emission_energy_multiplier = 3.2; night_glow_mats.append(flm)
	flame.mesh = fm; flame.position = Vector3(0, 1.5, 0.8); flame.material_override = flm; mem.add_child(flame)
	var lbl := Label3D.new(); lbl.text = "1941 — 1945"; lbl.font_size = 72; lbl.modulate = Color(0.95, 0.78, 0.28)
	lbl.position = Vector3(0, 3.6, -2.55); mem.add_child(lbl)
	_add_landmark_collider(mem, Vector3(12.0, 6.0, 8.0), Vector3(0, 3.0, -1.0))

func _build_vyatka_embankment(pos: Vector3) -> void:
	var emb := Node3D.new(); emb.position = pos; add_child(emb)
	# Two-level promenade overlooking Vyatka River
	for lvl in [[0.0, 0.4, 24.0, 95.0], [10.0, -2.4, 14.0, 105.0]]:
		var deck := MeshInstance3D.new(); var dm := BoxMesh.new(); dm.size = Vector3(lvl[2], 1.6, lvl[3])
		deck.mesh = dm; deck.position = Vector3(lvl[0], lvl[1], 0.0)
		deck.material_override = TextureBank.pbr_mat("paving", 0.28, true); emb.add_child(deck)
	# Wooden Fortress Kremlin towers
	for tz in [-40.0, 40.0]:
		var base := MeshInstance3D.new(); var bm := CylinderMesh.new(); bm.top_radius = 4.0; bm.bottom_radius = 4.4; bm.height = 8.2; bm.radial_segments = 8
		base.mesh = bm; base.position = Vector3(-4.0, 4.1, tz); base.material_override = TextureBank.pbr_mat("wood_fortress", 0.3, true); emb.add_child(base)
		var roof := MeshInstance3D.new(); var rm := CylinderMesh.new(); rm.top_radius = 0.2; rm.bottom_radius = 5.0; rm.height = 4.5; rm.radial_segments = 8
		roof.mesh = rm; roof.position = Vector3(-4.0, 10.4, tz); roof.material_override = TextureBank.pbr_mat("bricks_red", 0.4, true); emb.add_child(roof)
		_add_landmark_collider(emb, Vector3(8.5, 9.0, 8.5), Vector3(-4.0, 4.5, tz))
	# Iconic «Ладья» wooden river vessel monument on lower level
	var hull := MeshInstance3D.new(); var hm := BoxMesh.new(); hm.size = Vector3(4.2, 2.2, 13.0)
	hull.mesh = hm; hull.position = Vector3(11.0, -0.6, 0.0); hull.material_override = TextureBank.pbr_mat("wood_fortress", 0.35, true); emb.add_child(hull)
	var mast := MeshInstance3D.new(); var mm := CylinderMesh.new(); mm.top_radius = 0.14; mm.bottom_radius = 0.2; mm.height = 8.5
	mast.mesh = mm; mast.position = Vector3(11.0, 4.2, 0.0); mast.material_override = TextureBank.pbr_mat("wood_fortress", 0.4, true); emb.add_child(mast)
	var sail := MeshInstance3D.new(); var sm := BoxMesh.new(); sm.size = Vector3(4.4, 4.8, 0.25)
	sail.mesh = sm; sail.position = Vector3(11.0, 5.2, 0.3); sail.rotation_degrees.y = 14.0
	var smat := StandardMaterial3D.new(); smat.albedo_color = Color(0.95, 0.90, 0.78); sail.material_override = smat; emb.add_child(sail)
	# 7-tier fountain
	var wg := StandardMaterial3D.new(); wg.albedo_color = Color(0.18, 0.78, 0.95); wg.emission_enabled = true
	wg.emission = Color(0.15, 0.85, 1.0); wg.emission_energy_multiplier = 0.4; night_glow_mats.append(wg)
	for tier in range(7):
		var tr := 4.8 - tier * 0.6; var d := MeshInstance3D.new(); var cm := CylinderMesh.new()
		cm.top_radius = tr; cm.bottom_radius = tr + 0.18; cm.height = 0.5
		d.mesh = cm; d.position = Vector3(-2.0, 0.6 + tier * 0.55, 0.0)
		d.material_override = wg if tier % 2 == 1 else TextureBank.pbr_mat("stone_blocks", 0.4, true); emb.add_child(d)
	_add_landmark_collider(emb, Vector3(9.5, 4.5, 9.5), Vector3(-2.0, 2.2, 0.0))
	var slbl := Label3D.new(); slbl.text = "НАБЕРЕЖНАЯ ВЯТКИ • ПАРИЖ 3784 КМ"; slbl.font_size = 46
	slbl.modulate = Color(1.0, 0.92, 0.55); slbl.position = Vector3(-5.0, 4.2, 22.0); slbl.rotation_degrees.y = -90.0; emb.add_child(slbl)

func _build_olimp_ice_palace(pos: Vector3) -> void:
	# Modeled directly from real photo: teal-turquoise & white ribbed sports palace with blue arched glass portico!
	var arena := Node3D.new(); arena.position = pos; arena.rotation_degrees = Vector3(0, 18, 0); add_child(arena)
	var teal := StandardMaterial3D.new(); teal.albedo_color = Color(0.08, 0.52, 0.50); teal.metallic = 0.35; teal.roughness = 0.42
	var white_p := StandardMaterial3D.new(); white_p.albedo_color = Color(0.92, 0.94, 0.96); white_p.roughness = 0.38
	var blue_g := StandardMaterial3D.new(); blue_g.albedo_color = Color(0.10, 0.42, 0.84); blue_g.metallic = 0.5; blue_g.roughness = 0.18
	blue_g.emission_enabled = true; blue_g.emission = Color(0.12, 0.48, 0.95); blue_g.emission_energy_multiplier = 0.25; night_glow_mats.append(blue_g)

	var body := MeshInstance3D.new(); var bm := BoxMesh.new(); bm.size = Vector3(48.0, 12.5, 34.0)
	body.mesh = bm; body.position = Vector3(0, 5.8, 0); body.material_override = teal; arena.add_child(body)
	var stripe := MeshInstance3D.new(); var sm := BoxMesh.new(); sm.size = Vector3(48.4, 3.2, 34.4)
	stripe.mesh = sm; stripe.position = Vector3(0, 10.2, 0); stripe.material_override = white_p; arena.add_child(stripe)
	var roof := MeshInstance3D.new(); var rm := CylinderMesh.new(); rm.top_radius = 19.0; rm.bottom_radius = 19.0; rm.height = 50.0
	roof.mesh = rm; roof.rotation_degrees = Vector3(0, 0, 90); roof.scale = Vector3(1, 1, 0.28)
	roof.position = Vector3(0, 12.2, 0); roof.material_override = TextureBank.pbr_mat("metal_brushed", 0.35, true); arena.add_child(roof)
	var portico := MeshInstance3D.new(); var pm := CylinderMesh.new(); pm.top_radius = 7.5; pm.bottom_radius = 7.5; pm.height = 10.0
	portico.mesh = pm; portico.rotation_degrees = Vector3(90, 0, 0); portico.scale = Vector3(1.1, 1.0, 0.9)
	portico.position = Vector3(0, 5.5, 18.5); portico.material_override = blue_g; arena.add_child(portico)
	var lbl := Label3D.new(); lbl.text = "ОЛИМП • ДВОРЕЦ СПОРТА"; lbl.font_size = 76
	lbl.modulate = Color(0.92, 0.97, 1.0); lbl.position = Vector3(0, 10.5, 17.5); arena.add_child(lbl)
	_add_landmark_collider(arena, Vector3(48.0, 14.0, 36.0), Vector3(0, 6.5, 0))

func _build_lenin_monument(pos: Vector3) -> void:
	var m := Node3D.new(); m.position = pos; add_child(m)
	var gran := TextureBank.pbr_mat("stone_blocks", 0.4, true)
	var bronze := StandardMaterial3D.new(); bronze.albedo_color = Color(0.18, 0.14, 0.11); bronze.metallic = 0.78; bronze.roughness = 0.35
	var ped := MeshInstance3D.new(); var pm := BoxMesh.new(); pm.size = Vector3(5.6, 3.8, 5.6)
	ped.mesh = pm; ped.position = Vector3(0, 1.9, 0); ped.material_override = gran; m.add_child(ped)
	var st := MeshInstance3D.new(); var sm := CylinderMesh.new(); sm.top_radius = 0.6; sm.bottom_radius = 0.9; sm.height = 3.8
	st.mesh = sm; st.position = Vector3(0, 5.7, 0); st.material_override = bronze; m.add_child(st)
	_add_landmark_collider(m, Vector3(5.8, 8.0, 5.8), Vector3(0, 4.0, 0))

func _build_rdk_palace(pos: Vector3) -> void:
	var r := Node3D.new(); r.position = pos; r.rotation_degrees = Vector3(0, -18, 0); add_child(r)
	var cream := StandardMaterial3D.new(); cream.albedo_color = Color(0.92, 0.88, 0.78); cream.roughness = 0.6
	var main := MeshInstance3D.new(); var mm := BoxMesh.new(); mm.size = Vector3(34.0, 11.0, 22.0)
	main.mesh = mm; main.position = Vector3(0, 5.5, 0); main.material_override = cream; r.add_child(main)
	for cx in [-8.0, -4.0, 0.0, 4.0, 8.0]:
		var col := MeshInstance3D.new(); var cm := CylinderMesh.new(); cm.top_radius = 0.38; cm.bottom_radius = 0.44; cm.height = 9.0
		col.mesh = cm; col.position = Vector3(cx, 4.5, 12.2); col.material_override = cream; r.add_child(col)
	var ped := MeshInstance3D.new(); var pm := BoxMesh.new(); pm.size = Vector3(20.0, 2.2, 3.5)
	ped.mesh = pm; ped.position = Vector3(0, 10.0, 11.6); ped.material_override = cream; r.add_child(ped)
	var lbl := Label3D.new(); lbl.text = "РАЙОННЫЙ ДОМ КУЛЬТУРЫ"; lbl.font_size = 54
	lbl.modulate = Color(1.0, 0.92, 0.65); lbl.position = Vector3(0, 10.0, 13.5); r.add_child(lbl)
	_add_landmark_collider(r, Vector3(34.0, 12.0, 24.0), Vector3(0, 5.5, 0))

func _build_admin_building(pos: Vector3) -> void:
	var a := Node3D.new(); a.position = pos; add_child(a)
	var mat := TextureBank.pbr_mat("facade_merchant", 1.0, false, 0.0).duplicate() as StandardMaterial3D
	mat.uv1_scale = Vector3(4.0, 2.0, 1.0); facade_mats.append(mat)
	var b := MeshInstance3D.new(); var bm := BoxMesh.new(); bm.size = Vector3(30.0, 13.5, 18.0)
	b.mesh = bm; b.position = Vector3(0, 6.75, 0); b.material_override = mat; a.add_child(b)
	# Tatarstan flag colors banner on roof
	var flag_cols := [Color(0.05, 0.55, 0.25), Color(0.95, 0.95, 0.96), Color(0.85, 0.12, 0.14)]
	for fi in range(3):
		var fm := StandardMaterial3D.new(); fm.albedo_color = flag_cols[fi]
		var fl := MeshInstance3D.new(); var flm := BoxMesh.new(); flm.size = Vector3(3.2, 0.6, 0.15)
		fl.mesh = flm; fl.position = Vector3(0, 17.5 - fi * 0.65, 0); fl.material_override = fm; a.add_child(fl)
	_add_landmark_collider(a, Vector3(30.0, 14.0, 18.0), Vector3(0, 7.0, 0))

func _build_church(pos: Vector3) -> void:
	var ch := Node3D.new(); ch.position = pos; add_child(ch)
	var white_st := StandardMaterial3D.new(); white_st.albedo_color = Color(0.94, 0.92, 0.86); white_st.roughness = 0.65
	var gold_d := StandardMaterial3D.new(); gold_d.albedo_color = Color(0.98, 0.78, 0.18); gold_d.metallic = 0.92; gold_d.roughness = 0.16
	var nave := MeshInstance3D.new(); var nm := BoxMesh.new(); nm.size = Vector3(16.0, 10.5, 22.0)
	nave.mesh = nm; nave.position = Vector3(0, 5.25, 0); nave.material_override = white_st; ch.add_child(nave)
	var bell := MeshInstance3D.new(); var bm := BoxMesh.new(); bm.size = Vector3(6.0, 18.0, 6.0)
	bell.mesh = bm; bell.position = Vector3(0, 9.0, 12.0); bell.material_override = white_st; ch.add_child(bell)
	for dp in [Vector3(0, 14.5, 0), Vector3(0, 20.5, 12.0)]:
		var drum := MeshInstance3D.new(); var dm := CylinderMesh.new(); dm.top_radius = 2.0; dm.bottom_radius = 2.0; dm.height = 4.2
		drum.mesh = dm; drum.position = dp - Vector3(0, 2.0, 0); drum.material_override = white_st; ch.add_child(drum)
		var dome := MeshInstance3D.new(); var sm := SphereMesh.new(); sm.radius = 2.4; sm.height = 4.2
		dome.mesh = sm; dome.position = dp; dome.material_override = gold_d; ch.add_child(dome)
	_add_landmark_collider(ch, Vector3(17.0, 14.0, 28.0), Vector3(0, 7.0, 2.0))

func _build_puzanka_pavilion(pos: Vector3) -> void:
	var pav := Node3D.new(); pav.position = pos; add_child(pav)
	var base := MeshInstance3D.new(); var bm := CylinderMesh.new(); bm.top_radius = 6.2; bm.bottom_radius = 6.8; bm.height = 1.2
	base.mesh = bm; base.position = Vector3(0, 0.3, 0); base.material_override = TextureBank.pbr_mat("stone_blocks", 0.4, true); pav.add_child(base)
	for a in range(6):
		var ang := float(a) * TAU / 6.0
		var col := MeshInstance3D.new(); var cm := CylinderMesh.new(); cm.top_radius = 0.22; cm.bottom_radius = 0.26; cm.height = 4.6
		col.mesh = cm; col.position = Vector3(cos(ang) * 4.8, 2.8, sin(ang) * 4.8)
		col.material_override = TextureBank.pbr_mat("concrete", 0.5, true); pav.add_child(col)
	var dome := MeshInstance3D.new(); var dm := CylinderMesh.new(); dm.top_radius = 0.2; dm.bottom_radius = 6.4; dm.height = 2.8
	dome.mesh = dm; dome.position = Vector3(0, 6.2, 0); dome.material_override = TextureBank.pbr_mat("bricks_red", 0.4, true); pav.add_child(dome)
	var sign := Label3D.new(); sign.text = "МАМАДЫШ • ГОРА ПУЗАНКА"; sign.font_size = 90
	sign.modulate = Color(1.0, 0.94, 0.72); sign.position = Vector3(0, 9.2, 0); pav.add_child(sign)
	_add_landmark_collider(pav, Vector3(11.0, 6.0, 11.0), Vector3(0, 3.0, 0))

func _make_beam(a: Vector3, b: Vector3, thickness: float, mat: Material) -> MeshInstance3D:
	var m := MeshInstance3D.new(); var bm := BoxMesh.new(); bm.size = Vector3(thickness, thickness, a.distance_to(b))
	m.mesh = bm; m.position = (a + b) * 0.5; m.look_at_from_position(m.position, b, Vector3.UP); m.material_override = mat
	return m

func _build_city_buildings() -> void:
	const CHUNK_M := 365.0
	var groups := {}
	for b: Array in map_data.get("footprints", []):
		var center := Vector2(float(b[0]), float(b[1]))
		if _landmark_overlaps(center):
			continue
		var key := Vector2i(floori(center.x / CHUNK_M), floori(center.y / CHUNK_M))
		if not groups.has(key):
			groups[key] = []
		groups[key].append(b)

	var wall_mats: Array[StandardMaterial3D] = []
	for style: String in ["facade_khrushchevka", "facade_merchant", "bricks_red"]:
		var mat := TextureBank.pbr_mat(style, 1.0, false, 0.0).duplicate() as StandardMaterial3D
		mat.cull_mode = BaseMaterial3D.CULL_DISABLED
		wall_mats.append(mat)
		facade_mats.append(mat)
	var roof_mat := StandardMaterial3D.new()
	roof_mat.vertex_color_use_as_albedo = true
	roof_mat.roughness = 0.77
	roof_mat.cull_mode = BaseMaterial3D.CULL_DISABLED

	for key: Vector2i in groups:
		var root := StaticBody3D.new()
		root.name = "Quartier_%d_%d" % [key.x, key.y]
		root.collision_layer = 2
		root.collision_mask = 0
		add_child(root)
		var walls: Array[SurfaceTool] = []
		for _i in range(3):
			walls.append(_triangle_surface())
		var roofs := _triangle_surface()
		var collision_faces := PackedVector3Array()
		for b: Array in groups[key]:
			var center := Vector2(float(b[0]), float(b[1]))
			var outline := PackedVector2Array()
			var ground := sample_terrain_h(center.x, center.y)
			for point: Array in b[5]:
				var v := Vector2(float(point[0]), float(point[1]))
				outline.append(v)
				ground = minf(ground, sample_terrain_h(v.x, v.y))
			var eaves := maxf(sample_terrain_h(center.x, center.y), ground + 0.2) + float(b[2])
			var roof_tint := _roof_color(int(b[6]), bool(b[4]))
			var wall := walls[int(b[3])]
			for i in range(outline.size()):
				var a := outline[i]
				var c := outline[(i + 1) % outline.size()]
				var base_a := Vector3(a.x, ground - 0.8, a.y)
				var base_c := Vector3(c.x, ground - 0.8, c.y)
				var top_a := Vector3(a.x, eaves, a.y)
				var top_c := Vector3(c.x, eaves, c.y)
				var u := maxf(1.0, roundf(a.distance_to(c) / 7.5))
				var v := maxf(1.0, roundf(float(b[2]) / 3.8))
				_add_quad(wall, base_a, base_c, top_c, top_a, Vector2(0, v), Vector2(u, v), Vector2(u, 0), Vector2.ZERO)
				collision_faces.append_array(PackedVector3Array([base_a, base_c, top_c, base_a, top_c, top_a]))
			if bool(b[4]) and outline.size() == 4:
				_add_gabled_roof(roofs, outline, eaves, roof_tint)
			else:
				for index in Geometry2D.triangulate_polygon(outline):
					var point := outline[index]
					roofs.set_color(roof_tint)
					roofs.add_vertex(Vector3(point.x, eaves, point.y))
		for style in range(walls.size()):
			_add_city_mesh(root, walls[style], wall_mats[style])
		_add_city_mesh(root, roofs, roof_mat)
		if not collision_faces.is_empty():
			var shape := ConcavePolygonShape3D.new()
			shape.backface_collision = true
			shape.set_faces(collision_faces)
			var col := CollisionShape3D.new()
			col.shape = shape
			root.add_child(col)

func _triangle_surface() -> SurfaceTool:
	var surface := SurfaceTool.new()
	surface.begin(Mesh.PRIMITIVE_TRIANGLES)
	return surface

func _add_city_mesh(parent: Node3D, surface: SurfaceTool, material: Material) -> void:
	surface.generate_normals()
	var mesh := surface.commit()
	if mesh.get_surface_count() == 0:
		return
	var instance := MeshInstance3D.new()
	instance.mesh = mesh
	instance.material_override = material
	instance.visibility_range_end = 1050.0 if OS.has_feature("mobile") else 1700.0
	parent.add_child(instance)

func _landmark_overlaps(center: Vector2) -> bool:
	var radii := {"olimp": 29.0, "church": 12.0, "rdk": 14.0, "admin": 13.0}
	for key: String in radii:
		if landmarks.has(key):
			var at := _lm_pos(key)
			if center.distance_to(Vector2(at.x, at.z)) < float(radii[key]):
				return true
	return false

func _roof_color(id: int, house: bool) -> Color:
	var colors := [
		Color("#626d70"), Color("#294a53"), Color("#604049"),
		Color("#486252"), Color("#895341"), Color("#7c807e")
	]
	return colors[id % colors.size()] if house else Color("#727675")

func _add_gabled_roof(surface: SurfaceTool, outline: PackedVector2Array, y: float, tint: Color) -> void:
	var i := 0 if outline[0].distance_to(outline[1]) <= outline[1].distance_to(outline[2]) else 1
	var corners: Array[Vector3] = []
	for offset in range(4):
		var p := outline[(i + offset) % 4]
		corners.append(Vector3(p.x, y, p.y))
	var rise := Vector3.UP * clampf(corners[0].distance_to(corners[1]) * 0.24, 0.6, 2.6)
	var a := corners[0].lerp(corners[1], 0.5) + rise
	var b := corners[2].lerp(corners[3], 0.5) + rise
	for point: Vector3 in [corners[0], corners[1], a, corners[2], corners[3], b,
			corners[1], corners[2], b, corners[1], b, a, corners[3], corners[0], a, corners[3], a, b]:
		surface.set_color(tint)
		surface.add_vertex(point)

func _build_pedestrian_spaces() -> void:
	var pavement := _triangle_surface()
	for line: Array in map_data.get("walking_paths", []):
		for i in range(1, line.size()):
			var a := Vector2(float(line[i - 1][0]), float(line[i - 1][2]))
			var b := Vector2(float(line[i][0]), float(line[i][2]))
			var side := (b - a).normalized().orthogonal() * 1.25
			var count := maxi(1, ceili(a.distance_to(b) / 4.0))
			for step in range(count):
				var left := a.lerp(b, float(step) / count)
				var right := a.lerp(b, float(step + 1) / count)
				_add_quad(pavement, _path_point(left - side), _path_point(right - side),
					_path_point(right + side), _path_point(left + side),
					Vector2.ZERO, Vector2.DOWN, Vector2.ONE, Vector2.RIGHT)
	_add_city_mesh(self, pavement, TextureBank.pbr_mat("paving", 1.0, false))
	if not landmarks.has("yashlek"):
		return
	var center := _lm_pos("yashlek")
	var boardwalk := _triangle_surface()
	for i in range(48):
		var a := TAU * float(i) / 48.0
		var b := TAU * float(i + 1) / 48.0
		var ca := Vector2(center.x + cos(a) * 23.0, center.z + sin(a) * 14.0)
		var cb := Vector2(center.x + cos(b) * 23.0, center.z + sin(b) * 14.0)
		var sa := Vector2(cos(a), sin(a)) * 1.3
		var sb := Vector2(cos(b), sin(b)) * 1.3
		_add_quad(boardwalk, _path_point(ca - sa, 0.20), _path_point(cb - sb, 0.20),
			_path_point(cb + sb, 0.20), _path_point(ca + sa, 0.20),
			Vector2.ZERO, Vector2.DOWN, Vector2.ONE, Vector2.RIGHT)
	_add_city_mesh(self, boardwalk, TextureBank.pbr_mat("wood_fortress", 1.0, false))
	_build_park_seating(center)
	var sign := Label3D.new()
	sign.text = "ЯШЬЛЕК"
	sign.font_size = 55
	sign.pixel_size = 0.016
	sign.position = center + Vector3(0, 2.2, 0)
	sign.billboard = BaseMaterial3D.BILLBOARD_FIXED_Y
	add_child(sign)

func _build_park_seating(center: Vector3) -> void:
	var seat := BoxMesh.new()
	seat.size = Vector3(2.2, 0.12, 0.52)
	var back := BoxMesh.new()
	back.size = Vector3(2.2, 0.32, 0.10)
	var support := BoxMesh.new()
	support.size = Vector3(0.12, 0.52, 0.48)
	var timber := _triangle_surface()
	var frame := _triangle_surface()
	for i in range(8):
		var angle := float(i) * TAU / 8.0
		var pos := _path_point(Vector2(center.x + cos(angle) * 26.0, center.z + sin(angle) * 17.0))
		var pose := Transform3D(Basis(Vector3.UP, -angle + PI * 0.5), pos)
		timber.append_from(seat, 0, pose.translated_local(Vector3(0, 0.49, 0)))
		timber.append_from(back, 0, pose.translated_local(Vector3(0, 0.73, 0.23)))
		for x in [-0.77, 0.77]:
			frame.append_from(support, 0, pose.translated_local(Vector3(x, 0.23, 0)))
	_add_city_mesh(self, timber, TextureBank.pbr_mat("wood_fortress", 1.0, false))
	_add_city_mesh(self, frame, TextureBank.pbr_mat("metal_brushed", 1.0, false))

func _path_point(point: Vector2, lift := 0.12) -> Vector3:
	return Vector3(point.x, sample_terrain_h(point.x, point.y) + lift, point.y)

func _build_trees_and_lights() -> void:
	# Group forest stands so nearby scenery does not draw the entire city's trees.
	var stands := {}
	for row: Array in map_data.get("trees", []):
		var position_on_map := Vector3(float(row[0]), float(row[1]), float(row[2]))
		var key := Vector2i(floori(position_on_map.x / 275.0), floori(position_on_map.z / 275.0))
		if not stands.has(key):
			stands[key] = []
		stands[key].append(position_on_map)
	var trunk := CylinderMesh.new()
	trunk.top_radius = 0.12
	trunk.bottom_radius = 0.24
	trunk.height = 3.4
	trunk.radial_segments = 6
	var crown := CylinderMesh.new()
	crown.top_radius = 0.12
	crown.bottom_radius = 2.25
	crown.height = 6.7
	crown.radial_segments = 7
	var leaves := StandardMaterial3D.new()
	leaves.albedo_color = Color("#345438")
	leaves.vertex_color_use_as_albedo = true
	leaves.roughness = 0.93
	for stand: Array in stands.values():
		var trunks := MultiMesh.new()
		trunks.transform_format = MultiMesh.TRANSFORM_3D
		trunks.mesh = trunk
		trunks.instance_count = stand.size()
		var crowns := MultiMesh.new()
		crowns.transform_format = MultiMesh.TRANSFORM_3D
		crowns.use_colors = true
		crowns.mesh = crown
		crowns.instance_count = stand.size()
		for i in range(stand.size()):
			var p: Vector3 = stand[i]
			var k := _rng.randf_range(0.65, 1.65)
			var basis := Basis.from_scale(Vector3(k, k, k))
			trunks.set_instance_transform(i, Transform3D(basis, p + Vector3.UP * 1.65 * k))
			crowns.set_instance_transform(i, Transform3D(basis, p + Vector3.UP * 5.2 * k))
			crowns.set_instance_color(i, Color.WHITE.darkened(_rng.randf_range(0.0, 0.28)))
		_add_forest_batch(trunks, TextureBank.pbr_mat("wood_fortress", 1.0, false))
		_add_forest_batch(crowns, leaves)

	# Streetlights along active race circuit (batched MultiMesh poles + glowing bulbs)
	var L := get_track_length()
	var n_poles := 80
	var mm_p := MultiMesh.new(); mm_p.transform_format = MultiMesh.TRANSFORM_3D
	var pm := CylinderMesh.new(); pm.top_radius = 0.09; pm.bottom_radius = 0.14; pm.height = 6.6
	mm_p.mesh = pm; mm_p.instance_count = n_poles

	var mm_b := MultiMesh.new(); mm_b.transform_format = MultiMesh.TRANSFORM_3D
	var bm := BoxMesh.new(); bm.size = Vector3(0.75, 0.2, 0.35)
	mm_b.mesh = bm; mm_b.instance_count = n_poles

	var lamp_mat := StandardMaterial3D.new()
	lamp_mat.albedo_color = Color(1.0, 0.9, 0.65)
	lamp_mat.emission_enabled = true; lamp_mat.emission = Color(1.0, 0.85, 0.5); lamp_mat.emission_energy_multiplier = 0.0
	night_glow_mats.append(lamp_mat)

	for i in range(n_poles):
		var d := (float(i) / float(n_poles)) * L
		var tr := sample_track(d)
		var side := -1.0 if i % 2 == 0 else 1.0
		var pp := tr.origin + tr.basis.x * (side * (ROAD_HALF_W + 1.2))
		mm_p.set_instance_transform(i, Transform3D(tr.basis, pp + Vector3(0, 3.3, 0)))
		mm_b.set_instance_transform(i, Transform3D(tr.basis, pp - tr.basis.x * (side * 0.6) + Vector3(0, 6.5, 0)))
		if i % 6 == 0:
			var nl := OmniLight3D.new(); nl.light_color = Color(1.0, 0.82, 0.52); nl.light_energy = 0.0; nl.omni_range = 20.0
			nl.position = pp + Vector3(0, 6.1, 0); add_child(nl); night_lights.append(nl)

	var mmi_p := MultiMeshInstance3D.new(); mmi_p.multimesh = mm_p; mmi_p.material_override = TextureBank.pbr_mat("metal_brushed", 1.0, true); add_child(mmi_p)
	var mmi_b := MultiMeshInstance3D.new(); mmi_b.multimesh = mm_b; mmi_b.material_override = lamp_mat; add_child(mmi_b)

func _add_forest_batch(batch: MultiMesh, material: Material) -> void:
	var instance := MultiMeshInstance3D.new()
	instance.multimesh = batch
	instance.material_override = material
	instance.visibility_range_end = 800.0 if OS.has_feature("mobile") else 1350.0
	instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(instance)

func _build_destructibles() -> void:
	destructibles_root = Node3D.new(); destructibles_root.name = "Destructibles"; add_child(destructibles_root)
	roadblocks_root = Node3D.new(); roadblocks_root.name = "Roadblocks"; add_child(roadblocks_root)
	var cone_mat := StandardMaterial3D.new(); cone_mat.albedo_color = Color(0.95, 0.38, 0.06); cone_mat.roughness = 0.55
	var crate_mat := TextureBank.pbr_mat("wood_fortress", 1.0, true)
	var L := get_track_length()
	for i in range(24):
		var d := fmod(55.0 + float(i) * (L / 24.0), L)
		var tr := sample_track(d)
		var side := -1.0 if i % 2 == 0 else 1.0
		var base := tr.origin + tr.basis.x * (side * (ROAD_HALF_W - 0.6))
		for j in range(2):
			var rb := RigidBody3D.new(); rb.collision_layer = 2; rb.collision_mask = 1 | 2 | 4
			rb.mass = 14.0 if j == 0 else 28.0
			rb.position = base + tr.basis.z * (float(j) * 2.2) + Vector3(0, 0.5, 0)
			var mi := MeshInstance3D.new(); var cs := CollisionShape3D.new()
			if j == 0:
				var cm := CylinderMesh.new(); cm.top_radius = 0.09; cm.bottom_radius = 0.28; cm.height = 0.72
				mi.mesh = cm; mi.material_override = cone_mat
				var sh := CylinderShape3D.new(); sh.radius = 0.28; sh.height = 0.72; cs.shape = sh
			else:
				var bm := BoxMesh.new(); bm.size = Vector3(0.85, 0.85, 0.85)
				mi.mesh = bm; mi.material_override = crate_mat
				var sh := BoxShape3D.new(); sh.size = Vector3(0.85, 0.85, 0.85); cs.shape = sh
			rb.add_child(mi); rb.add_child(cs); destructibles_root.add_child(rb)

func _build_checkpoints() -> void:
	if checkpoints_root:
		checkpoints_root.queue_free()
	checkpoints_root = Node3D.new(); checkpoints_root.name = "Checkpoints"; add_child(checkpoints_root)
	checkpoint_positions.clear()
	var L := get_track_length()
	var count := clampi(ceili(L / 150.0), 12, 80)
	for i in range(count):
		var d := (float(i) / float(count)) * L
		var tr := sample_track(d)
		checkpoint_positions.append({"dist": d, "pos": tr.origin, "transform": tr})

func spawn_roadblock_at_pos(pos: Vector3, dir: Vector3) -> void:
	if roadblocks_root.get_child_count() > 16:
		for old in roadblocks_root.get_children().slice(0, 4):
			old.queue_free()
	var fwd := Vector3(dir.x, 0.0, dir.z).normalized()
	if fwd.length_squared() < 0.01: fwd = Vector3.FORWARD
	var right := fwd.cross(Vector3.UP).normalized()
	var tr := Transform3D(Basis(right, Vector3.UP, -fwd), pos)
	var bar_mat := TextureBank.curb_redwhite_material()
	for off_x in [-3.6, 0.0, 3.6]:
		var rb := RigidBody3D.new(); rb.collision_layer = 2; rb.collision_mask = 1 | 2 | 4; rb.mass = 65.0
		rb.transform = tr; rb.position += right * off_x + Vector3(0, 0.65, 0)
		var mi := MeshInstance3D.new(); var bm := BoxMesh.new(); bm.size = Vector3(3.0, 1.05, 0.45)
		mi.mesh = bm; mi.material_override = bar_mat
		var cs := CollisionShape3D.new(); var sh := BoxShape3D.new(); sh.size = Vector3(3.0, 1.05, 0.45); cs.shape = sh
		rb.add_child(mi); rb.add_child(cs); roadblocks_root.add_child(rb)

func clear_roadblocks() -> void:
	if roadblocks_root:
		for c in roadblocks_root.get_children(): c.queue_free()

func set_night_state(is_night: bool, is_wet := false) -> void:
	if road_mesh_inst:
		road_mesh_inst.material_override = TextureBank.road_material(is_wet)
	for fm in facade_mats: fm.emission_energy_multiplier = 1.15 if is_night else 0.0
	for gm in night_glow_mats: gm.emission_energy_multiplier = 2.0 if is_night else 0.18
	for nl in night_lights: nl.light_energy = 1.75 if is_night else 0.0

# --- Street Graph Navigation, Nearest Road Recovery & Water Detection ---
func get_nearest_graph_node(pos: Vector3) -> int:
	var best_i := 0; var best_d2 := 1e18
	for i in range(graph_nodes.size()):
		var p := graph_nodes[i]
		var d2 := (p.x - pos.x) * (p.x - pos.x) + (p.z - pos.z) * (p.z - pos.z)
		if d2 < best_d2:
			best_d2 = d2; best_i = i
	return best_i

func get_nearest_road_transform(pos: Vector3) -> Transform3D:
	if graph_nodes.is_empty():
		return spawn_transform
	var ni := get_nearest_graph_node(pos)
	var p := graph_nodes[ni]
	var fwd := Vector3.FORWARD
	var adj: Array = graph_adj[ni] if ni < graph_adj.size() else []
	if not adj.is_empty():
		var nb_idx := int(adj[0][0])
		fwd = (graph_nodes[nb_idx] - p)
		fwd.y = 0.0
		if fwd.length_squared() < 0.01: fwd = Vector3.FORWARD
		else: fwd = fwd.normalized()
	var right := fwd.cross(Vector3.UP).normalized()
	return Transform3D(Basis(right, Vector3.UP, -fwd), Vector3(p.x, maxf(p.y, sample_terrain_h(p.x, p.z)) + 0.35, p.z))

func get_street_spawn_near(center: Vector3, min_d: float, max_d: float, face_pos: Vector3, avoid_pts: Array[Vector3] = []) -> Transform3D:
	var best_idx := -1
	var candidates: Array[int] = []
	for i in range(graph_nodes.size()):
		var p := graph_nodes[i]
		if graph_adj[i].is_empty() or p.x < x_min + 45.0 or p.x > x_max - 45.0 or p.z < z_min + 45.0 or p.z > z_max - 45.0:
			continue
		var d := Vector2(p.x - center.x, p.z - center.z).length()
		if d >= min_d and d <= max_d:
			var ok := true
			for ap in avoid_pts:
				if p.distance_to(ap) < 18.0:
					ok = false; break
			if ok:
				candidates.append(i)
	if candidates.is_empty():
		return get_nearest_road_transform(center + Vector3(min_d, 0.0, 0.0))
	best_idx = candidates[randi() % candidates.size()]
	var sp := graph_nodes[best_idx]
	var best_fwd := Vector3.FORWARD
	var best_dot := -2.0
	var to_face := (face_pos - sp); to_face.y = 0.0
	if to_face.length_squared() > 0.01: to_face = to_face.normalized()
	var adj: Array = graph_adj[best_idx] if best_idx < graph_adj.size() else []
	for e_item in adj:
		var e: Array = e_item
		var nb := graph_nodes[int(e[0])]
		var dir := (nb - sp); dir.y = 0.0
		if dir.length_squared() > 0.01:
			dir = dir.normalized()
			var dt := dir.dot(to_face)
			if dt > best_dot:
				best_dot = dt; best_fwd = dir
	var right := best_fwd.cross(Vector3.UP).normalized()
	return Transform3D(Basis(right, Vector3.UP, -best_fwd), Vector3(sp.x, maxf(sp.y, sample_terrain_h(sp.x, sp.z)) + 0.35, sp.z))

func is_in_water(pos: Vector3) -> bool:
	return pos.y < water_y + 0.24 and sample_terrain_h(pos.x, pos.z) < water_y - 0.05

func find_path_astar(start_pos: Vector3, goal_pos: Vector3) -> PackedVector3Array:
	if graph_nodes.is_empty():
		return PackedVector3Array()
	return _street_router.get_point_path(get_nearest_graph_node(start_pos), get_nearest_graph_node(goal_pos))
