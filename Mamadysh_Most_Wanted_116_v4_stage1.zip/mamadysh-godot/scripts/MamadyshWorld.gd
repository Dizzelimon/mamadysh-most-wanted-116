extends Node3D
class_name MamadyshWorld

var map_data: Dictionary = {}
var bounds: Dictionary = {}
var terrain_h: PackedFloat32Array = PackedFloat32Array()
var grid_n := 180
var x_min := -1880.0
var x_max := 1520.0
var z_min := -1750.0
var z_max := 1550.0
var water_y := 0.4

var vyatka_bank: Array = []
var oshma_pts: Array = []
var graph_nodes: PackedVector3Array = PackedVector3Array()
var graph_adj: Array = []
var landmarks: Dictionary = {}

var road_curve: Curve3D
var race_curve: Curve3D
var olimp_curve: Curve3D
var active_circuit_name := "race"

var road_mesh_inst: MeshInstance3D
var facade_mats: Array[StandardMaterial3D] = []
var night_glow_mats: Array[StandardMaterial3D] = []
var night_lights: Array[Light3D] = []
var checkpoint_positions: Array[Dictionary] = []
var spawn_transform: Transform3D
var destructibles_root: Node3D
var roadblocks_root: Node3D
var checkpoints_root: Node3D
var _rng := RandomNumberGenerator.new()

const ROAD_HALF_W := 6.2

func load_map_json() -> void:
	if not map_data.is_empty():
		return
	var f := FileAccess.open("res://assets/map/mamadysh_map.json", FileAccess.READ)
	if f == null:
		push_error("Cannot open res://assets/map/mamadysh_map.json")
		return
	var txt := f.get_as_text()
	f.close()
	var parsed: Variant = JSON.parse_string(txt)
	if typeof(parsed) != TYPE_DICTIONARY:
		push_error("Invalid mamadysh_map.json format")
		return
	map_data = parsed
	bounds = map_data.get("bounds", {})
	grid_n = int(bounds.get("grid_n", 180))
	x_min = float(bounds.get("x_min", -1880.0))
	x_max = float(bounds.get("x_max", 1520.0))
	z_min = float(bounds.get("z_min", -1750.0))
	z_max = float(bounds.get("z_max", 1550.0))
	water_y = float(bounds.get("water_y", 0.4))

	var th_raw: Array = map_data.get("terrain_h", [])
	terrain_h.resize(th_raw.size())
	for i in range(th_raw.size()):
		terrain_h[i] = float(th_raw[i])

	vyatka_bank = map_data.get("vyatka_bank", [])
	oshma_pts = map_data.get("oshma", [])
	landmarks = map_data.get("landmarks", {})

	var gn_raw: Array = map_data.get("graph_nodes", [])
	graph_nodes.resize(gn_raw.size())
	for i in range(gn_raw.size()):
		var p: Array = gn_raw[i]
		graph_nodes[i] = Vector3(float(p[0]), float(p[1]), float(p[2]))
	graph_adj = map_data.get("graph_adj", [])

func build_world(is_night := false, circuit_id := "race") -> void:
	_rng.seed = 11616
	load_map_json()
	active_circuit_name = circuit_id
	for c in get_children():
		c.queue_free()
	facade_mats.clear()
	night_glow_mats.clear()
	night_lights.clear()
	checkpoint_positions.clear()

	_init_circuits()
	_build_terrain_and_water()
	_build_all_roads_and_bridges()
	_build_mamadysh_landmarks()
	_build_city_buildings()
	_build_trees_and_lights()
	_build_destructibles()
	_build_checkpoints()
	set_night_state(is_night)

func sample_terrain_h(x: float, z: float) -> float:
	if terrain_h.is_empty():
		return 10.0
	var cell_x := (x_max - x_min) / float(grid_n - 1)
	var cell_z := (z_max - z_min) / float(grid_n - 1)
	var u := clampf((x - x_min) / cell_x, 0.0, float(grid_n - 1) - 0.001)
	var v := clampf((z - z_min) / cell_z, 0.0, float(grid_n - 1) - 0.001)
	var i0 := int(u)
	var j0 := int(v)
	var fu := u - float(i0)
	var fv := v - float(j0)
	var h00 := terrain_h[j0 * grid_n + i0]
	var h10 := terrain_h[j0 * grid_n + i0 + 1]
	var h01 := terrain_h[(j0 + 1) * grid_n + i0]
	var h11 := terrain_h[(j0 + 1) * grid_n + i0 + 1]
	return (h00 * (1.0 - fu) + h10 * fu) * (1.0 - fv) + (h01 * (1.0 - fu) + h11 * fu) * fv

func set_active_circuit(circuit_id: String) -> void:
	active_circuit_name = circuit_id
	road_curve = olimp_curve if (circuit_id == "olimp" and olimp_curve != null) else race_curve
	if road_curve and road_curve.point_count > 1:
		var p0 := road_curve.sample_baked(0.0, true)
		var p1 := road_curve.sample_baked(6.0, true)
		var fwd := (p1 - p0).normalized()
		var up := Vector3.UP
		var right := fwd.cross(up).normalized()
		up = right.cross(fwd).normalized()
		spawn_transform = Transform3D(Basis(right, up, -fwd), p0 + Vector3(0.0, 0.25, 0.0))
	if is_inside_tree():
		_build_checkpoints()

func _build_curve_from_pts(raw_pts: Array) -> Curve3D:
	var c := Curve3D.new()
	c.bake_interval = 3.0
	var pts: Array[Vector3] = []
	for item in raw_pts:
		var a: Array = item
		var p := Vector3(float(a[0]), float(a[1]), float(a[2]))
		if pts.is_empty() or pts[-1].distance_to(p) > 2.5:
			pts.append(p)
	if pts.size() >= 2 and pts[0].distance_to(pts[-1]) < 4.0:
		pts.pop_back()
	var n := pts.size()
	for i in range(n + 1):
		var idx := i % n
		var p_prev := pts[(idx - 1 + n) % n]
		var p_curr := pts[idx]
		var p_next := pts[(idx + 1) % n]
		var d_in := (p_curr - p_prev).length()
		var d_out := (p_next - p_curr).length()
		var tang := (p_next - p_prev)
		if tang.length_squared() < 0.01:
			tang = Vector3.FORWARD
		else:
			tang = tang.normalized()
		var hl := minf(d_in, d_out) * 0.28
		c.add_point(p_curr, -tang * hl, tang * hl)
	return c

func _init_circuits() -> void:
	race_curve = _build_curve_from_pts(map_data.get("race_circuit", []))
	olimp_curve = _build_curve_from_pts(map_data.get("olimp_circuit", []))
	set_active_circuit(active_circuit_name)

func get_track_length() -> float:
	return road_curve.get_baked_length() if road_curve else 100.0

func sample_track(dist: float) -> Transform3D:
	var L := get_track_length()
	var d := fposmod(dist, L)
	var p := road_curve.sample_baked(d, true)
	var p_ahead := road_curve.sample_baked(fposmod(d + 5.0, L), true)
	var fwd := (p_ahead - p).normalized()
	if fwd.length_squared() < 0.001:
		fwd = Vector3.FORWARD
	var up := Vector3.UP
	var right := fwd.cross(up).normalized()
	up = right.cross(fwd).normalized()
	return Transform3D(Basis(right, up, -fwd), p)

func _build_terrain_and_water() -> void:
	var terrain_body := StaticBody3D.new()
	terrain_body.name = "MamadyshTerrain"
	terrain_body.collision_layer = 1
	terrain_body.collision_mask = 0
	terrain_body.add_to_group("Grass")
	add_child(terrain_body)

	var cell_x := (x_max - x_min) / float(grid_n - 1)
	var cell_z := (z_max - z_min) / float(grid_n - 1)
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)

	for j in range(grid_n - 1):
		var z0 := z_min + float(j) * cell_z
		var z1 := z_min + float(j + 1) * cell_z
		for i in range(grid_n - 1):
			var x0 := x_min + float(i) * cell_x
			var x1 := x_min + float(i + 1) * cell_x
			var h00 := terrain_h[j * grid_n + i]
			var h10 := terrain_h[j * grid_n + i + 1]
			var h01 := terrain_h[(j + 1) * grid_n + i]
			var h11 := terrain_h[(j + 1) * grid_n + i + 1]
			var p00 := Vector3(x0, h00, z0)
			var p10 := Vector3(x1, h10, z0)
			var p01 := Vector3(x0, h01, z1)
			var p11 := Vector3(x1, h11, z1)
			_add_terrain_tri(st, p00, p10, p11)
			_add_terrain_tri(st, p00, p11, p01)

	st.generate_normals()
	var t_mesh := st.commit()
	var t_inst := MeshInstance3D.new()
	t_inst.mesh = t_mesh
	var t_mat := TextureBank.pbr_mat("grass", 0.06, true).duplicate() as StandardMaterial3D
	t_mat.vertex_color_use_as_albedo = true
	t_inst.material_override = t_mat
	terrain_body.add_child(t_inst)

	var t_col := CollisionShape3D.new()
	t_col.shape = t_mesh.create_trimesh_shape()
	terrain_body.add_child(t_col)

	# World outer containment barrier walls so cars stay inside Mamadysh
	var wall_body := StaticBody3D.new()
	wall_body.name = "WorldBounds"
	wall_body.collision_layer = 2
	wall_body.collision_mask = 0
	add_child(wall_body)
	var span_x := x_max - x_min
	var span_z := z_max - z_min
	var mid_x := (x_min + x_max) * 0.5
	var mid_z := (z_min + z_max) * 0.5
	var walls := [
		[Vector3(mid_x, 40.0, z_min + 12.0), Vector3(span_x, 160.0, 6.0)],
		[Vector3(mid_x, 40.0, z_max - 12.0), Vector3(span_x, 160.0, 6.0)],
		[Vector3(x_min + 12.0, 40.0, mid_z), Vector3(6.0, 160.0, span_z)],
		[Vector3(x_max - 12.0, 40.0, mid_z), Vector3(6.0, 160.0, span_z)],
	]
	for w in walls:
		var wc := CollisionShape3D.new()
		var bs := BoxShape3D.new(); bs.size = w[1]
		wc.shape = bs; wc.position = w[0]
		wall_body.add_child(wc)

	# Vyatka River + Oshma River Mesh
	var st_water := SurfaceTool.new()
	st_water.begin(Mesh.PRIMITIVE_TRIANGLES)
	for i in range(vyatka_bank.size() - 1):
		var a: Array = vyatka_bank[i]
		var b: Array = vyatka_bank[i + 1]
		var p0 := Vector3(float(a[0]) - 8.0, water_y, float(a[1]))
		var p1 := Vector3(x_max + 900.0, water_y, float(a[1]))
		var p2 := Vector3(x_max + 900.0, water_y, float(b[1]))
		var p3 := Vector3(float(b[0]) - 8.0, water_y, float(b[1]))
		_add_quad(st_water, p0, p1, p2, p3, Vector2(0, 0), Vector2(1, 0), Vector2(1, 1), Vector2(0, 1))

	for i in range(oshma_pts.size() - 1):
		var a: Array = oshma_pts[i]
		var b: Array = oshma_pts[i + 1]
		var pa := Vector3(float(a[0]), water_y + 0.02, float(a[1]))
		var pb := Vector3(float(b[0]), water_y + 0.02, float(b[1]))
		var dir := (pb - pa)
		if dir.length_squared() < 0.01:
			continue
		var side := Vector3(-dir.z, 0.0, dir.x).normalized() * 24.0
		_add_quad(st_water, pa - side, pb - side, pb + side, pa + side, Vector2(0, 0), Vector2(0, 1), Vector2(1, 1), Vector2(1, 0))

	st_water.generate_normals()
	var w_mesh := MeshInstance3D.new()
	w_mesh.mesh = st_water.commit()
	w_mesh.material_override = TextureBank.water_material()
	add_child(w_mesh)

func _add_terrain_tri(st: SurfaceTool, p0: Vector3, p1: Vector3, p2: Vector3) -> void:
	for p: Vector3 in [p0, p1, p2]:
		var col := Color(0.92, 0.96, 0.88)
		if p.y < water_y + 0.7:
			col = Color(0.84, 0.78, 0.62)  # Sandy shoreline
		elif p.y > 68.0:
			col = Color(0.76, 0.86, 0.68)  # Puzanka sunlit slope
		st.set_color(col)
		st.add_vertex(p)

func _build_all_roads_and_bridges() -> void:
	var roads: Array = map_data.get("roads", [])
	var st_road := SurfaceTool.new()
	var st_side := SurfaceTool.new()
	var st_bridge_conc := SurfaceTool.new()
	var st_guard := SurfaceTool.new()
	st_road.begin(Mesh.PRIMITIVE_TRIANGLES)
	st_side.begin(Mesh.PRIMITIVE_TRIANGLES)
	st_bridge_conc.begin(Mesh.PRIMITIVE_TRIANGLES)
	st_guard.begin(Mesh.PRIMITIVE_TRIANGLES)

	for r_item in roads:
		var r: Dictionary = r_item
		var pts_raw: Array = r.get("pts", [])
		if pts_raw.size() < 2:
			continue
		var hw := float(r.get("w", 8.0)) * 0.5
		var is_bridge := int(r.get("br", 0)) == 1
		var is_main := String(r.get("hw", "")) == "secondary"

		# Subdivide long segments <= 12m so asphalt follows rolling Mamadysh slopes cleanly
		var sub_pts: Array[Vector3] = []
		for i in range(pts_raw.size()):
			var a: Array = pts_raw[i]
			var p := Vector3(float(a[0]), float(a[1]), float(a[2]))
			if i > 0:
				var prev := sub_pts[-1]
				var seg_len := prev.distance_to(p)
				var steps := maxi(1, int(ceilf(seg_len / 12.0)))
				for s in range(1, steps + 1):
					var t := float(s) / float(steps)
					var sp := prev.lerp(p, t)
					if not is_bridge:
						sp.y = maxf(sp.y, sample_terrain_h(sp.x, sp.z)) + (0.10 if is_main else 0.05)
					else:
						sp.y += 0.14
					sub_pts.append(sp)
			else:
				if not is_bridge:
					p.y = maxf(p.y, sample_terrain_h(p.x, p.z)) + (0.10 if is_main else 0.05)
				else:
					p.y += 0.14
				sub_pts.append(p)

		if not is_bridge and sub_pts.size() >= 3:
			for _pass in range(2):
				var sy: Array[float] = [sub_pts[0].y]
				for k in range(1, sub_pts.size() - 1):
					sy.append(0.25 * sub_pts[k - 1].y + 0.50 * sub_pts[k].y + 0.25 * sub_pts[k + 1].y)
				sy.append(sub_pts[-1].y)
				for k in range(1, sub_pts.size() - 1):
					sub_pts[k].y = maxf(sy[k], sample_terrain_h(sub_pts[k].x, sub_pts[k].z) + (0.09 if is_main else 0.04))

		var target_st := st_road if is_main else st_side
		var v_acc := 0.0
		var n_pts := sub_pts.size()
		var prev_l := Vector3.ZERO
		var prev_r := Vector3.ZERO
		for i in range(n_pts):
			var p := sub_pts[i]
			var fwd := (sub_pts[mini(i + 1, n_pts - 1)] - sub_pts[maxi(i - 1, 0)])
			fwd.y = 0.0
			if fwd.length_squared() < 0.001:
				fwd = Vector3.FORWARD
			fwd = fwd.normalized()
			var right := fwd.cross(Vector3.UP).normalized()
			var cur_l := p - right * hw
			var cur_r := p + right * hw
			if i > 0:
				v_acc += sub_pts[i - 1].distance_to(p)
				var va := (v_acc - sub_pts[i - 1].distance_to(p)) / 14.0
				var vb := v_acc / 14.0
				_add_quad(target_st, prev_l, cur_l, cur_r, prev_r, Vector2(0, va), Vector2(0, vb), Vector2(1, vb), Vector2(1, va))

				# Curb & skirt edges so roads sit solidly on terrain
				var sk_a_l := prev_l - right * 1.1 - Vector3(0, 0.85, 0)
				var sk_b_l := cur_l - right * 1.1 - Vector3(0, 0.85, 0)
				var sk_a_r := prev_r + right * 1.1 - Vector3(0, 0.85, 0)
				var sk_b_r := cur_r + right * 1.1 - Vector3(0, 0.85, 0)
				_add_quad(st_bridge_conc, sk_a_l, sk_b_l, cur_l, prev_l, Vector2(0, va), Vector2(0, vb), Vector2(1, vb), Vector2(1, va))
				_add_quad(st_bridge_conc, prev_r, cur_r, sk_b_r, sk_a_r, Vector2(0, va), Vector2(0, vb), Vector2(1, vb), Vector2(1, va))

				if is_bridge:
					# Bridge concrete deck underside + safety guardrails
					var u_al := prev_l - Vector3(0, 0.9, 0)
					var u_bl := cur_l - Vector3(0, 0.9, 0)
					var u_ar := prev_r - Vector3(0, 0.9, 0)
					var u_br := cur_r - Vector3(0, 0.9, 0)
					_add_quad(st_bridge_conc, prev_r, cur_r, u_br, u_ar, Vector2(0, 0), Vector2(0, 1), Vector2(1, 1), Vector2(1, 0))
					_add_quad(st_bridge_conc, u_al, u_bl, cur_l, prev_l, Vector2(0, 0), Vector2(0, 1), Vector2(1, 1), Vector2(1, 0))
					for s_edge in [prev_l, prev_r]:
						var b_edge := cur_l if s_edge == prev_l else cur_r
						_add_quad(st_guard, s_edge, s_edge + Vector3(0, 1.05, 0), b_edge + Vector3(0, 1.05, 0), b_edge,
								  Vector2(0, 0), Vector2(0, 1), Vector2(1, 1), Vector2(1, 0))
			prev_l = cur_l
			prev_r = cur_r

		if is_bridge and sub_pts.size() >= 2:
			var mid := sub_pts[sub_pts.size() / 2]
			var pier := MeshInstance3D.new()
			var pm := BoxMesh.new(); pm.size = Vector3(hw * 1.8, mid.y + 4.0, 2.8)
			pier.mesh = pm; pier.position = Vector3(mid.x, (mid.y - 4.0) * 0.5, mid.z)
			pier.material_override = TextureBank.pbr_mat("concrete", 0.3, true)
			add_child(pier)

	st_road.generate_normals(); st_road.generate_tangents()
	st_side.generate_normals(); st_side.generate_tangents()
	st_bridge_conc.generate_normals()
	st_guard.generate_normals()

	var road_body := StaticBody3D.new()
	road_body.name = "MamadyshRoadNetwork"
	road_body.collision_layer = 1
	road_body.collision_mask = 0
	road_body.add_to_group("Road")
	add_child(road_body)

	var main_mesh := st_road.commit()
	road_mesh_inst = MeshInstance3D.new()
	road_mesh_inst.mesh = main_mesh
	road_mesh_inst.material_override = TextureBank.road_material(false)
	road_body.add_child(road_mesh_inst)

	var side_mesh := st_side.commit()
	if side_mesh.get_surface_count() > 0:
		var side_inst := MeshInstance3D.new()
		side_inst.mesh = side_mesh
		side_inst.material_override = TextureBank.pbr_mat("asphalt_shoulder", 1.0, false)
		road_body.add_child(side_inst)
		var sc := CollisionShape3D.new(); sc.shape = side_mesh.create_trimesh_shape()
		road_body.add_child(sc)

	var mc := CollisionShape3D.new(); mc.shape = main_mesh.create_trimesh_shape()
	road_body.add_child(mc)

	var conc_mesh := st_bridge_conc.commit()
	if conc_mesh.get_surface_count() > 0:
		var ci := MeshInstance3D.new(); ci.mesh = conc_mesh
		ci.material_override = TextureBank.pbr_mat("concrete", 0.25, true)
		road_body.add_child(ci)

	var g_mesh := st_guard.commit()
	if g_mesh.get_surface_count() > 0:
		var gb := StaticBody3D.new(); gb.name = "BridgeGuardrails"; gb.collision_layer = 2; gb.collision_mask = 0
		add_child(gb)
		var gi := MeshInstance3D.new(); gi.mesh = g_mesh
		var gmat := TextureBank.pbr_mat("metal_brushed", 0.6, true).duplicate() as StandardMaterial3D
		gmat.cull_mode = BaseMaterial3D.CULL_DISABLED
		gi.material_override = gmat
		gb.add_child(gi)
		var gc := CollisionShape3D.new(); gc.shape = g_mesh.create_trimesh_shape()
		gb.add_child(gc)

func _add_quad(st: SurfaceTool, p0: Vector3, p1: Vector3, p2: Vector3, p3: Vector3, uv0: Vector2, uv1: Vector2, uv2: Vector2, uv3: Vector2) -> void:
	st.set_uv(uv0); st.add_vertex(p0)
	st.set_uv(uv1); st.add_vertex(p1)
	st.set_uv(uv2); st.add_vertex(p2)
	st.set_uv(uv0); st.add_vertex(p0)
	st.set_uv(uv2); st.add_vertex(p2)
	st.set_uv(uv3); st.add_vertex(p3)

func _lm_pos(key: String) -> Vector3:
	if not landmarks.has(key):
		return Vector3.ZERO
	var p: Array = landmarks[key]["pos"]
	var x := float(p[0]); var z := float(p[2])
	return Vector3(x, sample_terrain_h(x, z), z)

func _build_mamadysh_landmarks() -> void:
	# Start/Finish arch right on race_circuit[0] (Sovetskaya St / Lenin Square)
	if race_curve and race_curve.point_count > 1:
		var tr0 := sample_track(14.0)
		_build_start_arch(tr0)

	if landmarks.has("eiffel"): _build_eiffel_tower(_lm_pos("eiffel"))
	if landmarks.has("memorial"): _build_memorial(_lm_pos("memorial"))
	if landmarks.has("embankment"): _build_vyatka_embankment(_lm_pos("embankment"))
	if landmarks.has("olimp"): _build_olimp_ice_palace(_lm_pos("olimp"))
	if landmarks.has("lenin"): _build_lenin_monument(_lm_pos("lenin"))
	if landmarks.has("rdk"): _build_rdk_palace(_lm_pos("rdk"))
	if landmarks.has("admin"): _build_admin_building(_lm_pos("admin"))
	if landmarks.has("church"): _build_church(_lm_pos("church"))
	if landmarks.has("puzanka"): _build_puzanka_pavilion(_lm_pos("puzanka"))

func _add_landmark_collider(parent: Node3D, sz: Vector3, offset: Vector3) -> void:
	var sb := StaticBody3D.new(); sb.collision_layer = 2; sb.collision_mask = 0
	var cs := CollisionShape3D.new(); var bs := BoxShape3D.new(); bs.size = sz
	cs.shape = bs; cs.position = offset
	sb.add_child(cs); parent.add_child(sb)

func _build_start_arch(tr: Transform3D) -> void:
	var arch := Node3D.new(); arch.transform = tr; add_child(arch)
	var steel := TextureBank.pbr_mat("metal_brushed", 0.5, true)
	var banner := StandardMaterial3D.new()
	banner.albedo_color = Color(0.08, 0.09, 0.12)
	banner.emission_enabled = true; banner.emission = Color(1.0, 0.65, 0.12); banner.emission_energy_multiplier = 0.85
	for sx in [-7.6, 7.6]:
		var col := MeshInstance3D.new(); var bm := BoxMesh.new(); bm.size = Vector3(0.75, 7.2, 0.75)
		col.mesh = bm; col.position = Vector3(sx, 3.6, 0); col.material_override = steel; arch.add_child(col)
		_add_landmark_collider(arch, Vector3(0.85, 6.0, 0.85), Vector3(sx, 3.0, 0))
	var top := MeshInstance3D.new(); var tm := BoxMesh.new(); tm.size = Vector3(16.4, 1.9, 1.0)
	top.mesh = tm; top.position = Vector3(0, 6.8, 0); top.material_override = banner; arch.add_child(top)
	for s in [-1.0, 1.0]:
		var lbl := Label3D.new(); lbl.text = "МАМАДЫШ • MOST WANTED 116"; lbl.font_size = 68
		lbl.modulate = Color(1.0, 0.88, 0.25); lbl.position = Vector3(0, 6.8, s * 0.58)
		if s < 0.0: lbl.rotation_degrees.y = 180.0
		arch.add_child(lbl)

func _build_eiffel_tower(pos: Vector3) -> void:
	var tower := Node3D.new(); tower.position = pos; add_child(tower)
	var iron := StandardMaterial3D.new(); iron.albedo_color = Color(0.24, 0.21, 0.19); iron.metallic = 0.82; iron.roughness = 0.42
	var gold := StandardMaterial3D.new(); gold.albedo_color = Color(1.0, 0.82, 0.35); gold.emission_enabled = true
	gold.emission = Color(1.0, 0.72, 0.22); gold.emission_energy_multiplier = 0.2; night_glow_mats.append(gold)

	var ped := MeshInstance3D.new(); var pm := BoxMesh.new(); pm.size = Vector3(7.6, 1.2, 7.6)
	ped.mesh = pm; ped.position = Vector3(0, 0.4, 0); ped.material_override = TextureBank.pbr_mat("paving", 0.35, true)
	tower.add_child(ped)
	_add_landmark_collider(tower, Vector3(6.8, 14.0, 6.8), Vector3(0, 7.0, 0))

	var levels := [[2.7, 0.8], [1.45, 5.8], [0.70, 10.4], [0.18, 14.2]]
	for idx in range(levels.size() - 1):
		var r0: float = levels[idx][0]; var y0: float = levels[idx][1]
		var r1: float = levels[idx + 1][0]; var y1: float = levels[idx + 1][1]
		for sx in [-1.0, 1.0]:
			for sz in [-1.0, 1.0]:
				tower.add_child(_make_beam(Vector3(sx * r0, y0, sz * r0), Vector3(sx * r1, y1, sz * r1), 0.24 if idx == 0 else 0.15, iron))
		var deck := MeshInstance3D.new(); var dm := BoxMesh.new(); dm.size = Vector3(r1 * 2.4, 0.34, r1 * 2.4)
		deck.mesh = dm; deck.position = Vector3(0, y1, 0); deck.material_override = gold if idx < 2 else iron; tower.add_child(deck)
	var spire := MeshInstance3D.new(); var sm := CylinderMesh.new(); sm.top_radius = 0.04; sm.bottom_radius = 0.16; sm.height = 3.0
	spire.mesh = sm; spire.position = Vector3(0, 15.6, 0); spire.material_override = gold; tower.add_child(spire)
	var tl := OmniLight3D.new(); tl.light_color = Color(1.0, 0.78, 0.35); tl.light_energy = 0.0; tl.omni_range = 28.0
	tl.position = Vector3(0, 10.0, 0); tower.add_child(tl); night_lights.append(tl)

func _build_memorial(pos: Vector3) -> void:
	var mem := Node3D.new(); mem.position = pos; add_child(mem)
	var gran := TextureBank.pbr_mat("stone_blocks", 0.35, true)
	var dark_gran := StandardMaterial3D.new(); dark_gran.albedo_color = Color(0.14, 0.14, 0.16); dark_gran.roughness = 0.35
	var base := MeshInstance3D.new(); var bm := BoxMesh.new(); bm.size = Vector3(14.0, 1.0, 10.0)
	base.mesh = bm; base.position = Vector3(0, 0.3, 0); base.material_override = gran; mem.add_child(base)
	var wall := MeshInstance3D.new(); var wm := BoxMesh.new(); wm.size = Vector3(11.0, 4.2, 1.2)
	wall.mesh = wm; wall.position = Vector3(0, 2.8, -3.2); wall.material_override = dark_gran; mem.add_child(wall)
	var ob := MeshInstance3D.new(); var om := BoxMesh.new(); om.size = Vector3(1.6, 11.5, 1.6)
	ob.mesh = om; ob.position = Vector3(0, 6.2, -3.0); ob.material_override = dark_gran; mem.add_child(ob)
	var flame := MeshInstance3D.new(); var fm := CylinderMesh.new(); fm.top_radius = 0.05; fm.bottom_radius = 0.45; fm.height = 1.2
	var flm := StandardMaterial3D.new(); flm.albedo_color = Color(1.0, 0.55, 0.1); flm.emission_enabled = true
	flm.emission = Color(1.0, 0.48, 0.08); flm.emission_energy_multiplier = 3.2; night_glow_mats.append(flm)
	flame.mesh = fm; flame.position = Vector3(0, 1.5, 0.8); flame.material_override = flm; mem.add_child(flame)
	var lbl := Label3D.new(); lbl.text = "1941 — 1945"; lbl.font_size = 72; lbl.modulate = Color(0.95, 0.78, 0.28)
	lbl.position = Vector3(0, 3.6, -2.55); mem.add_child(lbl)
	_add_landmark_collider(mem, Vector3(12.0, 6.0, 8.0), Vector3(0, 3.0, -1.0))

func _build_vyatka_embankment(pos: Vector3) -> void:
	var emb := Node3D.new(); emb.position = pos; add_child(emb)
	# Two-level promenade overlooking Vyatka River
	for lvl in [[0.0, 0.4, 24.0, 95.0], [10.0, -2.4, 14.0, 105.0]]:
		var deck := MeshInstance3D.new(); var dm := BoxMesh.new(); dm.size = Vector3(lvl[2], 1.6, lvl[3])
		deck.mesh = dm; deck.position = Vector3(lvl[0], lvl[1], 0.0)
		deck.material_override = TextureBank.pbr_mat("paving", 0.28, true); emb.add_child(deck)
	# Wooden Fortress Kremlin towers
	for tz in [-40.0, 40.0]:
		var base := MeshInstance3D.new(); var bm := CylinderMesh.new(); bm.top_radius = 4.0; bm.bottom_radius = 4.4; bm.height = 8.2; bm.radial_segments = 8
		base.mesh = bm; base.position = Vector3(-4.0, 4.1, tz); base.material_override = TextureBank.pbr_mat("wood_fortress", 0.3, true); emb.add_child(base)
		var roof := MeshInstance3D.new(); var rm := CylinderMesh.new(); rm.top_radius = 0.2; rm.bottom_radius = 5.0; rm.height = 4.5; rm.radial_segments = 8
		roof.mesh = rm; roof.position = Vector3(-4.0, 10.4, tz); roof.material_override = TextureBank.pbr_mat("bricks_red", 0.4, true); emb.add_child(roof)
		_add_landmark_collider(emb, Vector3(8.5, 9.0, 8.5), Vector3(-4.0, 4.5, tz))
	# Iconic «Ладья» wooden river vessel monument on lower level
	var hull := MeshInstance3D.new(); var hm := BoxMesh.new(); hm.size = Vector3(4.2, 2.2, 13.0)
	hull.mesh = hm; hull.position = Vector3(11.0, -0.6, 0.0); hull.material_override = TextureBank.pbr_mat("wood_fortress", 0.35, true); emb.add_child(hull)
	var mast := MeshInstance3D.new(); var mm := CylinderMesh.new(); mm.top_radius = 0.14; mm.bottom_radius = 0.2; mm.height = 8.5
	mast.mesh = mm; mast.position = Vector3(11.0, 4.2, 0.0); mast.material_override = TextureBank.pbr_mat("wood_fortress", 0.4, true); emb.add_child(mast)
	var sail := MeshInstance3D.new(); var sm := BoxMesh.new(); sm.size = Vector3(4.4, 4.8, 0.25)
	sail.mesh = sm; sail.position = Vector3(11.0, 5.2, 0.3); sail.rotation_degrees.y = 14.0
	var smat := StandardMaterial3D.new(); smat.albedo_color = Color(0.95, 0.90, 0.78); sail.material_override = smat; emb.add_child(sail)
	# 7-tier fountain
	var wg := StandardMaterial3D.new(); wg.albedo_color = Color(0.18, 0.78, 0.95); wg.emission_enabled = true
	wg.emission = Color(0.15, 0.85, 1.0); wg.emission_energy_multiplier = 0.4; night_glow_mats.append(wg)
	for tier in range(7):
		var tr := 4.8 - tier * 0.6; var d := MeshInstance3D.new(); var cm := CylinderMesh.new()
		cm.top_radius = tr; cm.bottom_radius = tr + 0.18; cm.height = 0.5
		d.mesh = cm; d.position = Vector3(-2.0, 0.6 + tier * 0.55, 0.0)
		d.material_override = wg if tier % 2 == 1 else TextureBank.pbr_mat("stone_blocks", 0.4, true); emb.add_child(d)
	_add_landmark_collider(emb, Vector3(9.5, 4.5, 9.5), Vector3(-2.0, 2.2, 0.0))
	var slbl := Label3D.new(); slbl.text = "НАБЕРЕЖНАЯ ВЯТКИ • ПАРИЖ 3784 КМ"; slbl.font_size = 46
	slbl.modulate = Color(1.0, 0.92, 0.55); slbl.position = Vector3(-5.0, 4.2, 22.0); slbl.rotation_degrees.y = -90.0; emb.add_child(slbl)

func _build_olimp_ice_palace(pos: Vector3) -> void:
	# Modeled directly from real photo: teal-turquoise & white ribbed sports palace with blue arched glass portico!
	var arena := Node3D.new(); arena.position = pos; arena.rotation_degrees = Vector3(0, 18, 0); add_child(arena)
	var teal := StandardMaterial3D.new(); teal.albedo_color = Color(0.08, 0.52, 0.50); teal.metallic = 0.35; teal.roughness = 0.42
	var white_p := StandardMaterial3D.new(); white_p.albedo_color = Color(0.92, 0.94, 0.96); white_p.roughness = 0.38
	var blue_g := StandardMaterial3D.new(); blue_g.albedo_color = Color(0.10, 0.42, 0.84); blue_g.metallic = 0.5; blue_g.roughness = 0.18
	blue_g.emission_enabled = true; blue_g.emission = Color(0.12, 0.48, 0.95); blue_g.emission_energy_multiplier = 0.25; night_glow_mats.append(blue_g)

	var body := MeshInstance3D.new(); var bm := BoxMesh.new(); bm.size = Vector3(48.0, 12.5, 34.0)
	body.mesh = bm; body.position = Vector3(0, 5.8, 0); body.material_override = teal; arena.add_child(body)
	var stripe := MeshInstance3D.new(); var sm := BoxMesh.new(); sm.size = Vector3(48.4, 3.2, 34.4)
	stripe.mesh = sm; stripe.position = Vector3(0, 10.2, 0); stripe.material_override = white_p; arena.add_child(stripe)
	var roof := MeshInstance3D.new(); var rm := CylinderMesh.new(); rm.top_radius = 19.0; rm.bottom_radius = 19.0; rm.height = 50.0
	roof.mesh = rm; roof.rotation_degrees = Vector3(0, 0, 90); roof.scale = Vector3(1, 1, 0.28)
	roof.position = Vector3(0, 12.2, 0); roof.material_override = TextureBank.pbr_mat("metal_brushed", 0.35, true); arena.add_child(roof)
	var portico := MeshInstance3D.new(); var pm := CylinderMesh.new(); pm.top_radius = 7.5; pm.bottom_radius = 7.5; pm.height = 10.0
	portico.mesh = pm; portico.rotation_degrees = Vector3(90, 0, 0); portico.scale = Vector3(1.1, 1.0, 0.9)
	portico.position = Vector3(0, 5.5, 18.5); portico.material_override = blue_g; arena.add_child(portico)
	var lbl := Label3D.new(); lbl.text = "ОЛИМП • ДВОРЕЦ СПОРТА"; lbl.font_size = 76
	lbl.modulate = Color(0.92, 0.97, 1.0); lbl.position = Vector3(0, 10.5, 17.5); arena.add_child(lbl)
	_add_landmark_collider(arena, Vector3(48.0, 14.0, 36.0), Vector3(0, 6.5, 0))

func _build_lenin_monument(pos: Vector3) -> void:
	var m := Node3D.new(); m.position = pos; add_child(m)
	var gran := TextureBank.pbr_mat("stone_blocks", 0.4, true)
	var bronze := StandardMaterial3D.new(); bronze.albedo_color = Color(0.18, 0.14, 0.11); bronze.metallic = 0.78; bronze.roughness = 0.35
	var ped := MeshInstance3D.new(); var pm := BoxMesh.new(); pm.size = Vector3(5.6, 3.8, 5.6)
	ped.mesh = pm; ped.position = Vector3(0, 1.9, 0); ped.material_override = gran; m.add_child(ped)
	var st := MeshInstance3D.new(); var sm := CylinderMesh.new(); sm.top_radius = 0.6; sm.bottom_radius = 0.9; sm.height = 3.8
	st.mesh = sm; st.position = Vector3(0, 5.7, 0); st.material_override = bronze; m.add_child(st)
	_add_landmark_collider(m, Vector3(5.8, 8.0, 5.8), Vector3(0, 4.0, 0))

func _build_rdk_palace(pos: Vector3) -> void:
	var r := Node3D.new(); r.position = pos; r.rotation_degrees = Vector3(0, -18, 0); add_child(r)
	var cream := StandardMaterial3D.new(); cream.albedo_color = Color(0.92, 0.88, 0.78); cream.roughness = 0.6
	var main := MeshInstance3D.new(); var mm := BoxMesh.new(); mm.size = Vector3(34.0, 11.0, 22.0)
	main.mesh = mm; main.position = Vector3(0, 5.5, 0); main.material_override = cream; r.add_child(main)
	for cx in [-8.0, -4.0, 0.0, 4.0, 8.0]:
		var col := MeshInstance3D.new(); var cm := CylinderMesh.new(); cm.top_radius = 0.38; cm.bottom_radius = 0.44; cm.height = 9.0
		col.mesh = cm; col.position = Vector3(cx, 4.5, 12.2); col.material_override = cream; r.add_child(col)
	var ped := MeshInstance3D.new(); var pm := BoxMesh.new(); pm.size = Vector3(20.0, 2.2, 3.5)
	ped.mesh = pm; ped.position = Vector3(0, 10.0, 11.6); ped.material_override = cream; r.add_child(ped)
	var lbl := Label3D.new(); lbl.text = "РАЙОННЫЙ ДОМ КУЛЬТУРЫ"; lbl.font_size = 54
	lbl.modulate = Color(1.0, 0.92, 0.65); lbl.position = Vector3(0, 10.0, 13.5); r.add_child(lbl)
	_add_landmark_collider(r, Vector3(34.0, 12.0, 24.0), Vector3(0, 5.5, 0))

func _build_admin_building(pos: Vector3) -> void:
	var a := Node3D.new(); a.position = pos; add_child(a)
	var mat := TextureBank.pbr_mat("facade_merchant", 1.0, false, 0.0).duplicate() as StandardMaterial3D
	mat.uv1_scale = Vector3(4.0, 2.0, 1.0); facade_mats.append(mat)
	var b := MeshInstance3D.new(); var bm := BoxMesh.new(); bm.size = Vector3(30.0, 13.5, 18.0)
	b.mesh = bm; b.position = Vector3(0, 6.75, 0); b.material_override = mat; a.add_child(b)
	# Tatarstan flag colors banner on roof
	var flag_cols := [Color(0.05, 0.55, 0.25), Color(0.95, 0.95, 0.96), Color(0.85, 0.12, 0.14)]
	for fi in range(3):
		var fm := StandardMaterial3D.new(); fm.albedo_color = flag_cols[fi]
		var fl := MeshInstance3D.new(); var flm := BoxMesh.new(); flm.size = Vector3(3.2, 0.6, 0.15)
		fl.mesh = flm; fl.position = Vector3(0, 17.5 - fi * 0.65, 0); fl.material_override = fm; a.add_child(fl)
	_add_landmark_collider(a, Vector3(30.0, 14.0, 18.0), Vector3(0, 7.0, 0))

func _build_church(pos: Vector3) -> void:
	var ch := Node3D.new(); ch.position = pos; add_child(ch)
	var white_st := StandardMaterial3D.new(); white_st.albedo_color = Color(0.94, 0.92, 0.86); white_st.roughness = 0.65
	var gold_d := StandardMaterial3D.new(); gold_d.albedo_color = Color(0.98, 0.78, 0.18); gold_d.metallic = 0.92; gold_d.roughness = 0.16
	var nave := MeshInstance3D.new(); var nm := BoxMesh.new(); nm.size = Vector3(16.0, 10.5, 22.0)
	nave.mesh = nm; nave.position = Vector3(0, 5.25, 0); nave.material_override = white_st; ch.add_child(nave)
	var bell := MeshInstance3D.new(); var bm := BoxMesh.new(); bm.size = Vector3(6.0, 18.0, 6.0)
	bell.mesh = bm; bell.position = Vector3(0, 9.0, 12.0); bell.material_override = white_st; ch.add_child(bell)
	for dp in [Vector3(0, 14.5, 0), Vector3(0, 20.5, 12.0)]:
		var drum := MeshInstance3D.new(); var dm := CylinderMesh.new(); dm.top_radius = 2.0; dm.bottom_radius = 2.0; dm.height = 4.2
		drum.mesh = dm; drum.position = dp - Vector3(0, 2.0, 0); drum.material_override = white_st; ch.add_child(drum)
		var dome := MeshInstance3D.new(); var sm := SphereMesh.new(); sm.radius = 2.4; sm.height = 4.2
		dome.mesh = sm; dome.position = dp; dome.material_override = gold_d; ch.add_child(dome)
	_add_landmark_collider(ch, Vector3(17.0, 14.0, 28.0), Vector3(0, 7.0, 2.0))

func _build_puzanka_pavilion(pos: Vector3) -> void:
	var pav := Node3D.new(); pav.position = pos; add_child(pav)
	var base := MeshInstance3D.new(); var bm := CylinderMesh.new(); bm.top_radius = 6.2; bm.bottom_radius = 6.8; bm.height = 1.2
	base.mesh = bm; base.position = Vector3(0, 0.3, 0); base.material_override = TextureBank.pbr_mat("stone_blocks", 0.4, true); pav.add_child(base)
	for a in range(6):
		var ang := float(a) * TAU / 6.0
		var col := MeshInstance3D.new(); var cm := CylinderMesh.new(); cm.top_radius = 0.22; cm.bottom_radius = 0.26; cm.height = 4.6
		col.mesh = cm; col.position = Vector3(cos(ang) * 4.8, 2.8, sin(ang) * 4.8)
		col.material_override = TextureBank.pbr_mat("concrete", 0.5, true); pav.add_child(col)
	var dome := MeshInstance3D.new(); var dm := CylinderMesh.new(); dm.top_radius = 0.2; dm.bottom_radius = 6.4; dm.height = 2.8
	dome.mesh = dm; dome.position = Vector3(0, 6.2, 0); dome.material_override = TextureBank.pbr_mat("bricks_red", 0.4, true); pav.add_child(dome)
	var sign := Label3D.new(); sign.text = "МАМАДЫШ • ГОРА ПУЗАНКА"; sign.font_size = 90
	sign.modulate = Color(1.0, 0.94, 0.72); sign.position = Vector3(0, 9.2, 0); pav.add_child(sign)
	_add_landmark_collider(pav, Vector3(11.0, 6.0, 11.0), Vector3(0, 3.0, 0))

func _make_beam(a: Vector3, b: Vector3, thickness: float, mat: Material) -> MeshInstance3D:
	var m := MeshInstance3D.new(); var bm := BoxMesh.new(); bm.size = Vector3(thickness, thickness, a.distance_to(b))
	m.mesh = bm; m.position = (a + b) * 0.5; m.look_at_from_position(m.position, b, Vector3.UP); m.material_override = mat
	return m

func _build_city_buildings() -> void:
	var buildings: Array = map_data.get("buildings", [])
	var lm_pts: Array[Vector3] = []
	for k in landmarks.keys():
		var p: Array = landmarks[k]["pos"]
		lm_pts.append(Vector3(float(p[0]), 0.0, float(p[2])))

	# 4x4 Spatial Chunks batching 2,685 OSM buildings into minimal draw calls + fast StaticBody3D colliders!
	var chunk_n := 4
	var st_walls := {}
	var st_roofs := {}
	var chunk_bodies := {}
	for cz_i in range(chunk_n):
		for cx_i in range(chunk_n):
			var key := Vector2i(cx_i, cz_i)
			var sb := StaticBody3D.new()
			sb.name = "CityChunk_%d_%d" % [cx_i, cz_i]
			sb.collision_layer = 2
			sb.collision_mask = 0
			add_child(sb)
			chunk_bodies[key] = sb
			st_roofs[key] = SurfaceTool.new()
			(st_roofs[key] as SurfaceTool).begin(Mesh.PRIMITIVE_TRIANGLES)
			for style in range(3):
				var sk := "%d_%d_%d" % [cx_i, cz_i, style]
				var st := SurfaceTool.new(); st.begin(Mesh.PRIMITIVE_TRIANGLES)
				st_walls[sk] = st

	for b_item in buildings:
		var b: Array = b_item
		var bx := float(b[0]); var gy := float(b[1]); var bz := float(b[2])
		var hw := maxf(2.2, float(b[3])); var hd := maxf(2.2, float(b[4]))
		var ang := float(b[5]); var bh := maxf(3.6, float(b[6])); var style := int(b[7]) % 3

		# Keep clear of handcrafted landmark plazas
		var skip := false
		for lp in lm_pts:
			if Vector2(bx - lp.x, bz - lp.z).length() < 26.0:
				skip = true
				break
		if skip:
			continue

		var cx_i := clampi(int((bx - x_min) / (x_max - x_min) * chunk_n), 0, chunk_n - 1)
		var cz_i := clampi(int((bz - z_min) / (z_max - z_min) * chunk_n), 0, chunk_n - 1)
		var ckey := Vector2i(cx_i, cz_i)
		var sk := "%d_%d_%d" % [cx_i, cz_i, style]
		var st_w: SurfaceTool = st_walls[sk]
		var st_r: SurfaceTool = st_roofs[ckey]

		var ca := cos(ang); var sa := sin(ang)
		var rx := Vector3(ca, 0.0, sa); var rz := Vector3(-sa, 0.0, ca)
		var y_bot := gy - 2.6; var y_top := gy + bh
		var c0 := Vector3(bx, 0, bz) - rx * hw - rz * hd
		var c1 := Vector3(bx, 0, bz) + rx * hw - rz * hd
		var c2 := Vector3(bx, 0, bz) + rx * hw + rz * hd
		var c3 := Vector3(bx, 0, bz) - rx * hw + rz * hd

		var u_x := maxf(1.0, roundf(hw * 2.0 / 9.0))
		var u_z := maxf(1.0, roundf(hd * 2.0 / 9.0))
		var v_h := maxf(1.0, roundf(bh / 5.5))
		_add_quad(st_w, c0 + Vector3(0, y_bot, 0), c1 + Vector3(0, y_bot, 0), c1 + Vector3(0, y_top, 0), c0 + Vector3(0, y_top, 0),
				  Vector2(0, v_h), Vector2(u_x, v_h), Vector2(u_x, 0), Vector2(0, 0))
		_add_quad(st_w, c1 + Vector3(0, y_bot, 0), c2 + Vector3(0, y_bot, 0), c2 + Vector3(0, y_top, 0), c1 + Vector3(0, y_top, 0),
				  Vector2(0, v_h), Vector2(u_z, v_h), Vector2(u_z, 0), Vector2(0, 0))
		_add_quad(st_w, c2 + Vector3(0, y_bot, 0), c3 + Vector3(0, y_bot, 0), c3 + Vector3(0, y_top, 0), c2 + Vector3(0, y_top, 0),
				  Vector2(0, v_h), Vector2(u_x, v_h), Vector2(u_x, 0), Vector2(0, 0))
		_add_quad(st_w, c3 + Vector3(0, y_bot, 0), c0 + Vector3(0, y_bot, 0), c0 + Vector3(0, y_top, 0), c3 + Vector3(0, y_top, 0),
				  Vector2(0, v_h), Vector2(u_z, v_h), Vector2(u_z, 0), Vector2(0, 0))
		_add_quad(st_r, c0 + Vector3(0, y_top, 0), c3 + Vector3(0, y_top, 0), c2 + Vector3(0, y_top, 0), c1 + Vector3(0, y_top, 0),
				  Vector2(0, 0), Vector2(0, 1), Vector2(1, 1), Vector2(1, 0))

		var cs := CollisionShape3D.new()
		var bs := BoxShape3D.new(); bs.size = Vector3(hw * 2.0, bh + 2.6, hd * 2.0)
		cs.shape = bs
		cs.transform = Transform3D(Basis(rx, Vector3.UP, rz), Vector3(bx, (y_bot + y_top) * 0.5, bz))
		(chunk_bodies[ckey] as StaticBody3D).add_child(cs)

	var style_keys := ["facade_khrushchevka", "facade_merchant", "bricks_red"]
	var roof_mat := TextureBank.pbr_mat("concrete", 0.35, true)
	for cz_i in range(chunk_n):
		for cx_i in range(chunk_n):
			var ckey := Vector2i(cx_i, cz_i)
			var sb: StaticBody3D = chunk_bodies[ckey]
			var sr: SurfaceTool = st_roofs[ckey]
			sr.generate_normals()
			var rm := sr.commit()
			if rm.get_surface_count() > 0:
				var ri := MeshInstance3D.new(); ri.mesh = rm; ri.material_override = roof_mat; sb.add_child(ri)
			for style in range(3):
				var sk := "%d_%d_%d" % [cx_i, cz_i, style]
				var sw: SurfaceTool = st_walls[sk]
				sw.generate_normals()
				var wm := sw.commit()
				if wm.get_surface_count() > 0:
					var wi := MeshInstance3D.new(); wi.mesh = wm
					var mat := TextureBank.pbr_mat(style_keys[style], 1.0, false, 0.0).duplicate() as StandardMaterial3D
					if style < 2:
						facade_mats.append(mat)
					wi.material_override = mat
					sb.add_child(wi)

func _build_trees_and_lights() -> void:
	# MultiMesh trees on Mt. Puzanka slopes, parks & Vyatka riverbank (only 2 draw calls!)
	var tree_positions: Array[Vector3] = []
	for _i in range(420):
		var rx := _rng.randf_range(x_min + 80.0, x_max - 80.0)
		var rz := _rng.randf_range(z_min + 80.0, z_max - 80.0)
		var ry := sample_terrain_h(rx, rz)
		if ry < water_y + 1.4:
			continue
		# Bias densely onto Puzanka slope (z < -700) and Vyatka bluffs (x > 520)
		if rz > -700.0 and rx < 480.0 and _rng.randf() > 0.16:
			continue
		if _is_near_any_road(rx, rz, 14.0):
			continue
		tree_positions.append(Vector3(rx, ry, rz))

	if not tree_positions.is_empty():
		var mm_tr := MultiMesh.new(); mm_tr.transform_format = MultiMesh.TRANSFORM_3D
		var tr_mesh := CylinderMesh.new(); tr_mesh.top_radius = 0.18; tr_mesh.bottom_radius = 0.30; tr_mesh.height = 4.2
		mm_tr.mesh = tr_mesh; mm_tr.instance_count = tree_positions.size()

		var mm_cr := MultiMesh.new(); mm_cr.transform_format = MultiMesh.TRANSFORM_3D
		var cr_mesh := CylinderMesh.new(); cr_mesh.top_radius = 0.15; cr_mesh.bottom_radius = 2.6; cr_mesh.height = 7.4; cr_mesh.radial_segments = 7
		mm_cr.mesh = cr_mesh; mm_cr.instance_count = tree_positions.size()

		for i in range(tree_positions.size()):
			var tp := tree_positions[i]
			var sc := _rng.randf_range(0.85, 1.45)
			mm_tr.set_instance_transform(i, Transform3D(Basis.from_scale(Vector3(sc, sc, sc)), tp + Vector3(0, 2.1 * sc, 0)))
			mm_cr.set_instance_transform(i, Transform3D(Basis.from_scale(Vector3(sc, sc, sc)), tp + Vector3(0, 6.2 * sc, 0)))

		var mmi_tr := MultiMeshInstance3D.new(); mmi_tr.multimesh = mm_tr
		mmi_tr.material_override = TextureBank.pbr_mat("wood_fortress", 0.8, true); add_child(mmi_tr)
		var mmi_cr := MultiMeshInstance3D.new(); mmi_cr.multimesh = mm_cr
		var leaf_m := StandardMaterial3D.new(); leaf_m.albedo_color = Color(0.11, 0.32, 0.14); leaf_m.roughness = 0.88
		mmi_cr.material_override = leaf_m; add_child(mmi_cr)

	# Streetlights along active race circuit (batched MultiMesh poles + glowing bulbs)
	var L := get_track_length()
	var n_poles := 80
	var mm_p := MultiMesh.new(); mm_p.transform_format = MultiMesh.TRANSFORM_3D
	var pm := CylinderMesh.new(); pm.top_radius = 0.09; pm.bottom_radius = 0.14; pm.height = 6.6
	mm_p.mesh = pm; mm_p.instance_count = n_poles

	var mm_b := MultiMesh.new(); mm_b.transform_format = MultiMesh.TRANSFORM_3D
	var bm := BoxMesh.new(); bm.size = Vector3(0.75, 0.2, 0.35)
	mm_b.mesh = bm; mm_b.instance_count = n_poles

	var lamp_mat := StandardMaterial3D.new()
	lamp_mat.albedo_color = Color(1.0, 0.9, 0.65)
	lamp_mat.emission_enabled = true; lamp_mat.emission = Color(1.0, 0.85, 0.5); lamp_mat.emission_energy_multiplier = 0.0
	night_glow_mats.append(lamp_mat)

	for i in range(n_poles):
		var d := (float(i) / float(n_poles)) * L
		var tr := sample_track(d)
		var side := -1.0 if i % 2 == 0 else 1.0
		var pp := tr.origin + tr.basis.x * (side * (ROAD_HALF_W + 1.2))
		mm_p.set_instance_transform(i, Transform3D(tr.basis, pp + Vector3(0, 3.3, 0)))
		mm_b.set_instance_transform(i, Transform3D(tr.basis, pp - tr.basis.x * (side * 0.6) + Vector3(0, 6.5, 0)))
		if i % 6 == 0:
			var nl := OmniLight3D.new(); nl.light_color = Color(1.0, 0.82, 0.52); nl.light_energy = 0.0; nl.omni_range = 20.0
			nl.position = pp + Vector3(0, 6.1, 0); add_child(nl); night_lights.append(nl)

	var mmi_p := MultiMeshInstance3D.new(); mmi_p.multimesh = mm_p; mmi_p.material_override = TextureBank.pbr_mat("metal_brushed", 1.0, true); add_child(mmi_p)
	var mmi_b := MultiMeshInstance3D.new(); mmi_b.multimesh = mm_b; mmi_b.material_override = lamp_mat; add_child(mmi_b)

func _is_near_any_road(x: float, z: float, radius: float) -> bool:
	var r2 := radius * radius
	for i in range(0, graph_nodes.size(), 2):
		var n := graph_nodes[i]
		var dx := n.x - x; var dz := n.z - z
		if dx * dx + dz * dz < r2:
			return true
	return false

func _build_destructibles() -> void:
	destructibles_root = Node3D.new(); destructibles_root.name = "Destructibles"; add_child(destructibles_root)
	roadblocks_root = Node3D.new(); roadblocks_root.name = "Roadblocks"; add_child(roadblocks_root)
	var cone_mat := StandardMaterial3D.new(); cone_mat.albedo_color = Color(0.95, 0.38, 0.06); cone_mat.roughness = 0.55
	var crate_mat := TextureBank.pbr_mat("wood_fortress", 1.0, true)
	var L := get_track_length()
	for i in range(24):
		var d := fmod(55.0 + float(i) * (L / 24.0), L)
		var tr := sample_track(d)
		var side := -1.0 if i % 2 == 0 else 1.0
		var base := tr.origin + tr.basis.x * (side * (ROAD_HALF_W - 0.6))
		for j in range(2):
			var rb := RigidBody3D.new(); rb.collision_layer = 2; rb.collision_mask = 1 | 2 | 4
			rb.mass = 14.0 if j == 0 else 28.0
			rb.position = base + tr.basis.z * (float(j) * 2.2) + Vector3(0, 0.5, 0)
			var mi := MeshInstance3D.new(); var cs := CollisionShape3D.new()
			if j == 0:
				var cm := CylinderMesh.new(); cm.top_radius = 0.09; cm.bottom_radius = 0.28; cm.height = 0.72
				mi.mesh = cm; mi.material_override = cone_mat
				var sh := CylinderShape3D.new(); sh.radius = 0.28; sh.height = 0.72; cs.shape = sh
			else:
				var bm := BoxMesh.new(); bm.size = Vector3(0.85, 0.85, 0.85)
				mi.mesh = bm; mi.material_override = crate_mat
				var sh := BoxShape3D.new(); sh.size = Vector3(0.85, 0.85, 0.85); cs.shape = sh
			rb.add_child(mi); rb.add_child(cs); destructibles_root.add_child(rb)

func _build_checkpoints() -> void:
	if checkpoints_root:
		checkpoints_root.queue_free()
	checkpoints_root = Node3D.new(); checkpoints_root.name = "Checkpoints"; add_child(checkpoints_root)
	checkpoint_positions.clear()
	var L := get_track_length()
	var count := 16
	for i in range(count):
		var d := (float(i) / float(count)) * L
		var tr := sample_track(d)
		checkpoint_positions.append({"dist": d, "pos": tr.origin, "transform": tr})

func spawn_roadblock_at_pos(pos: Vector3, dir: Vector3) -> void:
	if roadblocks_root.get_child_count() > 16:
		for old in roadblocks_root.get_children().slice(0, 4):
			old.queue_free()
	var fwd := Vector3(dir.x, 0.0, dir.z).normalized()
	if fwd.length_squared() < 0.01: fwd = Vector3.FORWARD
	var right := fwd.cross(Vector3.UP).normalized()
	var tr := Transform3D(Basis(right, Vector3.UP, -fwd), pos)
	var bar_mat := TextureBank.curb_redwhite_material()
	for off_x in [-3.6, 0.0, 3.6]:
		var rb := RigidBody3D.new(); rb.collision_layer = 2; rb.collision_mask = 1 | 2 | 4; rb.mass = 65.0
		rb.transform = tr; rb.position += right * off_x + Vector3(0, 0.65, 0)
		var mi := MeshInstance3D.new(); var bm := BoxMesh.new(); bm.size = Vector3(3.0, 1.05, 0.45)
		mi.mesh = bm; mi.material_override = bar_mat
		var cs := CollisionShape3D.new(); var sh := BoxShape3D.new(); sh.size = Vector3(3.0, 1.05, 0.45); cs.shape = sh
		rb.add_child(mi); rb.add_child(cs); roadblocks_root.add_child(rb)

func clear_roadblocks() -> void:
	if roadblocks_root:
		for c in roadblocks_root.get_children(): c.queue_free()

func set_night_state(is_night: bool, is_wet := false) -> void:
	if road_mesh_inst:
		road_mesh_inst.material_override = TextureBank.road_material(is_wet)
	for fm in facade_mats: fm.emission_energy_multiplier = 1.15 if is_night else 0.0
	for gm in night_glow_mats: gm.emission_energy_multiplier = 2.0 if is_night else 0.18
	for nl in night_lights: nl.light_energy = 1.75 if is_night else 0.0

# --- Street Graph Navigation, Nearest Road Recovery & Water Detection ---
func get_nearest_graph_node(pos: Vector3) -> int:
	var best_i := 0; var best_d2 := 1e18
	for i in range(graph_nodes.size()):
		var p := graph_nodes[i]
		var d2 := (p.x - pos.x) * (p.x - pos.x) + (p.z - pos.z) * (p.z - pos.z)
		if d2 < best_d2:
			best_d2 = d2; best_i = i
	return best_i

func get_nearest_road_transform(pos: Vector3) -> Transform3D:
	if graph_nodes.is_empty():
		return spawn_transform
	var ni := get_nearest_graph_node(pos)
	var p := graph_nodes[ni]
	var fwd := Vector3.FORWARD
	var adj: Array = graph_adj[ni] if ni < graph_adj.size() else []
	if not adj.is_empty():
		var nb_idx := int(adj[0][0])
		fwd = (graph_nodes[nb_idx] - p)
		fwd.y = 0.0
		if fwd.length_squared() < 0.01: fwd = Vector3.FORWARD
		else: fwd = fwd.normalized()
	var right := fwd.cross(Vector3.UP).normalized()
	return Transform3D(Basis(right, Vector3.UP, -fwd), Vector3(p.x, maxf(p.y, sample_terrain_h(p.x, p.z)) + 0.35, p.z))

func get_street_spawn_near(center: Vector3, min_d: float, max_d: float, face_pos: Vector3, avoid_pts: Array[Vector3] = []) -> Transform3D:
	var best_idx := -1
	var candidates: Array[int] = []
	for i in range(graph_nodes.size()):
		var p := graph_nodes[i]
		var d := Vector2(p.x - center.x, p.z - center.z).length()
		if d >= min_d and d <= max_d:
			var ok := true
			for ap in avoid_pts:
				if p.distance_to(ap) < 18.0:
					ok = false; break
			if ok:
				candidates.append(i)
	if candidates.is_empty():
		return get_nearest_road_transform(center + Vector3(min_d, 0.0, 0.0))
	best_idx = candidates[randi() % candidates.size()]
	var sp := graph_nodes[best_idx]
	var best_fwd := Vector3.FORWARD
	var best_dot := -2.0
	var to_face := (face_pos - sp); to_face.y = 0.0
	if to_face.length_squared() > 0.01: to_face = to_face.normalized()
	var adj: Array = graph_adj[best_idx] if best_idx < graph_adj.size() else []
	for e_item in adj:
		var e: Array = e_item
		var nb := graph_nodes[int(e[0])]
		var dir := (nb - sp); dir.y = 0.0
		if dir.length_squared() > 0.01:
			dir = dir.normalized()
			var dt := dir.dot(to_face)
			if dt > best_dot:
				best_dot = dt; best_fwd = dir
	var right := best_fwd.cross(Vector3.UP).normalized()
	return Transform3D(Basis(right, Vector3.UP, -best_fwd), Vector3(sp.x, maxf(sp.y, sample_terrain_h(sp.x, sp.z)) + 0.35, sp.z))

func is_in_water(pos: Vector3) -> bool:
	return pos.y < water_y + 0.30

func find_path_astar(start_pos: Vector3, goal_pos: Vector3) -> PackedVector3Array:
	var out := PackedVector3Array()
	var n := graph_nodes.size()
	if n == 0:
		return out
	var start_idx := get_nearest_graph_node(start_pos)
	var goal_idx := get_nearest_graph_node(goal_pos)
	if start_idx == goal_idx:
		out.append(graph_nodes[goal_idx])
		return out

	var g_score := PackedFloat32Array(); g_score.resize(n); g_score.fill(1e12)
	var came_from := PackedInt32Array(); came_from.resize(n); came_from.fill(-1)
	var closed := PackedByteArray(); closed.resize(n)
	g_score[start_idx] = 0.0

	var open_nodes: Array[int] = [start_idx]
	var open_f: Array[float] = [graph_nodes[start_idx].distance_to(graph_nodes[goal_idx])]
	var goal_v := graph_nodes[goal_idx]
	var iters := 0

	while not open_nodes.is_empty() and iters < 750:
		iters += 1
		var best_k := 0
		var best_f := open_f[0]
		for k in range(1, open_nodes.size()):
			if open_f[k] < best_f:
				best_f = open_f[k]; best_k = k
		var curr := open_nodes[best_k]
		open_nodes.remove_at(best_k)
		open_f.remove_at(best_k)
		if curr == goal_idx:
			break
		if closed[curr] != 0:
			continue
		closed[curr] = 1

		var edges: Array = graph_adj[curr]
		for e_item in edges:
			var e: Array = e_item
			var nb := int(e[0])
			if closed[nb] != 0:
				continue
			var w := float(e[1])
			var tg := g_score[curr] + w
			if tg < g_score[nb]:
				g_score[nb] = tg
				came_from[nb] = curr
				var f := tg + graph_nodes[nb].distance_to(goal_v)
				open_nodes.append(nb)
				open_f.append(f)

	var rev: Array[Vector3] = []
	var c := goal_idx
	if came_from[c] == -1:
		out.append(goal_v)
		return out
	while c != -1:
		rev.append(graph_nodes[c])
		if c == start_idx:
			break
		c = came_from[c]
	for k in range(rev.size() - 1, -1, -1):
		out.append(rev[k])
	return out
