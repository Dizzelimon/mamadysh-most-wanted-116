extends Camera3D
class_name CameraRig

enum ViewMode { CHASE, FAR_CHASE, HOOD, BUMPER }

var target: MamadyshVehicle
var view_mode: ViewMode = ViewMode.CHASE
var garage_mode := true
var garage_focus := Vector3.ZERO
var garage_angle := 0.55

var _shake := 0.0
var _smooth_pos := Vector3.ZERO
var _smooth_look := Vector3.ZERO

func _ready() -> void:
	far = 2600.0
	near = 0.15
	fov = 66.0

func set_garage_target(focus: Vector3) -> void:
	garage_mode = true
	garage_focus = focus

func bind_vehicle(v: MamadyshVehicle) -> void:
	target = v
	garage_mode = false
	if is_instance_valid(target):
		_smooth_pos = target.global_position + target.global_transform.basis.z * 6.5 + Vector3(0, 2.5, 0)
		_smooth_look = target.global_position + Vector3(0, 1.0, 0)

func add_shake(amount: float) -> void:
	_shake = minf(1.0, _shake + amount)

func cycle_view() -> String:
	view_mode = ((int(view_mode) + 1) % 4) as ViewMode
	match view_mode:
		ViewMode.CHASE: return "КАМЕРА: БЛИЗКО"
		ViewMode.FAR_CHASE: return "КАМЕРА: ДАЛЬНЯЯ"
		ViewMode.HOOD: return "КАМЕРА: КАПОТ"
		ViewMode.BUMPER: return "КАМЕРА: БАМПЕР"
	return "КАМЕРА"

func _process(delta: float) -> void:
	var unscaled_dt := delta / maxf(Engine.time_scale, 0.1)
	if garage_mode:
		garage_angle += unscaled_dt * 0.35
		var cam_p := garage_focus + Vector3(sin(garage_angle) * 5.2, 1.75, cos(garage_angle) * 5.2)
		look_at_from_position(cam_p, garage_focus + Vector3(0.0, 0.65, 0.0), Vector3.UP)
		fov = lerpf(fov, 50.0, unscaled_dt * 5.0)
		return

	if not is_instance_valid(target):
		return

	var basis := target.global_transform.basis
	var pos := target.global_position
	var fwd := -basis.z
	var spd_ratio := clampf(target.speed / 58.0, 0.0, 1.0)
	var desired_pos := pos
	var desired_look := pos
	var desired_fov := 66.0 + spd_ratio * 14.0 + (8.0 if target.nos_active else 0.0)

	match view_mode:
		ViewMode.CHASE:
			desired_pos = pos - fwd * (5.3 + spd_ratio * 0.9) + Vector3(0.0, 2.20, 0.0)
			desired_look = pos + fwd * 8.0 + Vector3(0.0, 0.95, 0.0)
			_smooth_pos = _smooth_pos.lerp(desired_pos, clampf(unscaled_dt * 11.0, 0.0, 1.0))
			_smooth_look = _smooth_look.lerp(desired_look, clampf(unscaled_dt * 15.0, 0.0, 1.0))
		ViewMode.FAR_CHASE:
			desired_pos = pos - fwd * (7.8 + spd_ratio * 1.2) + Vector3(0.0, 3.15, 0.0)
			desired_look = pos + fwd * 10.0 + Vector3(0.0, 1.0, 0.0)
			_smooth_pos = _smooth_pos.lerp(desired_pos, clampf(unscaled_dt * 9.5, 0.0, 1.0))
			_smooth_look = _smooth_look.lerp(desired_look, clampf(unscaled_dt * 14.0, 0.0, 1.0))
		ViewMode.HOOD:
			_smooth_pos = pos + basis.y * 1.28 - basis.z * 0.55
			_smooth_look = pos + fwd * 24.0 + basis.y * 0.95
			desired_fov += 4.0
		ViewMode.BUMPER:
			_smooth_pos = pos + basis.y * 0.62 - basis.z * 2.15
			_smooth_look = pos + fwd * 28.0 + basis.y * 0.55
			desired_fov += 8.0

	var shake_off := Vector3.ZERO
	if _shake > 0.005:
		shake_off = Vector3(randf_range(-1, 1), randf_range(-1, 1), randf_range(-1, 1)) * (_shake * 0.35)
		_shake = maxf(0.0, _shake - unscaled_dt * 2.8)

	fov = lerpf(fov, desired_fov, clampf(unscaled_dt * 6.0, 0.0, 1.0))
	look_at_from_position(_smooth_pos + shake_off, _smooth_look, Vector3.UP)
