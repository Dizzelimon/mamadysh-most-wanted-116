extends SceneTree

var failures := 0
var main: Node

func check(value: bool, description: String) -> void:
	print(("PASS " if value else "FAIL ") + description)
	if not value: failures += 1

func _initialize() -> void:
	_run.call_deferred()

func _run() -> void:
	main = load("res://scenes/Main.tscn").instantiate()
	root.add_child(main)
	while not main.boot_ready:
		await process_frame
	check(main.world.ready_to_drive, "world collision-ready before start")
	check(main.world.map_data.roads.size() == 475, "475 preserved roads")
	check(main.world.map_data.footprints.size() == 3231, "3231 preserved footprints")
	check(main.world.race_curve.get_baked_length() > 7000, "long route preserved")
	check(main.world.olimp_curve.get_baked_length() > 2000, "Puzanka preserved")
	for curve in [main.world.race_curve, main.world.olimp_curve]:
		check(curve.get_point_position(0).distance_to(curve.get_point_position(curve.point_count - 1)) < 0.01, "route closed")
	await physics_frame
	var collision_ok := true
	for index in range(main.world.checkpoint_positions.size()):
		var pos: Vector3 = main.world.checkpoint_positions[index].pos
		var query := PhysicsRayQueryParameters3D.create(pos + Vector3.UP * 3.0, pos - Vector3.UP * 4.0, 1)
		if main.world.get_world_3d().direct_space_state.intersect_ray(query).is_empty(): collision_ok = false
	check(collision_ok, "road/terrain collision under every Puzanka gate")
	check(main.hud.garage_panel.visible and main.manager.state == 0, "garage idle")
	main._on_start_requested(PursuitAndRaceManager.GameMode.RACE)
	await process_frame
	main.player_car.freeze = true
	main.manager.countdown_timer = 0.0
	await process_frame
	check(main.manager.state == PursuitAndRaceManager.State.ACTIVE, "countdown starts race")
	# Three independent fingers; drag across a pedal boundary keeps captured role.
	var hud: GameHUD = main.hud
	var gas: Vector2 = hud._touch_pads[2].btn.get_global_rect().get_center()
	var nos: Vector2 = hud._touch_pads[3].btn.get_global_rect().get_center()
	for spec in [[1, gas], [2, nos], [3, hud._steer_zone.get_global_rect().get_center()]]:
		var touch := InputEventScreenTouch.new(); touch.index = spec[0]; touch.position = spec[1]; touch.pressed = true
		hud._input(touch)
	var drag := InputEventScreenDrag.new(); drag.index = 3; drag.position = hud._steer_zone.get_global_rect().get_center() + Vector2(45, 0); hud._input(drag)
	check(main.player_ctrl.touch_throttle > 0.0 and main.player_ctrl.touch_nos and absf(main.player_ctrl.touch_steer) > 0.1, "gas + NOS + steering simultaneously")
	drag.index = 1; drag.position = nos; hud._input(drag)
	check(main.player_ctrl.touch_throttle > 0.0, "finger role retained after drag")
	var before: float = main.manager.race_time
	hud.set_paused(true)
	await create_timer(0.15, true).timeout
	check(is_equal_approx(main.manager.race_time, before), "pause freezes race time")
	check(main.player_ctrl.touch_throttle == 0.0 and not main.player_ctrl.touch_nos, "pause releases inputs")
	hud.set_paused(false)
	check(hud._active_fingers.is_empty(), "resume requires new touches")
	main.atmosphere.apply_mode(AtmosphereManager.TimeMode.NIGHT_RAIN)
	for i in range(30): await physics_frame
	check(main.player_car.wetness > 0.0 and main.player_car.wetness < 1.0, "rain grip transitions smoothly")
	# Actual gate detector, using controlled positions, not claiming a driven race.
	var manager: PursuitAndRaceManager = main.manager
	var car: MamadyshVehicle = main.player_car
	var gate: Transform3D = main.world.checkpoint_positions[1].transform
	car.global_position = gate * Vector3(0, 1, 2)
	manager.clear_player_gate_sample(); manager._update_race_progress()
	car.global_position = gate * Vector3(0, 1, -2)
	manager.clear_player_gate_sample(); manager._update_race_progress()
	check(manager.next_cp_idx == 1, "reset cannot count checkpoint")
	car.global_position = gate * Vector3(0, 1, -2)
	manager.clear_player_gate_sample(); manager._update_race_progress()
	car.global_position = gate * Vector3(0, 1, 2); manager._update_race_progress()
	check(manager.next_cp_idx == 1, "wrong-direction crossing rejected")
	manager._previous_race_positions.clear()
	for idx in range(1, main.world.checkpoint_positions.size() + 1):
		var index: int = idx % main.world.checkpoint_positions.size()
		var tr: Transform3D = main.world.checkpoint_positions[index].transform
		car.global_position = tr * Vector3(0, 1, 2)
		manager.clear_player_gate_sample(); manager._update_race_progress()
		car.global_position = tr * Vector3(0, 1, -2)
		manager.race_time += 10.0
		manager._update_race_progress()
	check(manager.state == PursuitAndRaceManager.State.RACE_DONE, "ordered gates finish")
	check(PursuitAndRaceManager.read_best("olimp", "lada_vesta_sport") > 0.0, "route-car record persisted")
	check(manager.sector_times.size() >= 3, "sector times recorded")
	main._enter_garage(); await process_frame; await process_frame
	var baseline := root.get_tree().get_node_count()
	main._on_circuit_selected("race")
	main._on_start_requested(PursuitAndRaceManager.GameMode.RACE)
	await process_frame
	check(main.manager.next_cp_idx == 1 and main.manager.sector_times.is_empty(), "new race clears progress")
	hud._deadzone = 0.085; hud._sensitivity = 2; hud._save_settings()
	var saved := ConfigFile.new(); saved.load("user://controls.cfg")
	check(is_equal_approx(float(saved.get_value("controls", "deadzone")), 0.085) and int(saved.get_value("controls", "sensitivity")) == 2, "control settings persist")
	hud._deadzone = 0.035; hud._sensitivity = 1; hud._save_settings()
	main._enter_garage(); await process_frame; await process_frame
	for mode in [PursuitAndRaceManager.GameMode.FREE_ROAM, PursuitAndRaceManager.GameMode.PURSUIT]:
		main._on_start_requested(mode)
		await create_timer(0.25).timeout
		check(main.manager.state == PursuitAndRaceManager.State.ACTIVE, "mode %d starts" % mode)
		main._notification(Node.NOTIFICATION_APPLICATION_FOCUS_OUT)
		check(paused and main.player_ctrl.touch_throttle == 0.0, "focus loss pauses mode %d" % mode)
		hud.set_paused(false)
		main._enter_garage(); await process_frame; await process_frame
	check(root.get_tree().get_node_count() <= baseline + 2, "no node growth after session cycles")
	main._set_quality(false); main._set_quality(true)
	check(not main.atmosphere.sun_light.shadow_enabled, "minimum quality disables shadows")
	print("REGRESSION44 failures=%d" % failures)
	main.queue_free()
	await process_frame
	await process_frame
	await create_timer(0.15).timeout
	quit(1 if failures else 0)
