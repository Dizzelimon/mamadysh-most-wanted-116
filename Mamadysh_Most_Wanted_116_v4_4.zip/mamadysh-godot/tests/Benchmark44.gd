extends SceneTree

func _initialize() -> void:
	_run.call_deferred()

func _run() -> void:
	var main: Node = load("res://scenes/Main.tscn").instantiate()
	root.add_child(main)
	while not main.boot_ready: await process_frame
	main._on_start_requested(PursuitAndRaceManager.GameMode.RACE)
	main.manager.countdown_timer = 0.0
	await process_frame
	main.player_ctrl.set_physics_process(false)
	var driver := AICarDriver.new()
	driver.vehicle = main.player_car; driver.world = main.world; driver.role = AICarDriver.Role.RACER
	driver.target_speed_ms = 25.0
	main.player_car.add_child(driver)
	await create_timer(2.0).timeout
	var frame_ms: Array[float] = []
	var cpu_ms: Array[float] = []
	var start := Time.get_ticks_usec()
	var previous := start
	var max_speed := 0.0
	while Time.get_ticks_usec() - start < 20000000:
		await process_frame
		var now := Time.get_ticks_usec()
		frame_ms.append(float(now - previous) / 1000.0)
		previous = now
		cpu_ms.append((Performance.get_monitor(Performance.TIME_PROCESS) + Performance.get_monitor(Performance.TIME_PHYSICS_PROCESS)) * 1000.0)
		max_speed = maxf(max_speed, main.player_car.speed * 3.6)
	frame_ms.sort(); cpu_ms.sort()
	print("BENCH44 headless=" + str(DisplayServer.get_name() == "headless") + " route=olimp mode=race quality=minimum duration_s=20 frames=%d frame_p95_ms=%.3f cpu_p95_ms=%.3f max_kmh=%.1f next_cp=%d" % [frame_ms.size(), frame_ms[int(frame_ms.size()*0.95)], cpu_ms[int(cpu_ms.size()*0.95)], max_speed, main.manager.next_cp_idx])
	main.queue_free(); await process_frame; await process_frame
	await create_timer(0.15).timeout
	quit()
