"""Build the game map from an OSM XML extract and Mapzen Terrarium tiles.

Usage: python rebuild_city.py OSM_XML TILE_DIR ROUTE_REFERENCE_JSON OUTPUT_JSON
Tile directory contains the six z13 tiles named {x}-{y}.png.
Requires numpy, scipy, Pillow and shapely >= 2.1.
"""
import heapq
import json
import math
import sys
import xml.etree.ElementTree as ET
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np
import shapely
from PIL import Image, ImageDraw
from scipy.spatial import cKDTree
from shapely.geometry import LineString, Polygon, box
from shapely.ops import polygonize, unary_union

LAT, LON = 55.716, 51.404
NORTH_M = 111195.0
EAST_M = NORTH_M * math.cos(math.radians(LAT))
X0, X1, Z0, Z1, GRID = -1870.0, 1940.0, -2100.0, 2210.0, 215
WATER = 0.4
WIDTHS = {"secondary": 8.8, "unclassified": 6.3, "residential": 5.8, "service": 4.0}
REGION = box(X0, Z0, X1, Z1)


def project(lat, lon):
    return (lon - LON) * EAST_M, (LAT - lat) * NORTH_M


def tags(element):
    return {item.attrib["k"]: item.attrib["v"] for item in element.findall("tag")}


def polygon_parts(geom):
    if geom.geom_type == "Polygon" and not geom.is_empty:
        yield geom
    elif hasattr(geom, "geoms"):
        for child in geom.geoms:
            yield from polygon_parts(child)


def points_of(way, nodes):
    return [nodes[nd.attrib["ref"]] for nd in way.findall("nd")]


def load_dem(tile_dir, xx, zz):
    n = 2**13
    px = (180 + LON + xx / EAST_M) / 360 * n * 256 - 0.5
    py = (1 - np.arcsinh(np.tan(np.radians(LAT - zz / NORTH_M))) / np.pi) / 2 * n * 256 - 0.5
    x, y = np.floor(px).astype(int), np.floor(py).astype(int)
    cache = {}

    def take(cx, cy):
        out = np.empty(cx.shape)
        for tx, ty in set(zip((cx // 256).flat, (cy // 256).flat)):
            key = tx, ty
            if key not in cache:
                rgb = np.asarray(Image.open(tile_dir / f"{tx}-{ty}.png").convert("RGB"), dtype=float)
                cache[key] = rgb[:, :, 0] * 256 + rgb[:, :, 1] + rgb[:, :, 2] / 256 - 32768
            mask = (cx // 256 == tx) & (cy // 256 == ty)
            out[mask] = cache[key][cy[mask] % 256, cx[mask] % 256]
        return out

    u, v = px - x, py - y
    return (1 - v) * ((1 - u) * take(x, y) + u * take(x + 1, y)) + v * ((1 - u) * take(x, y + 1) + u * take(x + 1, y + 1))


def serialize_ring(ring):
    return [[round(x, 2), round(z, 2)] for x, z in list(ring.coords)[:-1]]


def main():
    xml, tile_dir, base, output = map(Path, sys.argv[1:])
    data = json.loads(base.read_text())
    root = ET.parse(xml).getroot()
    nodes = {n.attrib["id"]: project(float(n.attrib["lat"]), float(n.attrib["lon"])) for n in root.findall("node")}
    ways = {w.attrib["id"]: w for w in root.findall("way")}
    relation = next(r for r in root.findall("relation") if r.attrib["id"] == "167611")
    outer = []
    islands = []
    for member in relation.findall("member"):
        way = ways.get(member.attrib["ref"])
        if way is None:
            continue
        points = points_of(way, nodes)
        if member.attrib["role"] == "outer":
            outer.append(LineString(points).intersection(REGION))
        else:
            islands.append(shapely.make_valid(Polygon(points)).intersection(REGION))
    faces = list(polygonize(unary_union([REGION.boundary, *outer])))
    river = next(p for p in faces if p.covers(shapely.Point(1450, 500)))
    if islands:
        river = river.difference(unary_union(islands))
    waters = [river]
    woodlands = []
    park = None
    paths = []
    for way in ways.values():
        t = tags(way)
        points = points_of(way, nodes)
        if len(points) >= 4 and points[0] == points[-1]:
            if t.get("natural") in ("water", "wood") or t.get("name") == "Сквер Яшьлек":
                poly = shapely.make_valid(Polygon(points)).intersection(REGION)
                if t.get("natural") == "water":
                    waters.extend(p for p in polygon_parts(poly) if p.area > 12)
                elif t.get("natural") == "wood":
                    woodlands.extend(p for p in polygon_parts(poly) if p.area > 1600)
                else:
                    park = poly

    water_geom = unary_union(waters)
    xx, zz = np.meshgrid(np.linspace(X0, X1, GRID), np.linspace(Z0, Z1, GRID))
    wet = shapely.contains_xy(water_geom, xx, zz)
    elevations = load_dem(tile_dir, xx, zz)
    flat_river = shapely.contains_xy(river, xx, zz) & (xx > 1500)
    datum = float(np.median(elevations[flat_river]))
    heights = np.where(wet, WATER - 2.1, np.maximum(elevations - datum + WATER, WATER + 0.10))
    grid_points = shapely.points(xx, zz)
    coast_distance = shapely.distance(grid_points, water_geom.boundary)
    # Preserve the DEM inland and taper the first cells into the mapped edges.
    heights = np.where(wet, heights, np.minimum(heights, WATER + 0.45 + coast_distance * 0.9))

    def elevation(x, z):
        i = np.clip((x - X0) * (GRID - 1) / (X1 - X0), 0, GRID - 1.00001)
        j = np.clip((z - Z0) * (GRID - 1) / (Z1 - Z0), 0, GRID - 1.00001)
        a, b = int(i), int(j)
        u, v = i - a, j - b
        return float((1 - v) * ((1 - u) * heights[b, a] + u * heights[b, a + 1]) +
                     v * ((1 - u) * heights[b + 1, a] + u * heights[b + 1, a + 1]))

    def xyz(x, z, h=None):
        return [round(x, 2), round(elevation(x, z) if h is None else h, 2), round(z, 2)]

    roads, adjacency, graph, shapes = [], defaultdict(dict), {}, []
    crossings = Counter(nd.attrib["ref"] for w in ways.values() if tags(w).get("highway") in WIDTHS for nd in w.findall("nd"))
    for way in ways.values():
        t = tags(way)
        kind = t.get("highway")
        ids = [n.attrib["ref"] for n in way.findall("nd")]
        if len(ids) < 2:
            continue
        if kind in ("pedestrian", "footway", "path"):
            line = LineString([nodes[n] for n in ids])
            if t.get("name", "").startswith("Советская") or (park is not None and line.intersects(park)):
                for part in getattr(line.intersection(REGION), "geoms", [line.intersection(REGION)]):
                    if part.geom_type == "LineString" and part.length > 4:
                        paths.append(list(part.coords))
            continue
        if kind not in WIDTHS:
            continue
        bridge = t.get("bridge", "no") not in ("no", "")
        dirt = t.get("surface") in ("ground", "dirt", "gravel", "unpaved", "sand")
        width = WIDTHS[kind]
        try:
            width = float(np.clip(float(t.get("width", width).split()[0]), 3.0, 13.0))
        except (ValueError, AttributeError):
            pass
        line = LineString([nodes[n] for n in ids])
        if not line.intersects(REGION):
            continue
        public = t.get("access") not in ("private", "no") and t.get("motor_vehicle") not in ("private", "no")
        pts = [xyz(*nodes[n]) for n in ids]
        if bridge:
            start = max(pts[0][1], WATER + 2.2)
            end = max(pts[-1][1], WATER + 2.2)
            travel = 0.0
            for i, p in enumerate(pts):
                if i:
                    travel += math.hypot(p[0] - pts[i-1][0], p[2] - pts[i-1][2])
                p[1] = round(start + (end - start) * travel / max(1.0, line.length), 2)
        roads.append({"name": t.get("name", ""), "hw": kind, "w": width, "br": int(bridge),
                      "dirt": dirt, "pts": pts, "junctions": [i for i, n in enumerate(ids) if crossings[n] > 1]})
        shapes.append(line)
        if not public or kind == "service":
            continue
        for n, p in zip(ids, pts):
            if n not in graph or bridge:
                graph[n] = p
        limit = {"secondary": 55, "residential": 36, "unclassified": 42}[kind]
        try:
            limit = int(t.get("maxspeed", limit))
        except ValueError:
            pass
        for a, b in zip(ids, ids[1:]):
            length = math.dist(nodes[a], nodes[b])
            if length < 0.05:
                continue
            if t.get("oneway") != "-1":
                adjacency[a][b] = length, limit, bridge
            if t.get("oneway") not in ("yes", "1", "true"):
                adjacency[b][a] = length, limit, bridge

    # Route the two closed events along public motor roads near the original loops.
    # Avoid immediate U-turns and discourage revisiting the same road in a lap.
    interior = REGION.buffer(-30)
    active = {n for n in graph if interior.covers(shapely.Point(nodes[n]))}
    reverse = defaultdict(set)
    for a in active:
        for b in adjacency[a].keys() & active:
            reverse[b].add(a)

    def reachable(start, edges):
        seen, pending = {start}, [start]
        while pending:
            for b in edges[pending.pop()].keys() & active:
                if b not in seen:
                    seen.add(b)
                    pending.append(b)
        return seen

    center = min(active, key=lambda n: math.dist(nodes[n], (380, -200)))
    component = reachable(center, adjacency) & reachable(center, {n: dict.fromkeys(reverse[n]) for n in active})
    graph_ids = sorted(component)
    tree = cKDTree([nodes[n] for n in graph_ids])

    def shortest(start, goal, used, incoming):
        queue = [(0.0, start)]
        cost = {start: 0.0}
        came_from = {}
        while queue:
            score, a = heapq.heappop(queue)
            if score != cost[a]:
                continue
            if a == goal:
                path = [a]
                while path[-1] != start:
                    path.append(came_from[path[-1]])
                return path[::-1]
            for b, (distance, _, _) in adjacency[a].items():
                if b == incoming and a == start:
                    continue
                if b not in component:
                    continue
                weight = distance * (1.0 + 5.0 * used[tuple(sorted((a, b)))])
                if score + weight < cost.get(b, float("inf")):
                    cost[b] = score + weight
                    came_from[b] = a
                    heapq.heappush(queue, (cost[b], b))
        return []

    for name in ("race_circuit", "olimp_circuit"):
        points = [(p[0], p[2]) for p in data[name]]
        prior = LineString(points + points[:1])
        anchors = [prior.interpolate(d) for d in np.arange(45, prior.length - 125, 345)]
        if name == "olimp_circuit":
            # The access road to Olimp is a spur. The second circuit stays on
            # the connected streets below Puzanka instead of making a U-turn.
            anchors = [shapely.Point(x, z) for x, z in [
                (477, -805), (393, -617), (527, -549), (670, -490),
                (745, -677), (876, -616), (730, -265), (463, -373),
                (547, -578),
            ]]
        seeds = list(dict.fromkeys(graph_ids[tree.query([p.x, p.y])[1]] for p in anchors))
        path = [seeds[0]]
        used = Counter()
        for goal in seeds[1:] + seeds[:1]:
            leg = shortest(path[-1], goal, used, path[-2] if len(path) > 1 else None)
            if not leg:
                if goal != seeds[0]:
                    continue
                leg = shortest(path[-1], goal, used, None)
            used.update(tuple(sorted(edge)) for edge in zip(leg, leg[1:]))
            path.extend(leg[1:])
        if path[-1] != path[0]:
            raise ValueError(f"{name} did not close")
        # Move start away from the nearest junction, into a straight segment.
        segment = max(range(min(15, len(path) - 1)), key=lambda i: math.dist(nodes[path[i]], nodes[path[i+1]]))
        route = [graph[n] for n in path[segment+1:-1] + path[:segment+1]]
        a, b = graph[path[segment]], graph[path[segment+1]]
        start = [round((x+y)/2, 2) for x, y in zip(a, b)]
        data[name] = [start, *route]
        print(name, round(sum(math.dist(a, b) for a, b in zip(data[name], data[name][1:] + [start]))), "m")

    buildings = []
    for way in ways.values():
        t = tags(way)
        if t.get("building") in (None, "no", "roof"):
            continue
        pts = points_of(way, nodes)
        if len(pts) < 4 or pts[0] != pts[-1]:
            continue
        shape = Polygon(pts)
        if not shape.is_valid or not 10 < shape.area or not REGION.covers(shape.centroid) or water_geom.covers(shape.centroid):
            continue
        p = shape.centroid
        x, z = p.x, p.y
        kind = t["building"]
        small_home = kind in ("house", "detached", "yes") and shape.area < 320
        try:
            h = float(t.get("height", 0).split()[0])
        except (ValueError, AttributeError):
            h = 0.0
        if not h:
            try:
                h = 2.9 * float(t.get("building:levels", 0))
            except ValueError:
                pass
        if not h:
            h = 3.6 if small_home else (13.8 if kind == "apartments" else 6.8)
        if shape.area < 35:
            h = min(h, 3.0)
        ring = shapely.orient_polygons(shape.simplify(0.45, preserve_topology=True)).exterior
        style = 0 if kind == "apartments" else 1 if small_home else 2
        # Point rings are counter-clockwise in the x/z plane.
        buildings.append([round(x, 2), round(z, 2), round(h, 2), style, small_home, serialize_ring(ring), int(way.attrib["id"])])

    water_tris = []
    for p in polygon_parts(water_geom.simplify(0.85, preserve_topology=True)):
        for tri in shapely.constrained_delaunay_triangles(p).geoms:
            ring = list(shapely.orient_polygons(tri).exterior.coords)[:3]
            water_tris.append([[round(x, 2), round(z, 2)] for x, z in ring])
    trees = []
    rng = np.random.default_rng(116)
    road_index = shapely.STRtree(shapes)
    for forest in woodlands:
        minx, minz, maxx, maxz = forest.bounds
        for x, z in zip(rng.uniform(minx, maxx, max(3, int(forest.area/410))),
                        rng.uniform(minz, maxz, max(3, int(forest.area/410)))):
            p = shapely.Point(x, z)
            if forest.contains(p) and not len(road_index.query(p, predicate="dwithin", distance=8)):
                trees.append(xyz(x, z))
    for name, lat, lon in [("puzanka", 55.726199, 51.413932), ("olimp", 55.710372, 51.378792)]:
        data["landmarks"][name]["pos"] = xyz(*project(lat, lon))
    if park is not None:
        cp = park.centroid
        data["landmarks"]["yashlek"] = {"name": "Сквер «Яшьлек»", "pos": xyz(cp.x, cp.y)}
    for lm in data["landmarks"].values():
        lm["pos"] = xyz(lm["pos"][0], lm["pos"][2])
    indices = {n: i for i, n in enumerate(graph)}
    data.update(bounds={"x_min": X0, "x_max": X1, "z_min": Z0, "z_max": Z1, "grid_n": GRID, "water_y": WATER},
                terrain_h=np.round(heights, 2).ravel().tolist(), roads=roads,
                graph_nodes=list(graph.values()), graph_adj=[[[indices[b], round(dist, 2), lim, int(br)] for b, (dist, lim, br) in adjacency[a].items()] for a in graph],
                footprints=buildings, water_triangles=water_tris,
                water_rings=[serialize_ring(p.exterior) for p in polygon_parts(water_geom)],
                trees=trees, walking_paths=[[xyz(*p) for p in line] for line in paths],
                geographic_origin={"lat": LAT, "lon": LON, "vertical_offset_m": datum})
    output.write_text(json.dumps(data, ensure_ascii=False, separators=(",", ":")) + "\n")
    raster = Image.new("RGB", (900, 1018), "#111a22")
    draw = ImageDraw.Draw(raster)
    def pixel(x, z):
        return ((x-X0)/(X1-X0)*(raster.width-1), (z-Z0)/(Z1-Z0)*(raster.height-1))
    for poly in polygon_parts(water_geom):
        draw.polygon([pixel(x,z) for x,z in poly.exterior.coords], fill="#23516a")
        for ring in poly.interiors:
            draw.polygon([pixel(x,z) for x,z in ring.coords], fill="#111a22")
    for road in sorted(roads, key=lambda r: r["hw"] == "secondary"):
        draw.line([pixel(p[0],p[2]) for p in road["pts"]],
                  fill="#889ba5" if road["hw"] == "secondary" else "#535e66",
                  width=2 if road["hw"] == "secondary" else 1)
    raster.save(output.with_name("minimap.png"), optimize=True)
    print(len(roads), "road segments;", len(buildings), "footprints;", len(trees), "trees;", len(water_tris), "water triangles; DEM datum", datum)


if __name__ == "__main__":
    main()
