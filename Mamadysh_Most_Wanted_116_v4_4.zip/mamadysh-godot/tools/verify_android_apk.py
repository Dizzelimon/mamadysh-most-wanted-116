"""Check the signed ARM64 package produced by the Godot Android export."""
import argparse
import hashlib
import re
import struct
import subprocess
import zipfile
from pathlib import Path


def run(tool, *args):
    return subprocess.check_output([str(tool), *map(str, args)], text=True)


def check_apk(apk, build_tools, package, version_code):
    signer_output = run(build_tools / "apksigner", "verify", "--verbose", "--print-certs", apk)
    if "Verified using v2 scheme (APK Signature Scheme v2): true" not in signer_output:
        raise ValueError("APK has no valid v2 signature")
    print(signer_output, end="")
    run(build_tools / "zipalign", "-c", "-P", "16", "4", apk)

    manifest = run(build_tools / "aapt", "dump", "badging", apk)
    first_line = manifest.splitlines()[0]
    if f"name='{package}'" not in first_line or f"versionCode='{version_code}'" not in first_line:
        raise ValueError(f"Unexpected package ID or version code: {first_line}")
    native_abis = re.findall(r"'([^']+)'", next(line for line in manifest.splitlines() if line.startswith("native-code:")))
    if native_abis != ["arm64-v8a"]:
        raise ValueError(f"Unexpected Android ABIs: {native_abis}")
    if re.search(r"^uses-feature:.*android\.hardware\.vulkan", manifest, flags=re.MULTILINE):
        raise ValueError("Manifest marks Vulkan as required")
    print(first_line)

    with zipfile.ZipFile(apk) as z:
        bad_file = z.testzip()
        if bad_file:
            raise ValueError(f"Integrity check failed: {bad_file}")
        libraries = [n for n in z.namelist() if n.startswith("lib/arm64-v8a/") and n.endswith(".so")]
        if "lib/arm64-v8a/libgodot_android.so" not in libraries:
            raise ValueError("Godot ARM64 engine is missing")
        for name in libraries:
            library = z.read(name)
            if library[:6] != b"\x7fELF\x02\x01" or struct.unpack_from("<H", library, 18)[0] != 183:
                raise ValueError(f"Not a little-endian AArch64 library: {name}")
            offset = struct.unpack_from("<Q", library, 32)[0]
            header_size, count = struct.unpack_from("<HH", library, 54)
            segments = [
                struct.unpack_from("<Q", library, offset + i * header_size + 48)[0]
                for i in range(count)
                if struct.unpack_from("<I", library, offset + i * header_size)[0] == 1
            ]
            if not segments or min(segments) < 16384:
                raise ValueError(f"ELF LOAD alignment is below 16 KiB for {name}: {segments}")
            print(f"{name}: LOAD alignment {min(segments)} bytes")
        if not any(n.endswith("/mamadysh_map.json") for n in z.namelist()):
            raise ValueError("Game map is missing from the APK")
        project = z.read("assets/project.binary")
        if b"gl_compatibility" not in project:
            raise ValueError("Compatibility renderer is not present in project configuration")
    digest = hashlib.file_digest(apk.open("rb"), "sha256").hexdigest()
    print(f"SHA-256: {digest}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("apk", type=Path)
    parser.add_argument("build_tools", type=Path)
    parser.add_argument("package")
    parser.add_argument("version_code", type=int)
    args = parser.parse_args()
    check_apk(args.apk, args.build_tools, args.package, args.version_code)
