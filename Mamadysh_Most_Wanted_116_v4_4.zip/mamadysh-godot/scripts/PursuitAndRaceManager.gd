extends Node
class_name PursuitAndRaceManager

enum GameMode { FREE_ROAM, RACE, PURSUIT }
enum State { IDLE, COUNTDOWN, ACTIVE, BUSTED, EVADED, RACE_DONE }

signal hud_event(msg: String, color: Color)
signal state_changed(new_state: State, summary: Dictionary)

var world: MamadyshWorld
var player: MamadyshVehicle
var player_ctrl: PlayerCarController
var mode: GameMode = GameMode.RACE
var state: State = State.IDLE

var racers: Array[MamadyshVehicle] = []
var cops: Array[MamadyshVehicle] = []
var traffic: Array[MamadyshVehicle] = []
var vehicles_root: Node3D

var bounty := 0
var heat_level := 0
var bust_meter := 0.0
var evade_meter := 0.0
var takedowns := 0

var current_lap := 1
var total_laps := 1
var next_cp_idx := 1
var race_time := 0.0
var sector_times: Array[float] = []
var _sector_start := 0.0
var countdown_timer := 0.0
var _last_countdown_int := 4

var _cp_gate: Node3D
var _beep_player: AudioStreamPlayer
var _go_player: AudioStreamPlayer
var _roadblock_timer := 10.0
var _cop_spawn_timer := 4.0
var _bounty_tick := 0.0
var _water_timer := 0.0
var _is_night := false
var race_place := 1
var _previous_race_positions: Dictionary = {}
var _rival_checkpoints: Dictionary = {}
var _rival_finish_count := 0

func setup(v_root: Node3D, w: MamadyshWorld) -> void:
	vehicles_root = v_root
	world = w

	_beep_player = AudioStreamPlayer.new()
	_beep_player.stream = load("res://assets/audio/countdown_beep.wav")
	_beep_player.volume_db = -4.0
	add_child(_beep_player)

	_go_player = AudioStreamPlayer.new()
	_go_player.stream = load("res://assets/audio/countdown_go.wav")
	_go_player.volume_db = -3.0
	add_child(_go_player)

	_build_checkpoint_gate()

func _build_checkpoint_gate() -> void:
	_cp_gate = Node3D.new()
	var gmat := StandardMaterial3D.new()
	gmat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	gmat.albedo_color = Color(1.0, 0.72, 0.12, 0.48)
	gmat.emission_enabled = true; gmat.emission = Color(1.0, 0.72, 0.15); gmat.emission_energy_multiplier = 2.6
	gmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	for sx in [-7.0, 7.0]:
		var p := MeshInstance3D.new(); var cm := CylinderMesh.new(); cm.top_radius = 0.3; cm.bottom_radius = 0.45; cm.height = 6.5
		p.mesh = cm; p.position = Vector3(sx, 3.25, 0); p.material_override = gmat; _cp_gate.add_child(p)
	var bar := MeshInstance3D.new(); var bm := BoxMesh.new(); bm.size = Vector3(14.6, 0.65, 0.65)
	bar.mesh = bm; bar.position = Vector3(0, 6.2, 0); bar.material_override = gmat; _cp_gate.add_child(bar)
	_cp_gate.visible = false
	add_child(_cp_gate)

func clear_entities() -> void:
	for debris in get_tree().get_nodes_in_group("session_debris"): debris.queue_free()
	for arr in [racers, cops, traffic]:
		for v in arr:
			if is_instance_valid(v): v.queue_free()
		arr.clear()
	if is_instance_valid(world): world.clear_roadblocks()
	_cp_gate.visible = false

func start_session(selected_mode: GameMode, p_vehicle: MamadyshVehicle, p_ctrl: PlayerCarController, is_night: bool) -> void:
	clear_entities()
	mode = selected_mode
	player = p_vehicle
	player_ctrl = p_ctrl
	_is_night = is_night

	bounty = 0
	heat_level = 1 if mode == GameMode.PURSUIT else 0
	bust_meter = 0.0
	evade_meter = 0.0
	takedowns = 0
	current_lap = 1
	total_laps = 1
	next_cp_idx = 1
	race_time = 0.0
	sector_times.clear()
	_sector_start = 0.0
	_roadblock_timer = 14.0
	_cop_spawn_timer = 3.5
	_water_timer = 0.0

	player.crashed.connect(_on_player_crash)
	player.set_headlights_night(is_night)
	player.add_to_group("vehicles_headlights")

	_spawn_traffic(0 if mode == GameMode.RACE else (4 if OS.has_feature("mobile") else 6))

	if mode == GameMode.RACE:
		_spawn_racers(p_vehicle.car_cfg["id"])
		race_place = 1
		_rival_finish_count = 0
		_rival_checkpoints.clear()
		_previous_race_positions.clear()
		_update_checkpoint_gate()
		player_ctrl.controls_locked = true
		state = State.COUNTDOWN
		countdown_timer = 3.4
		_last_countdown_int = 4
	elif mode == GameMode.PURSUIT:
		player_ctrl.controls_locked = false
		state = State.ACTIVE
		_spawn_police(1, 65.0)
		_spawn_police(1, -60.0)
		hud_event.emit("ПОГОНЯ ДПС • УРОВЕНЬ ЖАРА 1!", Color(1.0, 0.32, 0.28))
	else:
		player_ctrl.controls_locked = false
		state = State.ACTIVE
		_spawn_police(1, 220.0)
		hud_event.emit("СВОБОДНАЯ ЕЗДА ПО МАМАДЫШУ", Color(0.45, 0.88, 1.0))

func _spawn_traffic(count: int) -> void:
	var pool := ["vaz_2107", "gaz_3110_volga", "lada_niva", "lada_priora", "uaz_patriot"]
	var L := world.get_track_length()
	for i in range(count):
		var cid: String = pool[i % pool.size()]
		var v := VehicleFactory.create_vehicle(cid, "traffic", false)
		var d := fmod(140.0 + float(i) * (L / float(count)), L)
		var tr := world.sample_track(d)
		v.transform = tr
		v.position += tr.basis.x * 2.8 + Vector3(0, 0.35, 0)
		v.set_headlights_night(_is_night)
		v.add_to_group("vehicles_headlights")

		var ai := AICarDriver.new(); ai.vehicle = v; ai.world = world; ai.role = AICarDriver.Role.TRAFFIC
		ai.target_speed_ms = 14.5
		v.add_child(ai)
		vehicles_root.add_child(v); traffic.append(v)

func _spawn_racers(player_car_id: String) -> void:
	var candidates := ["lada_vesta_sport", "lada_priora", "gaz_3110_volga", "vaz_2107"]
	var picks: Array[String] = []
	for c in candidates:
		if c != player_car_id and picks.size() < 2: picks.append(c)
	var offsets := [Vector2(-1.45, -6.5), Vector2(1.45, -13.0)]
	for i in range(picks.size()):
		var v := VehicleFactory.create_vehicle(picks[i], "racer", true)
		var tr := world.sample_track(world.get_track_length() + offsets[i].y)
		v.transform = tr; v.position += tr.basis.x * offsets[i].x + Vector3(0, 0.35, 0)
		v.set_headlights_night(_is_night); v.add_to_group("vehicles_headlights")
		var ai := AICarDriver.new(); ai.vehicle = v; ai.world = world; ai.role = AICarDriver.Role.RACER
		ai.lane_offset = offsets[i].x * 0.65; ai.target_speed_ms = 31.0 + float(i) * 2.5; ai.active = false
		v.add_child(ai); vehicles_root.add_child(v); racers.append(v)

func _spawn_police(count: int, ahead_dist := 75.0) -> void:
	if not is_instance_valid(player): return
	var avoid: Array[Vector3] = [player.global_position]
	for arr in [cops, racers, traffic]:
		for v in arr:
			if is_instance_valid(v): avoid.append(v.global_position)
	var min_d := clampf(absf(ahead_dist) * 0.75, 50.0, 140.0)
	var max_d := min_d + 65.0
	for i in range(count):
		var v := VehicleFactory.create_vehicle("dps_patrol", "police", true)
		var tr := world.get_street_spawn_near(player.global_position, min_d, max_d, player.global_position, avoid)
		avoid.append(tr.origin)
		v.transform = tr
		v.siren_active = (heat_level > 0); v.set_headlights_night(_is_night); v.add_to_group("vehicles_headlights")
		var ai := AICarDriver.new(); ai.vehicle = v; ai.world = world; ai.target_vehicle = player
		ai.role = AICarDriver.Role.POLICE
		ai.cop_state = AICarDriver.CopState.PURSUIT if heat_level > 0 else AICarDriver.CopState.PATROL
		v.add_child(ai); vehicles_root.add_child(v); cops.append(v)

func _on_player_crash(imp: float, other: Node) -> void:
	if state != State.ACTIVE or not is_instance_valid(player): return
	if other is MamadyshVehicle:
		var ov := other as MamadyshVehicle
		if ov.is_police:
			if heat_level == 0:
				heat_level = 1; hud_event.emit("ПРОВОКАЦИЯ ДПС! НАЧАТА ПОГОНЯ!", Color(1.0, 0.3, 0.25))
			if imp * player.ram_power > 5000.0:
				takedowns += 1; bounty += 2500
				hud_event.emit("ТАРАН ДПС! +2 500 ₽ РЕЙТИНГА", Color(1.0, 0.82, 0.2))
				_disable_cop_temporarily(ov)
		else: bounty += 250
	elif other is RigidBody3D: bounty += 150

func _disable_cop_temporarily(cop: MamadyshVehicle) -> void:
	for c in cop.get_children():
		if c is AICarDriver:
			c.active = false; cop.siren_active = false
			get_tree().create_timer(7.0).timeout.connect(func():
				if is_instance_valid(c) and is_instance_valid(cop):
					c.active = true; cop.siren_active = heat_level > 0
			)

func _update_checkpoint_gate() -> void:
	if world.checkpoint_positions.is_empty(): return
	var cp := world.checkpoint_positions[next_cp_idx % world.checkpoint_positions.size()]
	_cp_gate.global_transform = cp["transform"]
	_cp_gate.scale.x = 0.55
	_cp_gate.visible = (mode == GameMode.RACE and state == State.ACTIVE)

func _process(delta: float) -> void:
	if state == State.COUNTDOWN:
		countdown_timer -= delta
		var c_int := ceili(countdown_timer)
		if c_int != _last_countdown_int and c_int >= 1 and c_int <= 3:
			_last_countdown_int = c_int; _beep_player.play()
			hud_event.emit(str(c_int), Color(1.0, 0.86, 0.22))
		if countdown_timer <= 0.0:
			_go_player.play(); state = State.ACTIVE; player_ctrl.controls_locked = false
			for r in racers:
				for ch in r.get_children():
					if ch is AICarDriver: ch.active = true
			_previous_race_positions[player] = player.global_position
			for racer in racers:
				_previous_race_positions[racer] = racer.global_position
				_rival_checkpoints[racer] = 1
			_update_checkpoint_gate(); hud_event.emit("СТАРТ!", Color(0.28, 1.0, 0.45))
		return

	if state != State.ACTIVE or not is_instance_valid(player): return

	var unscaled_dt := delta / maxf(Engine.time_scale, 0.1)
	race_time += unscaled_dt

	# Water hazard recovery: if car splashes into Vyatka or Oshma, recover onto nearest road!
	if world.is_in_water(player.global_position):
		_water_timer += unscaled_dt
		if _water_timer > 0.45:
			_water_timer = 0.0
			var tr := world.get_nearest_road_transform(player.global_position)
			player.global_transform = tr
			clear_player_gate_sample()
			player.linear_velocity = Vector3.ZERO; player.angular_velocity = Vector3.ZERO
			hud_event.emit("ВЫЕЗД В РЕКУ! ЭВАКУАЦИЯ НА БЕРЕГ", Color(0.35, 0.85, 1.0))
	else:
		_water_timer = 0.0

	if mode == GameMode.RACE and not world.checkpoint_positions.is_empty():
		_update_race_progress()
		if state != State.ACTIVE:
			return

	if heat_level > 0 or mode == GameMode.PURSUIT:
		_process_pursuit(unscaled_dt)

func _crossed_gate(car: MamadyshVehicle, index: int) -> bool:
	var current := car.global_position
	var previous: Vector3 = _previous_race_positions.get(car, current)
	_previous_race_positions[car] = current
	if previous.distance_squared_to(current) > 625.0:
		return false # Resetting or teleporting the car never counts.
	var tr: Transform3D = world.checkpoint_positions[index]["transform"]
	var before := tr.affine_inverse() * previous
	var now := tr.affine_inverse() * current
	if before.z < 0.0 or now.z >= 0.0:
		return false
	var crossing := before.lerp(now, before.z / (before.z - now.z))
	return absf(crossing.x) < 4.9 and absf(crossing.y) < 3.5

func clear_player_gate_sample() -> void:
	if is_instance_valid(player):
		_previous_race_positions.erase(player)

func _update_race_progress() -> void:
	var count := world.checkpoint_positions.size()
	for rival in racers:
		if not is_instance_valid(rival):
			continue
		var index := int(_rival_checkpoints.get(rival, 1))
		if index < count + 1 and _crossed_gate(rival, index % count):
			_rival_checkpoints[rival] = index + 1
			if index == count:
				_rival_finish_count += 1
	race_place = 1
	var passed := count if next_cp_idx == 0 else next_cp_idx
	var player_fraction := _segment_fraction(player.global_position, next_cp_idx)
	for rival in racers:
		if not is_instance_valid(rival):
			continue
		var index := int(_rival_checkpoints.get(rival, 1))
		if index > passed or (index == passed and _segment_fraction(rival.global_position, next_cp_idx) > player_fraction):
			race_place += 1
	if not _crossed_gate(player, next_cp_idx):
		return
	if next_cp_idx == 0 or next_cp_idx % maxi(1, count / 3) == 0:
		sector_times.append(race_time - _sector_start)
		_sector_start = race_time
		hud_event.emit("СЕКТОР %d • %s" % [sector_times.size(), format_time(sector_times[-1])], Color(0.4, 1.0, 0.7))
	if next_cp_idx == 0:
		race_place = _rival_finish_count + 1
		_finish_race()
		return
	next_cp_idx = (next_cp_idx + 1) % count
	_update_checkpoint_gate()

func _process_pursuit(dt: float) -> void:
	_bounty_tick += dt
	if _bounty_tick >= 1.0:
		_bounty_tick = 0.0
		if player.speed > 18.0:
			bounty += int(player.speed * 4.5) * max(1, heat_level)

	var desired_heat := clampi(1 + int(bounty / 4500), 1, 5)
	if desired_heat > heat_level:
		heat_level = desired_heat
		hud_event.emit("УРОВЕНЬ ЖАРА ДПС: %d ★" % heat_level, Color(1.0, 0.28, 0.24))

	var target_cops := clampi(heat_level, 1, 3)
	_cop_spawn_timer -= dt
	if cops.size() < target_cops and _cop_spawn_timer <= 0.0:
		_cop_spawn_timer = 7.0
		_spawn_police(1, 95.0)

	if heat_level >= 2:
		_roadblock_timer -= dt
		if _roadblock_timer <= 0.0:
			_roadblock_timer = maxf(12.0, 24.0 - float(heat_level) * 2.5)
			var ahead_pos := player.global_position - player.global_transform.basis.z * 135.0
			var tr := world.get_nearest_road_transform(ahead_pos)
			world.spawn_roadblock_at_pos(tr.origin, -tr.basis.z)
			hud_event.emit("ВНИМАНИЕ: ВПЕРЕДИ БЛОКПОСТ ДПС!", Color(1.0, 0.55, 0.15))

	var nearest := 9999.0
	for c in cops:
		if is_instance_valid(c):
			var d := c.global_position.distance_to(player.global_position)
			if d < nearest: nearest = d
			if d > 280.0 and mode == GameMode.PURSUIT:
				var behind_pos := player.global_position + player.global_transform.basis.z * 90.0
				var tr := world.get_nearest_road_transform(behind_pos)
				c.global_transform = tr; c.global_position += Vector3(0, 0.4, 0)
				c.linear_velocity = -tr.basis.z * 24.0

	if nearest < 13.5 and player.get_speed_kmh() < 14:
		bust_meter = minf(1.0, bust_meter + dt / 4.2)
		evade_meter = maxf(0.0, evade_meter - dt * 0.5)
		if bust_meter >= 1.0: _trigger_busted()
	elif nearest > 115.0:
		bust_meter = maxf(0.0, bust_meter - dt * 0.6)
		evade_meter = minf(1.0, evade_meter + dt / 7.5)
		if evade_meter >= 1.0 and mode == GameMode.PURSUIT: _trigger_evaded()
	else:
		bust_meter = maxf(0.0, bust_meter - dt * 0.35)
		evade_meter = maxf(0.0, evade_meter - dt * 0.35)

func _finish_race() -> void:
	state = State.RACE_DONE; player_ctrl.controls_locked = true; bounty += 5000
	var old := read_best(world.active_circuit_name, player.car_cfg["id"])
	var improved := old <= 0.0 or race_time < old
	if improved:
		var records := ConfigFile.new()
		records.load("user://records.cfg")
		records.set_value(world.active_circuit_name, player.car_cfg["id"], race_time)
		records.save("user://records.cfg")
	var sectors := ""
	for time in sector_times: sectors += format_time(time) + "  "
	state_changed.emit(State.RACE_DONE, {"title": "НОВЫЙ ЛИЧНЫЙ РЕКОРД!" if improved else "ФИНИШ В МАМАДЫШЕ!", "subtitle": "%d место из %d • %s\nСекторы: %s" % [race_place, racers.size() + 1, format_time(race_time), sectors], "bounty": bounty})

func _trigger_busted() -> void:
	state = State.BUSTED; player_ctrl.controls_locked = true
	state_changed.emit(State.BUSTED, {"title": "АРЕСТОВАН ДПС (116 RUS)", "subtitle": "Полиция Мамадыша заблокировала ваш автомобиль", "bounty": bounty})

func _trigger_evaded() -> void:
	state = State.EVADED; player_ctrl.controls_locked = true; bounty += heat_level * 3000
	state_changed.emit(State.EVADED, {"title": "УШЁЛ ОТ ПОГОНИ!", "subtitle": "Вы оторвались от патрулей ДПС (Уровень жара %d)" % heat_level, "bounty": bounty})

static func format_time(seconds: float) -> String:
	return "%02d:%06.3f" % [int(seconds) / 60, fmod(seconds, 60.0)]

static func read_best(route: String, car: String) -> float:
	var records := ConfigFile.new()
	if records.load("user://records.cfg") != OK: return 0.0
	var value: Variant = records.get_value(route, car, 0.0)
	if not (value is float or value is int): return 0.0
	var seconds := float(value)
	return seconds if is_finite(seconds) and seconds > 0.0 and seconds < 86400.0 else 0.0

func _segment_fraction(pos: Vector3, next_index: int) -> float:
	var count := world.checkpoint_positions.size()
	var start: Vector3 = world.checkpoint_positions[posmod(next_index - 1, count)]["pos"]
	var finish: Vector3 = world.checkpoint_positions[next_index]["pos"]
	var segment := finish - start
	return clampf((pos - start).dot(segment) / maxf(segment.length_squared(), 0.01), 0.0, 1.0)
