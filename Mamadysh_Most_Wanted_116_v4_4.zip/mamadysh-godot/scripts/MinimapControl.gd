extends Control
class_name MinimapControl

var world: MamadyshWorld
var manager: PursuitAndRaceManager
var _track_pts: PackedVector2Array = PackedVector2Array()
var _pulse := 0.0
var _redraw_after := 0.0
var update_interval := 0.05
const RADAR_RADIUS := 340.0
const BASE_MAP := preload("res://assets/map/minimap.png")

func setup(w: MamadyshWorld, m: PursuitAndRaceManager) -> void:
	world = w
	manager = m
	refresh_map_cache()

func refresh_map_cache() -> void:
	_track_pts.clear()
	if not is_instance_valid(world):
		return
	if world.road_curve:
		var L := world.get_track_length()
		var n := maxi(130, ceili(L / 16.0))
		for i in range(n):
			var p := world.road_curve.sample_baked(float(i) / float(n) * L, true)
			_track_pts.append(Vector2(p.x, p.z))

func _process(delta: float) -> void:
	if not is_visible_in_tree():
		return
	_pulse += delta * 8.0
	_redraw_after -= delta
	if _redraw_after <= 0.0:
		_redraw_after = update_interval
		queue_redraw()

func _to_radar(wx: float, wz: float, center_w: Vector2, rot_cos: float, rot_sin: float) -> Vector2:
	var dx := wx - center_w.x
	var dz := wz - center_w.y
	# Rotate so player's heading points UP on radar
	var rx := dx * rot_cos - dz * rot_sin
	var ry := dx * rot_sin + dz * rot_cos
	var sc := (minf(size.x, size.y) * 0.48) / RADAR_RADIUS
	return size * 0.5 + Vector2(rx * sc, ry * sc)

func _draw() -> void:
	draw_rect(Rect2(Vector2.ZERO, size), Color(0.05, 0.08, 0.12, 0.84), true)
	if not is_instance_valid(world):
		return

	var center_w := Vector2(388.0, -197.0)
	var heading := 0.0
	if is_instance_valid(manager) and is_instance_valid(manager.player):
		var pp := manager.player.global_position
		center_w = Vector2(pp.x, pp.z)
		var fwd := -manager.player.global_transform.basis.z
		heading = atan2(fwd.x, -fwd.z)

	var rc := cos(-heading)
	var rs := sin(-heading)

	# Clip everything cleanly inside the minimap frame by checking bounds or using DrawSetTransform
	RenderingServer.canvas_item_set_clip(get_canvas_item(), true)

	var zoom := minf(size.x, size.y) * 0.48 / RADAR_RADIUS
	draw_set_transform(size * 0.5 - center_w.rotated(-heading) * zoom, -heading, Vector2.ONE * zoom)
	draw_texture_rect(BASE_MAP, Rect2(world.x_min, world.z_min, world.x_max - world.x_min, world.z_max - world.z_min), false)
	draw_set_transform(Vector2.ZERO)

	# Active Race Circuit highlight
	if _track_pts.size() > 2 and is_instance_valid(manager) and manager.mode == PursuitAndRaceManager.GameMode.RACE:
		var tpoly := PackedVector2Array()
		for p in _track_pts:
			tpoly.append(_to_radar(p.x, p.y, center_w, rc, rs))
		tpoly.append(tpoly[0])
		draw_polyline(tpoly, Color(0.95, 0.78, 0.25, 0.92), 3.6, true)

	# Landmarks
	var lm_tags := {"eiffel": "Э", "olimp": "ОЛ", "embankment": "В", "yashlek": "Я", "puzanka": "П", "rdk": "ДК"}
	for lk: String in lm_tags.keys():
		if world.landmarks.has(lk):
			var lp: Array = world.landmarks[lk]["pos"]
			var mp := _to_radar(float(lp[0]), float(lp[2]), center_w, rc, rs)
			if Rect2(Vector2(6, 6), size - Vector2(12, 12)).has_point(mp):
				draw_circle(mp, 4.2, Color(0.95, 0.75, 0.18))

	if is_instance_valid(manager):
		# Next checkpoint
		if manager.mode == PursuitAndRaceManager.GameMode.RACE and not world.checkpoint_positions.is_empty():
			var cp: Vector3 = world.checkpoint_positions[manager.next_cp_idx % world.checkpoint_positions.size()]["pos"]
			var cm := _to_radar(cp.x, cp.z, center_w, rc, rs)
			draw_circle(cm, 5.5, Color(1.0, 0.88, 0.18))

		# Rivals
		for r in manager.racers:
			if is_instance_valid(r):
				var rm := _to_radar(r.global_position.x, r.global_position.z, center_w, rc, rs)
				draw_circle(rm, 4.0, Color(1.0, 0.55, 0.12))

		# ДПС Patrols
		var cop_col := Color(1.0, 0.2, 0.2) if int(_pulse) % 2 == 0 else Color(0.22, 0.55, 1.0)
		for c in manager.cops:
			if is_instance_valid(c):
				var cm := _to_radar(c.global_position.x, c.global_position.z, center_w, rc, rs)
				draw_circle(cm, 4.8, cop_col)

	# Player centered upward arrow
	var mid := size * 0.5
	var tri := PackedVector2Array([mid + Vector2(0, -7.5), mid + Vector2(5.2, 5.5), mid + Vector2(-5.2, 5.5)])
	draw_colored_polygon(tri, Color(0.25, 0.96, 0.45))
	draw_rect(Rect2(Vector2.ZERO, size), Color(0.95, 0.72, 0.2, 0.72), false, 2.0)
