extends Node
class_name PlayerCarController

var vehicle: MamadyshVehicle
var touch_throttle := 0.0
var touch_brake := 0.0
var touch_left := 0.0
var touch_right := 0.0
var touch_steer := 0.0  # Analog steering: +1.0 = full left, -1.0 = full right
var touch_handbrake := 0.0
var touch_nos := false
var touch_sb := false
var controls_locked := false

var _sb_sound_in: AudioStreamPlayer
var _sb_sound_out: AudioStreamPlayer
var _was_sb := false
var _analog_steering := 0.0
var _reverse_hold := 0.0

func _ready() -> void:
	_sb_sound_in = AudioStreamPlayer.new()
	_sb_sound_in.stream = load("res://assets/audio/speedbreaker_in.wav")
	_sb_sound_in.volume_db = -4.0
	add_child(_sb_sound_in)

	_sb_sound_out = AudioStreamPlayer.new()
	_sb_sound_out.stream = load("res://assets/audio/speedbreaker_out.wav")
	_sb_sound_out.volume_db = -4.0
	add_child(_sb_sound_out)

func _physics_process(delta: float) -> void:
	if not is_instance_valid(vehicle):
		return

	if controls_locked:
		_analog_steering = 0.0
		vehicle.throttle_input = 0.0
		vehicle.brake_input = 0.65
		vehicle.handbrake_input = 1.0
		vehicle.steering_input = 0.0
		vehicle.nos_active = false
		_set_speedbreaker(false, delta)
		return

	var throt := maxf(Input.get_action_strength("Throttle"), touch_throttle)
	var brk := maxf(Input.get_action_strength("Brakes"), touch_brake)
	var sl := maxf(Input.get_action_strength("Steer Left"), touch_left)
	var sr := maxf(Input.get_action_strength("Steer Right"), touch_right)
	var hb := maxf(Input.get_action_strength("Handbrake"), touch_handbrake)
	var nos := Input.is_action_pressed("NOS") or touch_nos
	var sb_req := Input.is_action_pressed("Speedbreaker") or touch_sb

	# Speedbreaker (NFSMW slow-motion bullet-time & ultra-sharp grip)
	var sb_on := sb_req and vehicle.sb_energy > 4.0 and vehicle.speed > 5.0
	_set_speedbreaker(sb_on, delta)

	_analog_steering = move_toward(_analog_steering, touch_steer, delta * 18.0)
	var speed_gain := lerpf(1.0, 0.45, smoothstep(10.0, 37.0, vehicle.speed))
	vehicle.steering_input = clampf(sl - sr + _analog_steering * speed_gain, -1.0, 1.0)
	vehicle.handbrake_input = hb
	vehicle.clutch_input = hb
	vehicle.nos_active = nos

	if brk > 0.1 and throt <= 0.1 and vehicle.speed < 0.45:
		_reverse_hold += delta
	else:
		_reverse_hold = 0.0
	# Reverse requires a stopped car and deliberate continued hold.
	if brk > 0.1 and throt <= 0.1:
		if vehicle.current_gear >= 0:
			if vehicle.speed >= 0.45 or _reverse_hold < 0.55:
				vehicle.throttle_input = 0.0
				vehicle.brake_input = brk
			else:
				vehicle.current_gear = -1
				vehicle.requested_gear = -1
				vehicle.is_shifting = false
				vehicle.is_up_shifting = false
				vehicle.clutch_amount = 0.0
				vehicle.brake_amount = 0.0
				vehicle.brake_input = 0.0
				vehicle.throttle_input = pow(brk, 1.15)
		else:
			vehicle.brake_input = 0.0
			vehicle.throttle_input = pow(brk, 1.15)
	elif throt > 0.1:
		if vehicle.current_gear == -1:
			if vehicle.speed > 2.4 and vehicle.local_velocity.z > 1.0:
				vehicle.throttle_input = 0.0
				vehicle.brake_input = throt
			else:
				vehicle.current_gear = 1
				vehicle.requested_gear = 1
				vehicle.is_shifting = false
				vehicle.is_up_shifting = false
				vehicle.clutch_amount = 0.0
				vehicle.brake_amount = 0.0
				vehicle.brake_input = 0.0
				vehicle.throttle_input = pow(throt, 1.35)
		else:
			vehicle.throttle_input = pow(throt, 1.35)
			vehicle.brake_input = brk
	else:
		vehicle.throttle_input = 0.0
		vehicle.brake_input = brk

func _set_speedbreaker(active: bool, delta: float) -> void:
	if not is_instance_valid(vehicle):
		Engine.time_scale = 1.0
		return
	var unscaled_dt := delta / maxf(Engine.time_scale, 0.1)
	if active:
		vehicle.sb_active = true
		vehicle.sb_energy = maxf(0.0, vehicle.sb_energy - unscaled_dt * 22.0)
		Engine.time_scale = lerpf(Engine.time_scale, 0.45, clampf(unscaled_dt * 9.0, 0.0, 1.0))
		vehicle.steering_speed = 8.5
		if not _was_sb and _sb_sound_in:
			_sb_sound_in.play()
	else:
		vehicle.sb_active = false
		vehicle.sb_energy = minf(100.0, vehicle.sb_energy + unscaled_dt * 5.0)
		Engine.time_scale = lerpf(Engine.time_scale, 1.0, clampf(unscaled_dt * 10.0, 0.0, 1.0))
		if absf(Engine.time_scale - 1.0) < 0.03:
			Engine.time_scale = 1.0
		vehicle.steering_speed = 4.6
		if _was_sb and _sb_sound_out:
			_sb_sound_out.play()
	_was_sb = active
