extends Node3D

var world: MamadyshWorld
var atmosphere: AtmosphereManager
var camera_rig: CameraRig
var manager: PursuitAndRaceManager
var hud: GameHUD
var vehicles_root: Node3D

var selected_car_id := "lada_vesta_sport"
var showroom_root: Node3D
var showroom_car: Node3D
var player_car: MamadyshVehicle
var boot_ready := false
var _boot_label: Label
var _boot_layer: CanvasLayer
var _boot_start := Time.get_ticks_msec()
var player_ctrl: PlayerCarController

func diagnostic(stage: String) -> void:
	var line := "v4.4 | %d ms | %s" % [Time.get_ticks_msec() - _boot_start, stage]
	print(line)
	var f := FileAccess.open("user://startup.log", FileAccess.READ_WRITE)
	if f:
		f.seek_end()
		f.store_line(line)

func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_APPLICATION_FOCUS_OUT:
		if boot_ready and is_instance_valid(hud) and hud.hud_panel.visible:
			hud.set_paused(true)

func _set_quality(low: bool) -> void:
	world.apply_quality(low)
	atmosphere.sun_light.shadow_enabled = not low
	atmosphere.rain_particles.amount = 90 if low else 260
	camera_rig.far = 1600.0 if low else 2600.0
	hud.minimap.update_interval = 0.10 if low else 0.05


func _ready() -> void:
	var log_file := FileAccess.open("user://startup.log", FileAccess.WRITE)
	if log_file: log_file.close()
	diagnostic("engine=" + Engine.get_version_info().string + " renderer=" + RenderingServer.get_current_rendering_method())
	_boot_layer = CanvasLayer.new()
	add_child(_boot_layer)
	var bg := ColorRect.new()
	bg.color = Color("101824")
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_boot_layer.add_child(bg)
	_boot_label = Label.new()
	_boot_label.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_boot_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_boot_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_boot_label.add_theme_font_size_override("font_size", 28)
	_boot_label.text = "МАМАДЫШ • 4.4 COMPAT\nПодготовка гаража…"
	_boot_layer.add_child(_boot_label)
	await get_tree().process_frame
	await get_tree().process_frame
	diagnostic("first_loading_screen")
	world = MamadyshWorld.new()
	world.name = "MamadyshWorld"
	add_child(world)
	world.loading_stage.connect(func(stage: String):
		_boot_label.text = "МАМАДЫШ • 4.4 COMPAT\n" + stage
		diagnostic(stage)
	)
	if not await world.build_world_async():
		_boot_label.text = "Не удалось прочитать карту.\nПереустановите проверенный APK 4.4 и перезапустите игру."
		diagnostic("map_validation_failed")
		return
	diagnostic("city_collisions_ready")

	vehicles_root = Node3D.new()
	vehicles_root.name = "Vehicles"
	add_child(vehicles_root)

	camera_rig = CameraRig.new()
	camera_rig.name = "CameraRig"
	add_child(camera_rig)
	camera_rig.make_current()

	atmosphere = AtmosphereManager.new()
	atmosphere.name = "AtmosphereManager"
	add_child(atmosphere)
	atmosphere.setup(self, world, camera_rig)

	manager = PursuitAndRaceManager.new()
	manager.name = "PursuitAndRaceManager"
	add_child(manager)
	manager.setup(vehicles_root, world)

	hud = GameHUD.new()
	hud.name = "GameHUD"
	add_child(hud)
	hud.build_ui()
	hud.quality_changed.connect(_set_quality)
	hud.minimap.setup(world, manager)
	hud.set_atmosphere_label(atmosphere.get_mode_label())

	hud.car_selected.connect(_on_car_selected)
	hud.circuit_selected.connect(_on_circuit_selected)
	hud.start_requested.connect(_on_start_requested)
	hud.atmosphere_cycled.connect(_on_atmosphere_cycled)
	hud.camera_cycled.connect(_on_camera_cycled)
	hud.reset_car_requested.connect(_on_reset_car)
	hud.back_to_garage_requested.connect(_enter_garage)

	manager.hud_event.connect(func(msg: String, col: Color): hud.show_banner(msg, col))
	manager.state_changed.connect(func(_st, summary: Dictionary): hud.show_result(summary))

	_build_showroom()
	_enter_garage()
	_set_quality(hud.quality_low)
	boot_ready = true
	_boot_layer.queue_free()
	diagnostic("garage_ready")

func _build_showroom() -> void:
	showroom_root = Node3D.new()
	showroom_root.name = "ShowroomPodium"
	# Scenic Victory Park plaza right beside Mamadysh Eiffel Tower & 1941-1945 Memorial!
	var sx := 744.0; var sz := 22.0
	var sy := world.sample_terrain_h(sx, sz) + 0.35
	showroom_root.position = Vector3(sx, sy, sz)
	add_child(showroom_root)

	var podium := MeshInstance3D.new()
	var cm := CylinderMesh.new(); cm.top_radius = 3.8; cm.bottom_radius = 4.1; cm.height = 0.25
	podium.mesh = cm; podium.position = Vector3(0, -0.125, 0)
	var pmat := StandardMaterial3D.new(); pmat.albedo_color = Color(0.10, 0.12, 0.16); pmat.metallic = 0.72; pmat.roughness = 0.26
	podium.material_override = pmat; showroom_root.add_child(podium)

	var spot := OmniLight3D.new(); spot.light_color = Color(1.0, 0.94, 0.85); spot.light_energy = 2.6; spot.omni_range = 14.0
	spot.position = Vector3(0, 4.0, 0); showroom_root.add_child(spot)

func _spawn_showroom_car(car_id: String) -> void:
	if is_instance_valid(showroom_car): showroom_car.queue_free()
	var cfg := CarCatalog.get_car(car_id)
	var ps := load(cfg["glb"]) as PackedScene
	showroom_car = ps.instantiate()
	VehicleFactory.finish_showroom_model(showroom_car)
	showroom_car.rotation_degrees = Vector3(0, 145, 0)
	showroom_root.add_child(showroom_car)

func _enter_garage() -> void:
	get_tree().paused = false
	if is_instance_valid(hud): hud.set_paused(false)
	Engine.time_scale = 1.0
	manager.clear_entities()
	manager.state = PursuitAndRaceManager.State.IDLE
	if is_instance_valid(player_car): player_car.queue_free(); player_car = null
	if is_instance_valid(player_ctrl): player_ctrl.queue_free(); player_ctrl = null

	showroom_root.visible = true
	_spawn_showroom_car(selected_car_id)
	camera_rig.set_garage_target(showroom_root.global_position)
	hud.show_garage()

func _on_car_selected(car_id: String) -> void:
	selected_car_id = car_id
	if showroom_root.visible:
		_spawn_showroom_car(car_id)

func _on_circuit_selected(circuit_id: String) -> void:
	world.set_active_circuit(circuit_id)
	hud.minimap.refresh_map_cache()

func _on_start_requested(game_mode: PursuitAndRaceManager.GameMode) -> void:
	if not world.ready_to_drive: return
	hud.set_paused(false)
	diagnostic("session_start mode=%d route=%s" % [game_mode, world.active_circuit_name])
	Engine.time_scale = 1.0
	showroom_root.visible = false
	if is_instance_valid(showroom_car): showroom_car.queue_free(); showroom_car = null
	if is_instance_valid(player_car): player_car.queue_free()
	if is_instance_valid(player_ctrl): player_ctrl.queue_free()

	player_car = VehicleFactory.create_vehicle(selected_car_id, "player", true)
	player_car.transform = world.spawn_transform
	player_car.crashed.connect(func(imp: float, _other):
		if imp > 2400.0:
			camera_rig.add_shake(clampf(imp / 14000.0, 0.15, 0.9))
	)
	vehicles_root.add_child(player_car)

	player_ctrl = PlayerCarController.new()
	player_ctrl.vehicle = player_car
	add_child(player_ctrl)

	camera_rig.bind_vehicle(player_car)
	var is_night := atmosphere.current_mode == AtmosphereManager.TimeMode.NIGHT_RAIN
	manager.start_session(game_mode, player_car, player_ctrl, is_night)
	hud.bind_session(player_car, player_ctrl, manager)
	hud.show_hud()

func _on_atmosphere_cycled() -> void:
	atmosphere.cycle_mode()
	var lbl := atmosphere.get_mode_label()
	hud.set_atmosphere_label(lbl)
	if not showroom_root.visible:
		hud.show_banner("ПОГОДА: " + lbl, Color(0.55, 0.85, 1.0))

func _on_camera_cycled() -> void:
	var lbl := camera_rig.cycle_view()
	hud.set_camera_label(lbl)
	hud.show_banner(lbl, Color(0.85, 0.92, 1.0))

func _on_reset_car() -> void:
	if not is_instance_valid(player_car) or not is_instance_valid(world):
		return
	var tr := world.get_nearest_road_transform(player_car.global_position)
	player_car.global_transform = tr
	manager.clear_player_gate_sample()
	player_car.linear_velocity = Vector3.ZERO
	player_car.angular_velocity = Vector3.ZERO
	hud.show_banner("АВТО ВОЗВРАЩЕНО НА ДОРОГУ", Color(1.0, 0.84, 0.28))
